export interface IProductPayload {
    DistributorCode: number
    Category: string
    SearchText: string
    PageSize: number
    PageIndex: number
  }
  export interface IProductList {
    materialCode: string
    quantity:number
    uom: string
    description: string
    division: string
    divisionDescription: string
    distributionChannel: string
    distributionChannelDescription: string
    materialGroup: string
    materialGroupDescription: string
    firstLevelCategory: any
    firstLevelDescription: any
    secondLevelCategory: any
    secondLevelDescription: any
    thirdLevelCategory: any
    thirdLevelDescription: any
    fourthLevelCategory: any
    fourthLevelDescription: any
    isActive: boolean
    moq: number
    materialHSN: any
    materialRDP: MaterialRdp
    distributorInventoryItem: DistributorInventoryItem[]
  }
  
  export interface MaterialRdp {
    materialCode: string
    uom: string
    currency: string
    per: string
    mrp: number
    rdp: number
    validFrom: string
    validTo: string
  }
  
  export interface DistributorInventoryItem {
    distributorCode: number
    distributor: any
    goodItemQuantity: number
    badItemQuantity: number
    materialCode: string
    uom: any
    distributorMaterialMapping: any
  }
  