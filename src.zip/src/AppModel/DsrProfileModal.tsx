import { Role } from "../redux/datamodel/authDataModal"
import { Distributor2 } from "./UserProfileModel"

export interface IDsrProfileDto {
  dsrId: number
  dsrName: string
  mobileNo: string
  aadhaarNo: string
  emailId: string
  distributorCode: number
  distributor: Distributor2
  retailers: any
  isApproved: boolean
  isRejected: boolean
  beats: any
  visitDetails: any
  dmsUserId: any
  dmsUser: any
  dsrCode: number
  profile: ProfileDto
}
export interface ProfileDto {
  profileId: number | undefined
  profileName: string
  profileRole: Role
}

// export interface Distributor2 {
//   distributorCode: number
//   distributorName: string
//   address1: any
//   address2: string
//   address3: string
//   address4: any
//   address5: any
//   address6: string
//   pinCode: string
//   city: string
//   state: string
//   telephone: string
//   mobileNo: any
//   whatsAppNo: any
//   emailId: string
//   salesOffice: string
//   region: string
//   activeFrom: string
//   deActivatedOn: any
//   status: string
//   dmsUserName: number
//   dmsUser: any
//   stateCode: number
//   stateCodeDescription: any
//   dsRs: any[]
//   distributorBeats: any
//   retailers: Retailer[]
//   distributorBankTaxDetails: any
//   distributorDistributionChannels: any
//   distributorComplains: any
//   items: any
// }
export interface Retailer {
  retailerCode: number
  retailer: Retailer2
  distributorCode: number
  creditLimit: number
  distance: number
  outStanding: number
  status: boolean
}

export interface Retailer2 {
  retailerCode: number
  retailerName: string
  houseNo: any
  street1: any
  street2: string
  street3: string
  street4: string
  district: string
  pinCode: string
  city: string
  state: string
  mobileNo: number
  whatsAppNo: string
  emailId: any
  salesOffice: string
  region: string
  activeFrom: string
  deActivatedOn: string
  status: string
  dmsUserName: number
  dmsUser: any
  stateCode: number
  stateCodeDescription: any
  distributors: any[]
  dsrProfiles: any
  retailerBankTaxDetails: any
  retailerOrders: any
}
