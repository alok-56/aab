export interface ICategoryModel {
    CategoryName:string
    IsSelected:boolean
}