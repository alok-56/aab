export interface IOrderList {
    id: number
    orderNo: string
    orderDate: string
    retailerCode: number
    retailer: any
    distributorCode: number
    distributor: Distributor
    cartTotal: number
    tax: number
    invoiceValue: number
    expectedDelivery: string
    isOrderByDSR: boolean
    payment_Done: boolean
    retailerOrderStatusId: number
    retailerOrderStatus: RetailerOrderStatus
    distributorOrderStatusId: number
    distributorOrderStatus: any
    invoices: any[]
    isShortClosedByDistributor: boolean
    distributorShortCloseReason: any
    distributorShortCloseDescription: any
    iscancelledByDistributor: boolean
    distributorCancelReason: any
    iscancelledByRetailer: any
    cancelReason: any
    remarks: any
    fileName: any
    retailerOrderLineItems: any
  }
  
  export interface Distributor {
    distributorCode: number
    distributorName: string
    address1: string
    address2: string
    address3: string
    address4: any
    address5: any
    address6: string
    pinCode: string
    city: string
    state: string
    telephone: string
    mobileNo: any
    whatsAppNo: any
    emailId: string
    salesOffice: string
    region: string
    activeFrom: string
    deActivatedOn: any
    status: string
    dmsUserName: number
    dmsUser: any
    stateCode: number
    stateCodeDescription: any
    dsRs: any
    distributorBeats: any
    retailers: any
    distributorBankTaxDetails: any
    distributorDistributionChannels: any
    distributorComplains: any
    items: any
  }
  
  export interface RetailerOrderStatus {
    id: number
    name: string
  }
  