import { ProfileDto } from "./DsrProfileModal"

export interface IuserPorfileDto {
  retailerCode: number
  retailerName: string
  bankDetailsStatus:string
  approvedOn:string
  houseNo: any
  street1: any
  street2: any
  street3: any
  street4: any
  district: string
  pinCode: string
  city: any
  state: string
  mobileNo: number
  whatsAppNo: string
  emailId: any
  salesOffice: string
  region: string
  activeFrom: string
  deActivatedOn: string
  status: string
  dmsUserName: number
  dmsUser: any
  stateCode: number
  stateCodeDescription: any
  distributors: Distributor[]
  dsrProfiles: any
  retailerBankTaxDetails: RetailerBankTaxDetails
  retailerOrders: any
  profile:ProfileDto
}

export interface Distributor {
  retailerCode: number
  isSelected: boolean
  distributorCode: number
  distributor: Distributor2
  creditLimit: number
  distance: number
  outStanding: number
  status: boolean
}

export interface Distributor2 {
  distributorCode: number
  distributorName: string
  address1: any
  address2: string
  address3?: string
  address4: any
  address5: any
  address6: any
  pinCode: string
  city: string
  state: string
  telephone: string
  mobileNo: any
  whatsAppNo: any
  emailId: string
  salesOffice: string
  region: string
  activeFrom: string
  deActivatedOn: any
  status: string
  dmsUserName: number
  dmsUser: any
  stateCode: number
  stateCodeDescription: any
  dsRs: any
  distributorBeats: any
  retailers: any[]
  distributorBankTaxDetails: any
  distributorDistributionChannels: any
  distributorComplains: any
  items: any
}

export interface RetailerBankTaxDetails {
  retailerCode: number
  gstin: any
  panNo: any
  bankAccountNo: any
  accountHolderName: string
  bankName: any
  ifscCode: any
}
