import { View, Text, Modal, Image, StyleSheet, TextInput, Switch, FlatList, ActivityIndicator } from 'react-native'
import React, { SetStateAction, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import * as config from '../../config/index'
import { RadioButton } from 'react-native-paper';
// import RadioGroup from 'react-native-radio-buttons-group';

const Loader = (props: any) => {
    const { isOpen, onClose, onfilterValueSelected, filterValues, selectedFilter } = props;

    useEffect(() => {
        // setValue(filterValues[2])
    }, [])
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                {/* <View>
                    <TouchableOpacity activeOpacity={1}> */}
                <View style={styles.ModalView}>
                    <View style={[styles.innerModalView]}>
                        <ActivityIndicator size="small" color={config.fontAttribute.themeColor} />
                    </View>
                </View>
                {/* </TouchableOpacity></View> */}
            </Modal>
        </View>
    )
}

export default Loader

const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0,0,0,0.8)'
        // backgroundColor: 'transparent'
    },
    innerModalView: {
        backgroundColor: 'rgba(0,0,0,0.5)',
        height: 'auto',
        // width: '70%',
        borderRadius: 10,
        padding: 10
    },
    crossIcon: {
        alignItems: 'flex-end',
        marginBottom: 15,
        marginRight: 20,
        padding: 10
    },
    downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 30
    },
    titleView: {
        backgroundColor: config.fontAttribute.themeColor,
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        padding: 15,
        justifyContent: 'center',
        alignItems: 'center'
    },
    cancelButtonView: {
        padding: 15,
        justifyContent: 'center',
        alignItems: 'center',
        borderTopColor: 'gray',
        borderTopWidth: 0.5
    }
})