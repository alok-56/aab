import { View, Text, TouchableOpacity, Modal, StyleSheet, Image } from 'react-native'
import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { faCameraRetro, faImages } from '@fortawesome/free-solid-svg-icons'
import * as config from '../../config/index'
import { pixelValue } from '../../config/GlobalVariable'
import { useTranslation } from 'react-i18next'

const CameraOptionsModal = (props: any) => {
    const { isOpen, onClose, fromCamera, fromGallery } = props;
    const { t, i18n } = useTranslation();

    return (

        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={config.AppStyle.AppStyle.ModalOuterCss}>
                    <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                        <View style={config.AppStyle.AppStyle.ModalCrossIcon}>
                            <Image source={config.Images.cross} />
                        </View>
                    </TouchableOpacity>
                    <View style={[config.AppStyle.AppStyle.ModalInnerCss, { padding: 15, paddingHorizontal: 30 }]}>
                        <TouchableOpacity
                            onPress={fromCamera}
                            activeOpacity={0.8}
                        >
                            <View style={styles.typesOfImageUpload}>
                                <FontAwesomeIcon icon={faCameraRetro} size={25} color={config.fontAttribute.themeColor} />
                                <Text style={styles.typesOfImageUploadText}>{t('takeAPhoto')}</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity
                            onPress={fromGallery}
                            activeOpacity={0.8}
                        >
                            <View style={styles.typesOfImageUpload}>
                                <FontAwesomeIcon icon={faImages} size={25} color={config.fontAttribute.themeColor} />
                                <Text style={styles.typesOfImageUploadText}>{t('chooseFromGallery')}</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal >
        </View>
    )
}

export default CameraOptionsModal
const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.8)'
    },
    innerModalView: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '100%',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        padding: 20
    },
    crossIcon: {
        alignItems: 'flex-end',
        marginBottom: 30,
        marginRight: 20
    },
    typesOfImageUpload: {
        flexDirection: 'row',
        margin: 15,
        alignItems: 'center'
    },
    typesOfImageUploadText: {
        fontSize: 15 * pixelValue,
        fontWeight: '500',
        marginStart: 15,
        color: '#344054'
    }
})