import {
  useFocusEffect,
  useIsFocused,
  useNavigation,
} from '@react-navigation/native';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { SvgXml } from 'react-native-svg';
import Icon from 'react-native-vector-icons/FontAwesome';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';
import { GetUserProfileService } from '../../ApiServices/httpServices';
import { Distributor2, IuserPorfileDto } from '../../AppModel/UserProfileModel';
import { Headercomponent } from '../../Components';
import {
  BankDetailsStatusCodes,
  BankStatusKey,
  capitalize,
  checkStringNullOrEmpty,
  NavMenu,
} from '../../config/GlobalVariable';
import * as config from '../../config/index';
import {
  setDistributors,
  setProfileDetail,
} from '../../redux/actions/authAction';
import { Role } from '../../redux/datamodel/authDataModal';
import Loader from './loader';
import styles from './style';

const RetailerProfile = (props: any) => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const [RetailerDetails, setRetailerDetails] =
    useState<IuserPorfileDto | null>(null);
  const [isLoader, setIsLoader] = useState(false);
  const lodggedInUser = useSelector(
    (state: any) => state.auth.userData,
    shallowEqual,
  );
  const isFocused = useIsFocused();
  useFocusEffect(
    React.useCallback(() => {
      if (isFocused) {
        console.log('Logged In User in Profile', lodggedInUser);
        getRetailerProfile(lodggedInUser?.retailerCode || lodggedInUser?.userName, lodggedInUser?.role);
        // profileDetail?.profile?.profileRole?.id == 4 ? selectedRetailer = profileDetail : null;
      }
    }, [isFocused]),
  );
  // useEffect(() => {
  //     getRetailerProfile(lodggedInUser?.retailerCode, lodggedInUser?.role)
  //     console.log("LoggedInUser", lodggedInUser?.retailerCode, lodggedInUser?.role)
  // }, [])

  //Get RetailerProfile

  function formatDate(isoString: any) {
    const date = new Date(isoString);

    // Create an array for month abbreviations
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];

    // Get the month, day, and year
    const month = months[date.getMonth()];
    const day = date.getDate();
    const year = date.getFullYear();

    // Format the date
    return `${month} ${day}, ${year}`;
  }

  const getRetailerProfile = (userId: number, role: Role) => {
    setIsLoader(true);
    console.log(userId)
    console.log('i am here in Retailer Profile');
    GetUserProfileService(userId)
      .then((result: IuserPorfileDto) => {
        setIsLoader(false);
        result.profile = {
          profileId: result?.retailerCode,
          profileName: result?.retailerName,
          profileRole: role,
        };
        console.log('Retailer Profile', JSON.stringify(result));
        setRetailerDetails(result);
        dispatch(setProfileDetail(result));
        //setting distrbutor
        let DistributorArray: Array<Distributor2> = new Array<Distributor2>();
        result?.distributors.map(item => {
          DistributorArray.push(item?.distributor);
        });
        dispatch(setDistributors(DistributorArray));
        // setIsLoading(false)
      })
      .catch((err: any) => {
        setIsLoader(false);
        // setIsLoading(false)
        console.error('error:', err);
      });
  };

  const onEditIconClicked = (navigation: any, mode: any) => {
    switch (mode) {
      case 'create':
        navigation.navigate(NavMenu.updateBankDetails, { isView: false });
        break;
      case 'view':
        navigation.navigate(NavMenu.updateBankDetails, { isView: true });
        break;
      default:
        break;
    }
  };

  const { t, i18n } = useTranslation();

  return (
    <View style={{ maxHeight: '100%' }}>
      <Headercomponent name={t('myProfile')} type={'2'} />
      <ScrollView>
        <View>
          <View style={styles.userDetails}>
            <TouchableOpacity
              // onPress={onCameraIconclicked}
              activeOpacity={0.8}
            >
              <View>
                {/* {!checkStringNullOrEmpty(profilePic)
                                    ? */}
                <SvgXml
                  style={styles.userProfilePic}
                  height={70}
                  width={70}
                  xml={config.svgs.profileIcon}
                />
                {/* : <Image style={styles.userProfilePic} source={profilePic ? { uri: profilePic } : {}} />
                                } */}
                {/* <FontAwesomeIcon icon={faCamera} style={styles.cameraIcon} size={20} color={config.fontAttribute.TextColor1} /> */}
              </View>
            </TouchableOpacity>
            <View style={styles.userInfo}>
              <Text style={styles.userNameText}>
                {capitalize(
                  RetailerDetails?.retailerName
                    ? capitalize(RetailerDetails?.retailerName)
                    : '',
                )}
              </Text>
              <Text style={styles.userEmailText}>
                {checkStringNullOrEmpty(RetailerDetails?.emailId)
                  ? RetailerDetails?.emailId.toLowerCase()
                  : '-'}
              </Text>
            </View>
          </View>
        </View>

        {/* User Details */}
        <View style={styles.section}>
          <Text style={styles.SectionTitle}>{t('generalInformation')}</Text>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('retailerCode')}</Text>
            <Text selectable={true} style={styles.sectionItemValue}>
              {RetailerDetails?.retailerCode}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('address')}</Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(RetailerDetails?.street1)
                ? `${capitalize(RetailerDetails?.street1)}, `
                : ''}
              {checkStringNullOrEmpty(RetailerDetails?.street2)
                ? `${capitalize(RetailerDetails?.street2)}, `
                : ''}
              {checkStringNullOrEmpty(RetailerDetails?.street3)
                ? `${capitalize(RetailerDetails?.street3)}, `
                : ''}
              {checkStringNullOrEmpty(RetailerDetails?.street4)
                ? `${capitalize(RetailerDetails?.street4)}, `
                : ''}
              {checkStringNullOrEmpty(RetailerDetails?.pinCode)
                ? `${RetailerDetails?.pinCode}, `
                : ''}
              {RetailerDetails?.district != null
                ? `${capitalize(RetailerDetails?.district)}, `
                : ''}
              {RetailerDetails?.state != null
                ? `${capitalize(RetailerDetails?.state)} `
                : ''}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('mobileNo')}</Text>
            <Text style={styles.sectionItemValue}>
              {RetailerDetails?.mobileNo != null
                ? RetailerDetails?.mobileNo
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('whatsappNo')}</Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(RetailerDetails?.whatsAppNo)
                ? RetailerDetails?.whatsAppNo
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('emailId')}</Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(RetailerDetails?.emailId)
                ? RetailerDetails?.emailId.toLowerCase()
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('salesOffice')}</Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(RetailerDetails?.salesOffice)
                ? RetailerDetails?.salesOffice
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('region')}</Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(RetailerDetails?.region)
                ? RetailerDetails?.region
                : '-'}
            </Text>
          </View>
        </View>

        {/* Bank Details */}
        <View style={styles.section}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <Text style={styles.SectionTitle}>{t('bankDetails')}</Text>
            {!(
              RetailerDetails?.bankDetailsStatus.toLowerCase() ===
              'sent for approval'
            ) ? (
              <TouchableOpacity
                style={{ padding: 10 }}
                onPress={() => onEditIconClicked(navigation, 'create')}
              >
                <Icon
                  name="pencil"
                  size={15}
                  color={config.fontAttribute.themeColor}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={{ padding: 10 }}
                onPress={() => onEditIconClicked(navigation, 'view')}
              >
                <Icon
                  name="eye"
                  size={15}
                  color={config.fontAttribute.themeColor}
                />
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('gstin')}</Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(
                RetailerDetails?.retailerBankTaxDetails.gstin,
              )
                ? RetailerDetails?.retailerBankTaxDetails?.gstin
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('panNumber')}</Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(
                RetailerDetails?.retailerBankTaxDetails.panNo,
              )
                ? RetailerDetails?.retailerBankTaxDetails?.panNo
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>
              {t('bankAccountNumber')}
            </Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(
                RetailerDetails?.retailerBankTaxDetails.bankAccountNo,
              )
                ? RetailerDetails?.retailerBankTaxDetails?.bankAccountNo
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>
              {t('accountHolderName')}
            </Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(
                RetailerDetails?.retailerBankTaxDetails.accountHolderName,
              )
                ? RetailerDetails?.retailerBankTaxDetails?.accountHolderName
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('bankName')}</Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(
                RetailerDetails?.retailerBankTaxDetails.bankName,
              )
                ? RetailerDetails?.retailerBankTaxDetails?.bankName
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('ifscCode')}</Text>
            <Text style={styles.sectionItemValue}>
              {checkStringNullOrEmpty(
                RetailerDetails?.retailerBankTaxDetails.ifscCode,
              )
                ? RetailerDetails?.retailerBankTaxDetails?.ifscCode
                : '-'}
            </Text>
          </View>
          <View style={styles.sectionItems}>
            <Text style={styles.sectionItemTitle}>{t('status')}</Text>
            <Text
              style={[
                styles.sectionItemValue,
                {
                  color:
                    BankDetailsStatusCodes[
                      RetailerDetails?.bankDetailsStatus.toLowerCase() as BankStatusKey
                    ] || '#000000',
                },
              ]}
            >
              {' '}
              {checkStringNullOrEmpty(RetailerDetails?.bankDetailsStatus)
                ? RetailerDetails?.bankDetailsStatus
                : '-'}
            </Text>
            {/* <Text style={styles.sectionItemValue}>{checkStringNullOrEmpty(RetailerDetails?.bankDetailsStatus) ? RetailerDetails?.bankDetailsStatus : "-"}</Text> */}
          </View>
          {RetailerDetails?.approvedOn &&
            RetailerDetails?.bankDetailsStatus.toLowerCase() == 'approved' && (
              <View
                style={{
                  flexDirection: 'row',
                  marginRight: 10,
                  justifyContent: 'flex-end',
                }}
              >
                <Text style={styles.sectionItemValue}>
                  {' '}
                  Last updated on :{' '}
                  {checkStringNullOrEmpty(RetailerDetails?.approvedOn)
                    ? formatDate(RetailerDetails?.approvedOn)
                    : '-'}
                </Text>
              </View>
            )}
        </View>
      </ScrollView>
      {/* <CameraOptionsModal
                isOpen={isMenuOpen}
                onClose={toggleMenu}
                fromCamera={clickFromCamera}
                fromGallery={chooseFromGallery}
            /> */}
      <Loader isOpen={isLoader} />
    </View>
  );
};

export default RetailerProfile;
