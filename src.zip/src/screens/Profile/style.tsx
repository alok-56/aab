import * as config from "../../config"
import { StyleSheet } from "react-native";
import { pixelValue } from "../../config/GlobalVariable";

const styles = StyleSheet.create({

    userProfilePic: {
        height: 70,
        width: 70,
        borderColor: config.fontAttribute.TextColor1,
        borderRadius: 100
    },
    userDetails: {
        flexDirection: 'row',
        alignItems: 'center',
        margin: 10,
        backgroundColor: '#fff',
        padding: 10,
        borderRadius: 10
    },
    userInfo: {
        marginLeft: 20,
        maxWidth: '70%'
    },

    userNameText: {
        fontWeight: '600',
        color: config.fontAttribute.TextColor2,
        fontSize: config.fontAttribute.labelFontSize * pixelValue
    },
    userEmailText: {
        fontWeight: '400',
        color: config.fontAttribute.TextColor1,
        fontSize: config.fontAttribute.labelFontSizeSmall * pixelValue
    },
    SectionTitle: {
        color: config.fontAttribute.themeColor,
        fontWeight: '500',
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
        letterSpacing: 1,
        margin: 10
    },
    sectionItems: {
        flexDirection: 'row', margin: 10, justifyContent: 'space-between'
    },
    section: {
        backgroundColor: '#fff', margin: 10, borderRadius: 10, padding: 5
    },
    sectionItemTitle: {
        color: config.fontAttribute.TextColor2,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
        maxWidth: '30%'
    },
    retailerName: {
        color: config.fontAttribute.TextColor2,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
        maxWidth: '70%'
    },
    noAssociatedRetailersArea: {
        padding: 10,
        justifyContent: 'center',
        alignItems: 'center'
    },
    noAssociatedRetailers: {
        color: config.fontAttribute.TextColor1,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
    },
    sectionItemValue: {
        maxWidth: '70%',
        color: config.fontAttribute.TextColor1,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '400',
        textAlign: 'right'
    },
    cameraIcon: {
        position: 'absolute',
        right: 1,
        bottom: 0
    }
})
export default styles;