import {
  View,
  Text,
  ScrollView,
  Image,
  StyleSheet,
  TouchableOpacity,
  Platform,
} from 'react-native';
import React, { SetStateAction, useEffect, useState } from 'react';
import { Headercomponent } from '../../Components';
import {
  capitalize,
  checkStringNullOrEmpty,
} from '../../config/GlobalVariable';
import * as config from '../../config/index';
import { useTranslation } from 'react-i18next';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCamera } from '@fortawesome/free-solid-svg-icons';
import CameraOptionsModal from './modal';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import { shallowEqual, useSelector } from 'react-redux';
import { GetUserProfileService } from '../../ApiServices/httpServices';
import { IuserPorfileDto } from '../../AppModel/UserProfileModel';
import { SvgXml } from 'react-native-svg';
import styles from './style';
import { request, PERMISSIONS, RESULTS } from 'react-native-permissions';
import RetailerProfile from './RetailerProfile';
import DsrProfile from './DsrProfile';
import { IDsrProfileDto } from '../../AppModel/DsrProfileModal';
const Profile = () => {
  const { t, i18n } = useTranslation();
  const [isMenuOpen, setMenuOpen] = useState(false);
  const [profilePic, setProfilePic] = useState('');
  const [profileDetail, setProfileDetail] = useState<
    IuserPorfileDto | IDsrProfileDto | null
  >(null);

  const ProfileDetails = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );
  useEffect(() => {
    console.log('User: ', ProfileDetails);
    setProfileDetail(ProfileDetails);
  }, []);
  // const toggleMenu = () => {
  //     setMenuOpen(!isMenuOpen);
  // };
  // const onCameraIconclicked = () => {
  //     // toggleMenu();
  // }
  // const chooseFromGallery = async () => {
  //     toggleMenu();
  //     let options: any = {}
  //     const imagePath = await launchImageLibrary(options)

  //     let s: SetStateAction<string> | null = ''
  //     s = imagePath?.assets?.[0]?.uri ? imagePath?.assets?.[0]?.uri : "";
  //     setProfilePic(s);
  // }
  // const clickFromCamera = async () => {
  //     toggleMenu();
  //     let options: any = {}
  //     const result = await launchCamera(options);

  //     let s: SetStateAction<string> | null = ''
  //     s = result?.assets?.[0]?.uri ? result?.assets?.[0]?.uri : "";
  //     setProfilePic(s);
  // }
  return (
    <>
      {profileDetail?.profile?.profileRole?.id == 3 && <RetailerProfile />}
      {profileDetail?.profile?.profileRole?.id == 14 && <RetailerProfile />}
      {profileDetail?.profile?.profileRole?.id == 4 && <DsrProfile />}
    </>
  );
};

export default Profile;
