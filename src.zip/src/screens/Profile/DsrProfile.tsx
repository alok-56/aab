import { View, Text, Image, FlatList } from 'react-native'
import React, { useEffect, useState } from 'react'
import styles from './style'
import { Headercomponent } from '../../Components'
import { ScrollView } from 'react-native'
import { TouchableOpacity } from 'react-native'
import { capitalize, checkStringNullOrEmpty } from '../../config/GlobalVariable'
import { shallowEqual, useDispatch, useSelector } from 'react-redux'
import { useTranslation } from 'react-i18next'
import { SvgXml } from 'react-native-svg'
import * as config from '../../config/index'
import { IDsrProfileDto } from '../../AppModel/DsrProfileModal'
import { Role } from '../../redux/datamodel/authDataModal'
import { GetDsrProfileService } from '../../ApiServices/httpServices'
import { setDistributors, setProfileDetail } from '../../redux/actions/authAction'
import { Distributor2 } from '../../AppModel/UserProfileModel'
import Loader from './loader'


const DsrProfile = () => {
    const dispatch = useDispatch()
    const [DsrDetails, setDsrDetails] = useState<IDsrProfileDto | null>(null)
    const [isLoader, setIsLoader] = useState(false)
    const profileDetail: IDsrProfileDto = useSelector((state: any) => state.auth.profileData,
        shallowEqual,)
    const lodggedInUser = useSelector((state: any) => state.auth.userData,
        shallowEqual,)
    useEffect(() => {
        getDsrProfile(lodggedInUser?.dsrId, lodggedInUser?.role)
    }, [])


    //Get DSR Profile
    const getDsrProfile = (userId: number, role: Role) => {
        setIsLoader(true)
        GetDsrProfileService(userId).then((result: IDsrProfileDto) => {
            setIsLoader(false)
            console.log("Dsr Profile", result)
            result.profile = {
                profileId: result?.dsrCode,
                profileName: result?.dsrName,
                profileRole: role
            }
            setDsrDetails(result)
            dispatch(setProfileDetail(result));
            //setting distributors
            let DistributorArray: Array<Distributor2> = new Array<Distributor2>();
            DistributorArray.push(result?.distributor);
            dispatch(setDistributors(DistributorArray));
            // setIsLoading(false)
        }).catch((err: any) => {
            setIsLoader(false)
            // setIsLoading(false)
            console.error("error:", err);
        })
    }
    const { t, i18n } = useTranslation();

    const renderedItem = (item: any) => {
        return (
            <View style={styles.sectionItems}>
                <Text style={styles.retailerName}>{capitalize(item?.retailerName)}</Text>
                <Text style={styles.sectionItemValue}>{item?.retailerCode}</Text>
            </View>
        )
    }
    return (
        <View style={{ maxHeight: '100%' }}>
            <Headercomponent name={t('myProfile')} type={'2'} />
            <ScrollView>
                <View>
                    <View style={styles.userDetails}>
                        <TouchableOpacity
                            // onPress={onCameraIconclicked}
                            activeOpacity={0.8}>
                            <View>
                                {/* {!checkStringNullOrEmpty(profilePic)
                                    ? */}
                                <SvgXml style={styles.userProfilePic} height={70} width={70} xml={config.svgs.profileIcon} />
                                {/* : <Image style={styles.userProfilePic} source={profilePic ? { uri: profilePic } : {}} />
                                } */}
                                {/* <FontAwesomeIcon icon={faCamera} style={styles.cameraIcon} size={20} color={config.fontAttribute.TextColor1} /> */}
                            </View>
                        </TouchableOpacity>
                        <View style={styles.userInfo}>
                            <Text style={styles.userNameText}>{capitalize(DsrDetails?.profile?.profileName ? capitalize(DsrDetails?.profile?.profileName) : '')}</Text>
                            <Text style={styles.userEmailText}>{checkStringNullOrEmpty(DsrDetails?.emailId) ? DsrDetails?.emailId.toLowerCase() : "-"}</Text>
                        </View>
                    </View>
                </View>

                {/* User Details */}
                <View style={styles.section}>
                    <Text style={styles.SectionTitle}>{t('generalInformation')}</Text>
                    <View style={styles.sectionItems}>
                        <Text style={styles.sectionItemTitle}>{t('dsrCode')}</Text>
                        <Text style={styles.sectionItemValue}>{DsrDetails?.dsrCode}</Text>
                    </View>
                    {/* <View style={styles.sectionItems}>
                        <Text style={styles.sectionItemTitle}>{t('address')}</Text>
                        <Text style={styles.sectionItemValue}>
                            {checkStringNullOrEmpty(DsrDetails?.street1) ? `${capitalize(DsrDetails?.street1)}, ` : ""}
                            {checkStringNullOrEmpty(DsrDetails?.street2) ? `${capitalize(DsrDetails?.street2)}, ` : ""}
                            {checkStringNullOrEmpty(DsrDetails?.street3) ? `${capitalize(DsrDetails?.street3)}, ` : ""}
                            {checkStringNullOrEmpty(DsrDetails?.street4) ? `${capitalize(DsrDetails?.street4)}, ` : ""}
                            {checkStringNullOrEmpty(DsrDetails?.pinCode) ? `${DsrDetails?.pinCode}, ` : ""}
                            {DsrDetails?.district != null ? `${capitalize(DsrDetails?.district)}, ` : ""}
                            {DsrDetails?.state != null ? `${capitalize(DsrDetails?.state)} ` : ""}

                        </Text>
                    </View> */}
                    <View style={styles.sectionItems}>
                        <Text style={styles.sectionItemTitle}>{t('distributorCode')}</Text>
                        <Text style={styles.sectionItemValue}>{DsrDetails?.distributorCode != null ? DsrDetails?.distributorCode : "-"}</Text>
                    </View>
                    <View style={styles.sectionItems}>
                        <Text style={styles.sectionItemTitle}>{t('distributorName')}</Text>
                        <Text style={styles.sectionItemValue}>{checkStringNullOrEmpty(DsrDetails?.distributor?.distributorName) ? capitalize(DsrDetails?.distributor?.distributorName) : "-"}</Text>
                    </View>
                    <View style={styles.sectionItems}>
                        <Text style={styles.sectionItemTitle}>{t('mobileNo')}</Text>
                        <Text style={styles.sectionItemValue}>{DsrDetails?.mobileNo != null ? DsrDetails?.mobileNo : "-"}</Text>
                    </View>
                    <View style={styles.sectionItems}>
                        <Text style={styles.sectionItemTitle}>{t('emailId')}</Text>
                        <Text style={styles.sectionItemValue}>{checkStringNullOrEmpty(DsrDetails?.emailId) ? DsrDetails?.emailId.toLowerCase() : '-'}</Text>
                    </View>
                    <View style={styles.sectionItems}>
                        <Text style={styles.sectionItemTitle}>{t('aadharNo')}</Text>
                        <Text style={styles.sectionItemValue}>{checkStringNullOrEmpty(DsrDetails?.aadhaarNo) ? DsrDetails?.aadhaarNo : "-"}</Text>
                    </View>

                </View>

                {/* Associated Retailers */}
                <View
                    style={
                        [styles.section,
                            // { maxHeight: '50%' }
                        ]}>
                    <Text style={styles.SectionTitle}>{t('associatedRetailers')}</Text>

                    {/* <ScrollView nestedScrollEnabled> */}
                    <FlatList
                        showsVerticalScrollIndicator={false}
                        data={profileDetail?.retailers}
                        onEndReachedThreshold={.7}
                        ListEmptyComponent={
                            <View style={styles.noAssociatedRetailersArea}>
                                <Text style={styles.noAssociatedRetailers}>{t('noAssociatedRetailers')}</Text>
                            </View>
                        }
                        renderItem={({ item }) => renderedItem(item)}
                        keyExtractor={item => item?.distributor?.distributorCode.toString()}
                    />
                    {/* </ScrollView> */}
                </View>
                {/* No bank Details */}
            </ScrollView>
            {/* <CameraOptionsModal
                isOpen={isMenuOpen}
                onClose={toggleMenu}
                fromCamera={clickFromCamera}
                fromGallery={chooseFromGallery}
            /> */}
            <Loader isOpen={isLoader} />
        </View>
    )
}

export default DsrProfile