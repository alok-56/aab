import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    Modal,
    FlatList,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    Button
} from 'react-native';
import banks from './banks.json'; // Adjust the path as necessary
import * as config from '../../../config/index'

const BankListModal = ({ visible, onClose, onBankSelected, selectedBank, search, setSearch }: any) => {
    const [filteredBanks, setFilteredBanks] = useState(banks);

    useEffect(() => {
        setFilteredBanks(
            banks.filter(bank =>
                bank.name.toLowerCase().includes(search.toLowerCase())
            )
        );
    }, [search]);

    useEffect(() => {
        setSearch('')
    }, [])


    return (
        <Modal
            visible={visible}
            // animationType="slide"
            transparent={true}
            onRequestClose={onClose}
        >
            <View style={styles.modalContainer}>
                <View style={styles.modalContent}>
                    <View style={styles.titleView}>
                        <Text style={{
                            color: '#fff',
                            fontWeight: '600',
                            fontSize: 15,
                            textAlign: 'center'
                        }}>{'Select a bank'}</Text>
                    </View>
                    <TextInput
                        // style={styles.searchInput}
                        style={[config.AppStyle.AppStyle.inputField, { width: '85%' }]}
                        placeholder="Search for a bank..."
                        value={search}
                        onChangeText={setSearch}
                    />
                    <FlatList
                        showsVerticalScrollIndicator={false}
                        data={filteredBanks}
                        keyExtractor={(item) => item.id.toString()}
                        renderItem={({ item }) => (
                            <TouchableOpacity style={styles.bankItem} onPress={() => onBankSelected(item)}>
                                <Text style={[styles.bankName, { color: selectedBank?.id == item?.id ? config.fontAttribute.themeColor : 'grey' }]}>{item.name}</Text>
                            </TouchableOpacity>
                        )}
                    />
                    <TouchableOpacity activeOpacity={0.6} onPress={onClose} style={{ width: '100%', marginTop: 10 }}>
                        <View style={styles.cancelButtonView}>
                            <Text style={{ color: config.fontAttribute.TextColor1, fontWeight: '500' }}>{'Cancel'}</Text>
                        </View>
                    </TouchableOpacity>
                    {/* <Button title="Close" onPress={onClose} /> */}
                </View>
            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    modalContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalContent: {
        width: '90%',
        backgroundColor: 'white',
        paddingTop: 20,
        borderRadius: 10,
        alignItems: 'center',
        maxHeight: '80%'
    },
    title: {
        fontSize: 18,
        marginBottom: 10
    },
    searchInput: {
        width: '85%',
        padding: 10,
        borderWidth: 1,
        borderColor: '#ccc',
        marginBottom: 20,
        borderRadius: 5
    },
    bankItem: {
        padding: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc',
        // width: '100%'
    },
    bankName: {
        fontSize: 14,
        fontWeight: '500',
        textAlign: 'center'
    },
    titleView: {
        backgroundColor: config.fontAttribute.themeColor,
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        padding: 15,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: -20,
        marginBottom: 20,
        width: '100%',
    },
    cancelButtonView: {
        paddingVertical: 15,
        // width:'100%',
        justifyContent: 'center',
        alignItems: 'center',
        borderTopColor: 'gray',
        borderTopWidth: 0.5
    }
});

export default BankListModal;
