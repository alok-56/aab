import { StyleSheet } from "react-native";
import * as config from '../../../config/index'

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: config.fontAttribute.whiteColor,
        // margin: 10,
        borderRadius: 10,
        padding: 20,
    },
    absoluteIcon: {
        position: 'absolute',
        bottom: 27,
        right: 15
    },
    errorMessage: {
        color: 'red', fontWeight: '400', fontSize: config.fontAttribute.labelFontSizeMedium
    },
    buttons: {
        flex: 1, marginHorizontal: 5
    },
    headLineText:
        { fontSize: 12, marginVertical: 5, letterSpacing: 1, color: config.fontAttribute.themeColor },
    borderCard:
    {
        borderWidth: 1,
        borderColor: 'rgba(102,112,133,0.1)',
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 10,
        marginVertical: 10
    },
    attachmentArea: {
        borderWidth: 2,
        borderColor: '#ced4da',
        borderStyle: 'dashed',
        borderRadius: 10,
        margin: 10
    },
    addButton: {
        tintColor: config.fontAttribute.themeColor,
        width: 20,
        height: 20
    },
    attachmentImageView: {
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        margin: 5,
        overflow: 'hidden'
    },
    attachmentCrossIcon: {
        borderRadius: 100,
        borderColor: config.fontAttribute.themeColor,
        borderWidth: 1,
        padding: 2
    },
    withoutAttachmentView: {
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%'
    },
    downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 20
    },


})

export default styles;