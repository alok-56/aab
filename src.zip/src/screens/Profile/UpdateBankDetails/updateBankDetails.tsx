import { Formik, FormikProps } from 'formik';
import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  ActivityIndicator,
  Alert,
  Image,
  Keyboard,
  PermissionsAndroid,
  Platform,
  ScrollView,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import { pick } from '@react-native-documents/picker';
import { showMessage } from 'react-native-flash-message';
import { launchCamera } from 'react-native-image-picker';
import { SvgXml } from 'react-native-svg';
import { shallowEqual, useSelector } from 'react-redux';
import * as Yup from 'yup';
import {
  EditRetailerBankDetails,
  GetRetailerBankDetails,
} from '../../../ApiServices/httpServices';
import { Headercomponent } from '../../../Components';
import ConfirmationPopup from '../../../Components/ConfirmationPopup/ConfirmationPopup';
import { formatFileSize } from '../../../config/GlobalVariable';
import * as config from '../../../config/index';
import CameraOptionsModal from '../modal';
import BankListModal from './BanksListPopup';
import Formik_Text_Input_UpdateBankDetails, {
  RedStar,
} from './Formik_Text_Input_UpdateBankDetails';
import styles from './style';

const UpdateBankDetails = (props: any) => {
  const { navigation } = props;
  const { t, i18n } = useTranslation();
  const [isLoader, setIsLoader] = useState(false);
  const [bankProofAttachment, setBankProofAttachment] = useState<any>(null);
  const [GSTINProofAttachment, setGSTINProofAttachment] = useState<any>(null);
  const [PanNumberProofAttachment, setPanNumberProofAttachment] =
    useState<any>(null);
  const [selectedBank, setSelectedBank] = useState<any>(null);
  const [valuesTosubmit, setValuesToSubmit] = useState<any>(null);
  const [isConformationPopup, setIsConformationPopup] = useState(false);
  const [isModalVisible, setModalVisible] = useState(false);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [ViewDetail, setViewDetails] = useState<any>(null);
  const [isImageMenuOpen, setIsImageMenyOpen] = useState(false);
  const [typeOfFileUploading, setTypeOfFileUploading] = useState('');

  const toggleImageMenu = () => {
    setIsImageMenyOpen(!isImageMenuOpen);
  };
  const lodggedInUser = useSelector(
    (state: any) => state.auth.userData,
    shallowEqual,
  );

  useEffect(() => {
    if (props?.route?.params?.isView) {
      FetchBankDetails();
    }
  }, []);

  const checkForPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return true;
      } else {
        return false;
      }
    } catch (err) {
      return false;
      console.warn(err);
    }
  };
  // useEffect(() => {
  //     if (ViewDetail && formRef.current) {
  //         formRef.current.setValues({
  //             AccountHolderName: ViewDetail?.AccountHolderName || '',
  //             BankName: ViewDetail?.BankName || '',
  //             AccountNumber: ViewDetail?.BankAccountNo || '',
  //             ConfirmAccountNumber: ViewDetail?.BankAccountNo || '',
  //             IFSCCode: ViewDetail?.IFSCCode || '',
  //             GSTIN: ViewDetail?.GSTIN || '',
  //             PanNumber: ViewDetail?.PANNo || '',
  //         });
  //     }
  // }, [ViewDetail]);
  const FetchBankDetails = () => {
    const params = {
      FromDate: '',
      ToDate: '',
      Status: 'Sent For Approval',
      RetailerCode: lodggedInUser?.retailerCode || lodggedInUser?.userName,
      SearchText: '',
      PageNumber: 1,
      PageSize: 10,
      GetAll: false,
    };
    GetRetailerBankDetails(params)
      .then(result => {
        setViewDetails(result?.details?.[0]);
        console.log(result, 'GetBankDetails');
        if (result && result?.details?.[0] && formRef.current) {
          formRef.current.setValues({
            AccountHolderName: result?.details?.[0]?.AccountHolderName || '',
            BankName: result?.details?.[0]?.BankName || '',
            AccountNumber: result?.details?.[0]?.BankAccountNo || '',
            ConfirmAccountNumber: result?.details?.[0]?.BankAccountNo || '',
            IFSCCode: result?.details?.[0]?.IFSCCode || '',
            GSTIN: result?.details?.[0]?.GSTIN || '',
            PanNumber: result?.details?.[0]?.PANNo || '',
          });
          setBankProofAttachment({ name: result?.details?.[0]?.BankProof });
          setGSTINProofAttachment({ name: result?.details?.[0]?.GstinProof });
          setPanNumberProofAttachment({ name: result?.details?.[0]?.PanProof });
        }
      })
      .catch(err => {
        console.log(err, 'GetBankDetails');
      });
  };

  const attachment = {
    BankProofAttachment: 'BankProofAttachment',
    GSTINProofAttachment: 'GSTINProofAttachment',
    PanNumberProofAttachment: 'PanNumberProofAttachment',
  };

  const onSaveButtonClicked = (values: any, errors: any) => {
    // console.log(selectedBank)
    setValuesToSubmit(values);
    // console.log('values', values);
    setIsConformationPopup(true);
  };
  const UpdateBankDetailsFunc = () => {
    console.log(bankProofAttachment);
    
    setIsLoading(true);
    console.log(
      valuesTosubmit,
      selectedBank?.name,
      bankProofAttachment,
      GSTINProofAttachment,
      PanNumberProofAttachment,
    );
    const params = new FormData();
    params.append('RetailerCode', lodggedInUser?.retailerCode || lodggedInUser?.userName);
    params.append('AccountHolderName', valuesTosubmit?.AccountHolderName);
    params.append('BankAccountNo', valuesTosubmit?.AccountNumber);
    params.append(
      'BankName',
      selectedBank?.id == 0 ? valuesTosubmit?.BankName : selectedBank?.name,
    );
    params.append('IFSCCode', valuesTosubmit?.IFSCCode);
    params.append('GSTIN', valuesTosubmit?.GSTIN || '');
    params.append('PANNo', valuesTosubmit?.PanNumber || '');
    params.append('BankProof', bankProofAttachment || null);
    params.append('GstinProof', GSTINProofAttachment || null);
    params.append('PanProof', PanNumberProofAttachment || null);
    console.log(params);
    setIsConformationPopup(false);
    EditRetailerBankDetails(params)
      .then(result => {
        setIsLoading(false);
        console.log(result, 'Edit Retailer Result');
        if (result) {
          showMessage({
            message: 'Request sent successfully.',
            duration: 1000,
            color: 'white',
            backgroundColor: 'green',
          });
          navigation.goBack();
        }
      })
      .catch(err => {
        setIsLoading(false);
        showMessage({
          message: 'Failed to update bank details.',
          duration: 1000,
          color: 'white',
          backgroundColor: 'red',
        });
        console.log(err, 'Edit Retailer Error');
      });
  };

  const onUploadDocumentClicked = (type: any) => {
    console.log('I am here for pick file');
    setTypeOfFileUploading(type);
    toggleImageMenu();
    // PickFile(type);
  };

  const onBankSelected = (bank: any) => {
    setModalVisible(false);
    console.log('selected Bank', bank);
    setSelectedBank(bank);
  };

  const chooseFromGallery = async () => {
    PickFile();
    toggleImageMenu();
  };
  const clickFromCamera = async () => {
    // let options: any = {}
    if (Platform.OS == 'android') {
      PermissionsAndroid.check('android.permission.CAMERA').then(response => {
        if (response === true) {
          openCamera();
          toggleImageMenu();
        } else if (response === false) {
          console.log(false);
          checkForPermission().then(response => {
            openCamera();
          });
        }
      });
    } else {
      openCamera();
    }
    // const permission = checkForPermission();
    // console.log(permission)
  };
  function updateImageObject(imageObject: any) {
    // Destructure the original object and rename the keys
    const updatedObject = {
      ...imageObject,
      name: imageObject.fileName, // Rename fileName to name
      size: imageObject.fileSize, // Rename fileSize to size
    };

    // Remove the original keys: fileName and fileSize
    delete updatedObject.fileName;
    delete updatedObject.fileSize;

    return updatedObject;
  }
  const openCamera = () => {
    console.log('open camera');
    // setTimeout(() => {
    //   ImagePicker.openCamera({
    //     width: 300,
    //     height: 400,
    //     cropping: true,
    //   })
    //     .then(image => {
    //       console.log(image, 'camera image');
    //       let s: SetStateAction<string> | null = '';
    //       s = image?.path ? image?.path : '';
    //       let updatedImageObject = {
    //         ...image,
    //         name: image.path?.split('/')[image.path?.split('/').length - 1],
    //       };
    //       switch (typeOfFileUploading) {
    //         case attachment.BankProofAttachment:
    //           setBankProofAttachment(updatedImageObject);
    //           break;
    //         case attachment.GSTINProofAttachment:
    //           setGSTINProofAttachment(updatedImageObject);
    //           break;
    //         case attachment.PanNumberProofAttachment:
    //           setPanNumberProofAttachment(updatedImageObject);
    //           break;
    //         default:
    //           break;
    //       }
    //     })
    //     .catch((error: any) => {
    //       console.log(error);
    //     });
    // }, 100);
    const options: any = {
      mediaType: 'photo',
      maxWidth: 1024,
      maxHeight: 1024,
      quality: 0.8, // Set quality between 0 (low) and 1 (high)
      includeBase64: false,
    };

    // const handleCapture = async () => {
    launchCamera(options, response => {
      if (response.didCancel) {
        // Alert.alert('Cancelled', 'User cancelled the image picker.');
      } else if (response.errorCode) {
        // Alert.alert('Error', `Image picker error: ${response.errorMessage}`);
      } else if (response.assets) {
        const fileType = response.assets[0].type; // Check file type
        if (fileType === 'image/jpeg' || fileType === 'image/png') {
          console.log(response, 'from camera');
          switch (typeOfFileUploading) {
            case attachment.BankProofAttachment:
              setBankProofAttachment(updateImageObject(response?.assets[0]));
              break;
            case attachment.GSTINProofAttachment:
              setGSTINProofAttachment(updateImageObject(response?.assets[0]));
              break;
            case attachment.PanNumberProofAttachment:
              setPanNumberProofAttachment(
                updateImageObject(response?.assets[0]),
              );
              break;
            default:
              break;
          }
        } else {
          Alert.alert('Invalid Format', 'Please select a JPEG or PNG image.');
        }
      }
    });
    toggleImageMenu();
  };
  const PickFile = () => {
    pick({ type: ['application/pdf', 'image/*'] })
      .then((result: any) => {
        console.log('picked file', result);
        if (result) {
          switch (typeOfFileUploading) {
            case attachment.BankProofAttachment:
              setBankProofAttachment(result);
              break;
            case attachment.GSTINProofAttachment:
              setGSTINProofAttachment(result);
              break;
            case attachment.PanNumberProofAttachment:
              setPanNumberProofAttachment(result);
              break;
            default:
              break;
          }
        }
      })
      .catch((err: any) => {
        console.log('Error Picking file', err);
      });
  };

  const onAttachmentCrossButtonClicked = (type: any) => {
    switch (type) {
      case attachment.BankProofAttachment:
        setBankProofAttachment(null);
        break;
      case attachment.GSTINProofAttachment:
        setGSTINProofAttachment(null);
        break;
      case attachment.PanNumberProofAttachment:
        setPanNumberProofAttachment(null);
        break;
      default:
        break;
    }
  };

  const UpdateBankDetailsSchema = Yup.object().shape({
    AccountHolderName: Yup.string().required(
      t('Account Holder name is required'),
    ),
    BankName:
      selectedBank?.id == 0
        ? Yup.string().required(t('Bank name is required'))
        : Yup.string(),
    AccountNumber: Yup.string()
      .required(t('Account Number is required'))
      // .matches(/^\d{4}-\d{4}-\d{4}$/, t('Invalid format'))
      .min(8, ({ min }) => t(`Must be at least ${min} characters`))
      .max(20, ({ max }) => t(`Must be at least ${max} characters`)),
    ConfirmAccountNumber: Yup.string()
      .required(t('This field is required'))
      // .matches(/^\d{4}-\d{4}-\d{4}$/, t('Invalid format'))
      .min(8, ({ min }) => t(`Must be at least ${min} characters`))
      .max(20, ({ max }) => t(`Must be at least ${max} characters`))
      .oneOf([Yup.ref('AccountNumber')], t('Account Number mismatch')),
    IFSCCode: Yup.string()
      .required(t('IFSC is required'))
      .matches(/^[A-Z]{4}0[A-Z0-9]{6}$/, t('Invalid format')),
    // GSTIN: Yup.string()
    //     .required(t('GSTIN is required'))
    //     .matches(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/, t('Invalid format')),
    // PanNumber: Yup.string()
    //     .required(t('Pan Number is required'))
    //     .matches(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, t('Invalid format')),
  });

  interface MyFormValues {
    AccountHolderName: string;
    BankName: string;
    AccountNumber: string;
    ConfirmAccountNumber: string;
    IFSCCode: string;
    GSTIN: string;
    PanNumber: string;
  }

  const formRef = useRef<FormikProps<MyFormValues>>(null);

  return (
    <TouchableWithoutFeedback
      onPress={() => {
        Keyboard.dismiss();
      }}
    >
      <>
        <Headercomponent type={'2'} name={t('Update Bank Details')} />
        <View style={styles.container}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <Formik
              innerRef={formRef}
              enableReinitialize
              initialValues={{
                AccountHolderName: ViewDetail?.AccountHolderName || '',
                BankName: ViewDetail?.BankName,
                AccountNumber: ViewDetail?.BankAccountNo || '',
                ConfirmAccountNumber: ViewDetail?.BankAccountNo || '',
                IFSCCode: ViewDetail?.IFSCCode || '',
                GSTIN: ViewDetail?.GSTIN || '',
                PanNumber: ViewDetail?.PANNo || '',
              }}
              onSubmit={(values, errors) => {
                onSaveButtonClicked(values, errors);
              }}
              validationSchema={UpdateBankDetailsSchema}
            >
              {({
                values,
                errors,
                touched,
                handleChange,
                handleBlur,
                handleSubmit,
                setFieldTouched,
                isSubmitting,
                isValid,
                handleReset,
                setFieldValue,
              }) => (
                <View style={{ flex: 1 }}>
                  {/* Account Holder Name */}
                  <Formik_Text_Input_UpdateBankDetails
                    touched={touched.AccountHolderName}
                    errors={errors.AccountHolderName}
                    values={values.AccountHolderName}
                    onChangeText={(text: any) => {
                      handleChange('AccountHolderName')(text);
                      setFieldTouched('AccountHolderName', true, false);
                    }}
                    labelText={t('accountHolderName')}
                    editable={!props?.route?.params?.isView}
                  />

                  {/* Account Number */}
                  <Formik_Text_Input_UpdateBankDetails
                    numericKeyboard={true}
                    touched={touched.AccountNumber}
                    errors={errors.AccountNumber}
                    values={values.AccountNumber}
                    onChangeText={(text: any) => {
                      handleChange('AccountNumber')(text);
                      setFieldTouched('AccountNumber', true, false);
                    }}
                    labelText={t('accountNumber')}
                    isPassword={true}
                    // isAccountNumber={true}
                    maxCharacters={16}
                    editable={!props?.route?.params?.isView}
                  />

                  {/* Confirm Account Number */}
                  <Formik_Text_Input_UpdateBankDetails
                    numericKeyboard={true}
                    touched={touched.ConfirmAccountNumber}
                    errors={errors.ConfirmAccountNumber}
                    values={values.ConfirmAccountNumber}
                    onChangeText={(text: any) => {
                      handleChange('ConfirmAccountNumber')(text);
                      setFieldTouched('ConfirmAccountNumber', true, false);
                    }}
                    labelText={t('confirmAccountNumber')}
                    maxCharacters={16}
                    editable={!props?.route?.params?.isView}
                    // isAccountNumber={true}
                  />

                  {/* Select Bank */}
                  {/* <Text style={config.AppStyle.AppStyle.inputLabel}>
                                        {t('Select Bank')}<RedStar />
                                    </Text>
                                    <TouchableOpacity onPress={() => { setModalVisible(true); setSearch('') }} activeOpacity={1}>
                                        <View style={config.AppStyle.AppStyle.inputField} >
                                            <TextInput
                                                style={{ color: config.fontAttribute.TextColor1 }}
                                                placeholder={t('Select Bank')}
                                                placeholderTextColor={config.fontAttribute.placeholderColor}
                                                editable={false}
                                                value={selectedBank?.name}
                                            />                                          
                                            <Image style={styles.downArrow} source={config.Images.DownArrow} />
                                        </View>
                                    </TouchableOpacity> */}
                  {!props?.route?.params?.isView && (
                    <TouchableOpacity
                      onPress={() => {
                        setModalVisible(true);
                        setSearch('');
                      }}
                      activeOpacity={1}
                    >
                      <Formik_Text_Input_UpdateBankDetails
                        touched={touched.BankName}
                        errors={errors.BankName}
                        values={selectedBank?.name}
                        onChangeText={(text: any) => {
                          handleChange('BankName')(text);
                          setFieldTouched('BankName', true, false);
                          // setFieldValue('BankName', text)
                        }}
                        labelText={t('Select Bank')}
                        isDropdown={true}
                        editable={false}
                      />
                    </TouchableOpacity>
                  )}

                  {/* Bank Name */}
                  {(selectedBank?.id == 0 || props?.route?.params?.isView) && (
                    <Formik_Text_Input_UpdateBankDetails
                      touched={touched.BankName}
                      errors={errors.BankName}
                      values={values.BankName}
                      onChangeText={(text: any) => {
                        handleChange('BankName')(text);
                        setFieldTouched('BankName', true, false);
                      }}
                      labelText={t('bankName')}
                      editable={!props?.route?.params?.isView}
                    />
                  )}

                  {/* IFSC Code */}
                  <Formik_Text_Input_UpdateBankDetails
                    touched={touched.IFSCCode}
                    errors={errors.IFSCCode}
                    values={values.IFSCCode}
                    onChangeText={(text: any) => {
                      handleChange('IFSCCode')(text);
                      setFieldTouched('IFSCCode', true, false);
                    }}
                    labelText={t('IFSC')}
                    autoCapitalize={true}
                    editable={!props?.route?.params?.isView}
                  />

                  {/* Bank Proof Attachment */}
                

                  {/* GSTIN */}
                  <Formik_Text_Input_UpdateBankDetails
                    touched={touched.GSTIN}
                    errors={errors.GSTIN}
                    values={values.GSTIN}
                    onChangeText={(text: any) => {
                      handleChange('GSTIN')(text);
                      setFieldTouched('GSTIN', true, false);
                    }}
                    labelText={t('GSTIN')}
                    autoCapitalize={true}
                    required={true}
                    editable={!props?.route?.params?.isView}
                  />

                  {/* GSTIN Proof Attachment */}
                  <AttachmentUI
                    required={false}
                    labelText={'GSTIN Proof'}
                    t={t}
                    attachment={GSTINProofAttachment}
                    onUploadDocumentClicked={onUploadDocumentClicked}
                    onAttachmentCrossButtonClicked={
                      onAttachmentCrossButtonClicked
                    }
                    attachmentType={attachment.GSTINProofAttachment}
                    isView={props?.route?.params?.isView} // Pass the isView prop based on the mode
                  />

                  {/* Pan Card Number */}
                  <Formik_Text_Input_UpdateBankDetails
                    touched={touched.PanNumber}
                    errors={errors.PanNumber}
                    values={values.PanNumber}
                    onChangeText={(text: any) => {
                      handleChange('PanNumber')(text);
                      setFieldTouched('PanNumber', true, false);
                    }}
                    labelText={t('panNumber')}
                    autoCapitalize={true}
                    required={true}
                    editable={!props?.route?.params?.isView}
                  />

                  {/* Pan Card Proof Attachment */}
                  <AttachmentUI
                    required={false}
                    labelText={'Pan Number Proof'}
                    t={t}
                    attachment={PanNumberProofAttachment}
                    onUploadDocumentClicked={onUploadDocumentClicked}
                    onAttachmentCrossButtonClicked={
                      onAttachmentCrossButtonClicked
                    }
                    attachmentType={attachment.PanNumberProofAttachment}
                    isView={props?.route?.params?.isView} // Pass the isView prop based on the mode
                  />
                </View>
              )}
            </Formik>
          </ScrollView>

          {!props?.route?.params?.isView && (
            <View style={{ flexDirection: 'row', marginTop: 20 }}>
              <TouchableOpacity
                onPress={() => {
                  navigation.goBack();
                }}
                style={[
                  config.AppStyle.AppStyle.button2,
                  styles.buttons,
                  { marginTop: 0 },
                ]}
                activeOpacity={0.8}
              >
                <Text style={config.AppStyle.AppStyle.buttonText2}>
                  {t('cancel')}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  formRef?.current?.submitForm();
                }}
                style={[
                  config.AppStyle.AppStyle.button,
                  styles.buttons,
                  {
                    marginTop: 0,
                    flexDirection: 'row',
                    justifyContent: 'center',
                    alignItems: 'center',
                  },
                ]}
                activeOpacity={0.8}
              >
                <Text style={config.AppStyle.AppStyle.buttonText}>
                  {t('Submit')}
                </Text>
                {isLoader && (
                  <ActivityIndicator
                    size={15}
                    color={config.fontAttribute.whiteColor}
                    style={{ marginLeft: 5 }}
                  />
                )}
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Bank list Popup */}
        <BankListModal
          visible={isModalVisible}
          onClose={() => setModalVisible(false)}
          onBankSelected={(e: any) => onBankSelected(e)}
          selectedBank={selectedBank}
          search={search}
          setSearch={setSearch}
        />

        {/* Confirmation Popup */}
        <ConfirmationPopup
          isLoading={isLoading}
          isOpen={isConformationPopup}
          onClose={() => setIsConformationPopup(false)}
          onConfirmButtonClicked={UpdateBankDetailsFunc}
          message={t('Are you sure, you want to update your bank details.')}
          button1Title={t('Submit')}
          button2Title={t('no')}
          isconfirmation={true}
        />

        <CameraOptionsModal
          isOpen={isImageMenuOpen}
          onClose={toggleImageMenu}
          fromCamera={clickFromCamera}
          fromGallery={chooseFromGallery}
        />
      </>
    </TouchableWithoutFeedback>
  );
};

export default UpdateBankDetails;

const AttachmentUI = (props: any) => {
  const {
    labelText,
    t,
    attachment,
    onUploadDocumentClicked,
    onAttachmentCrossButtonClicked,
    attachmentType,
    required = true,
    isView = false, // Add isView prop to differentiate between view and edit modes
  } = props;

  return (
    <>
      <Text style={config.AppStyle.AppStyle.inputLabel}>
        {t(labelText)}
        {required && <RedStar />}
      </Text>
      {/* If in view mode, only show the name of the attachment */}
      {isView ? (
        attachment ? (
          <View style={styles.attachmentArea}>
            <View
              style={{
                margin: 10,
                paddingVertical: 5,
                paddingHorizontal: 10,
                backgroundColor: '#EAF4FF',
                borderWidth: 1,
                borderRadius: 10,
                borderColor: '#DEEEFF',
                flexDirection: 'row',
                alignItems: 'center',
              }}
            >
              <Text
                style={{
                  maxWidth: '100%',
                  flex: 1,
                  fontSize: config.fontAttribute.labelFontSizeMedium,
                  color: 'black',
                  fontWeight: '300',
                }}
              >
                {attachment?.name || t('No Attachment')}
              </Text>
            </View>
          </View>
        ) : (
          <Text style={{ color: 'gray', fontSize: 14 }}>
            {t('No Attachment')}
          </Text>
        )
      ) : (
        // If not in view mode, show the upload option
        <TouchableOpacity
          activeOpacity={1}
          onPress={() => !attachment && onUploadDocumentClicked(attachmentType)}
        >
          <View
            style={[
              styles.attachmentArea,
              { height: attachment ? 'auto' : 80 },
            ]}
          >
            {attachment ? (
              <View
                style={{
                  margin: 10,
                  paddingVertical: 5,
                  paddingHorizontal: 10,
                  backgroundColor: '#EAF4FF',
                  borderWidth: 1,
                  borderRadius: 10,
                  borderColor: '#DEEEFF',
                  flexDirection: 'row',
                  alignItems: 'center',
                }}
              >
                <Image
                  source={config.Images.file}
                  style={{ width: 25, height: 25, marginRight: 10 }}
                />
                <Text
                  style={{
                    maxWidth: '100%',
                    flex: 1,
                    fontSize: config.fontAttribute.labelFontSizeMedium,
                    color: 'black',
                    fontWeight: '300',
                  }}
                >
                  {attachment?.name}
                  <Text
                    style={{
                      fontSize: config.fontAttribute.labelFontSizeSmall,
                      color: 'gray',
                    }}
                  >
                    {' '}
                    ({formatFileSize(attachment?.size)})
                  </Text>
                </Text>
                <TouchableOpacity
                  style={{ padding: 10 }}
                  onPress={() => onAttachmentCrossButtonClicked(attachmentType)}
                >
                  <SvgXml xml={config.svgs.crossBlue} height={10} width={10} />
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.withoutAttachmentView}>
                <TouchableOpacity
                  activeOpacity={0.8}
                  onPress={() => onUploadDocumentClicked(attachmentType)}
                >
                  <Image
                    style={styles.addButton}
                    source={config.Images.addCircleBlack}
                  />
                </TouchableOpacity>
                <Text
                  style={{
                    color: config.fontAttribute.TextColor1,
                    fontSize: 12,
                  }}
                >
                  {t('uploadDocument')}
                </Text>
              </View>
            )}
          </View>
        </TouchableOpacity>
      )}
    </>
  );
};
