import { View, Text, TextInput, Image } from 'react-native';
import React, { useEffect, useState } from 'react';
import * as config from '../../../config/index';
import { SvgXml } from 'react-native-svg';
import { useTranslation } from 'react-i18next';

const Formik_Text_Input_UpdateBankDetails = (props: any) => {
  const { touched, errors, values, onChangeText, labelText, maxCharacters, editable, required, numericKeyboard, autoCapitalize, isPassword, isAccountNumber, isDropdown } = props;
  const { t, i18n } = useTranslation();
  const [requiredField, setRequiredField] = useState(true);
  const [accountNumber, setAccountNumber] = useState('');

  useEffect(() => {
    if (required === false) {
      setRequiredField(false);
    }
  }, []);

  const handleAccountNumberChange = (input: any) => {
    const cleanedInput = input.replace(/\D/g, ''); // Remove non-digit characters
    const formattedInput = formatAccountNumber(cleanedInput);
    setAccountNumber(formattedInput);
    onChangeText(formattedInput);
  };

  const formatAccountNumber = (input: any) => {
    const groups = input.match(/.{1,4}/g); // Match groups of 1 to 4 digits
    return groups ? groups.join('-') : '';
  };

  return (
    <>
      <Text style={config.AppStyle.AppStyle.inputLabel}>
        {t(labelText)}{!required && <RedStar />}
      </Text>
      <View style={[config.AppStyle.AppStyle.inputField, {
        borderColor: (isDropdown && values != null)
          ? '#ced4da'
          : (touched && errors ? 'red' : '#ced4da')
      }]}>
        <TextInput
          placeholderTextColor={config.fontAttribute.placeholderColor}
          selectionColor={config.fontAttribute.cursorColor}
          keyboardType={numericKeyboard ? 'numeric' : undefined}
          editable={editable}
          maxLength={maxCharacters}
          style={{ flex: 1, color: config.fontAttribute.textInputValueColor }}
          value={isAccountNumber ? accountNumber : values}
          onChangeText={(text) => isAccountNumber ? handleAccountNumberChange(text) : onChangeText(text)}
          placeholder={isAccountNumber ? 'XXXX-XXXX-XXXX' : t(labelText)}
          autoCapitalize={autoCapitalize ? "characters" : undefined}
          secureTextEntry={isPassword}
        />
        {
          isDropdown ? (
            <Image style={{
              position: 'absolute',
              right: 15,
              bottom: 20
            }} source={config.Images.DownArrow} />
          ) : (
            touched && errors ? (
              <SvgXml xml={config.svgs.errorIcon} height={18} width={18} />
            ) : (
              <></>
            )
          )
        }

      </View>

      {
        (isDropdown && values != null)
          ? <></>
          : (touched && errors && (
            <Text style={config.AppStyle.AppStyle.errorMessage}>{errors}</Text>
          ))
      }
    </>
  );
};

export default Formik_Text_Input_UpdateBankDetails;

export const RedStar = () => {
  return (
    <View>
      <Text style={{ color: 'red' }}>*</Text>
    </View>
  );
};
