import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert, TouchableWithoutFeedback, Keyboard, Image, ActivityIndicator } from 'react-native'
import React, { useState } from 'react'
import { Headercomponent } from '../../Components'
import * as config from '../../config/index'
import styles from './style'
import { useTranslation } from 'react-i18next'
import TextInputWithError, { ErrorMessage } from '../../Components/TextInputWithError'
import { showMessage } from 'react-native-flash-message'
import { Formik } from 'formik';
import * as Yup from 'yup'
import { SvgXml } from 'react-native-svg'
import { ChangePasswordApi } from '../../ApiServices/httpServices'
import { result } from 'lodash'
import { IuserPorfileDto } from '../../AppModel/UserProfileModel'
import { shallowEqual, useSelector } from 'react-redux'

const ChangePassword = (props: any) => {

    const { navigation } = props;
    const { t, i18n } = useTranslation();
    const [isLoader, setIsLoader] = useState(false);

    const profileDetail: IuserPorfileDto = useSelector(
        (state: any) => state.auth.profileData,
        shallowEqual,
    );
    const onChangePasswordClicked = (values: any) => {
        setIsLoader(true);
        console.log(values)
        changePassword(values);
    }
    const changePassword = (values: any) => {
        const params = {
            DMSUSerId: profileDetail?.profile?.profileId,
            // DMSUSerId: 1,
            OldPassword: values.currentPassword,
            NewPassword: values.newPassword,
            ReNewPassword: values.confirmNewPassword
        }
        console.log("Change pass Params", params)
        ChangePasswordApi(params).then((result) => {
            console.log("change password", result)
            if (result) {
                setIsLoader(false);
                navigation.goBack();
            }
        }).catch((err: any) => {
            showMessage({ message: err?.response?.data?.message, color: "white", duration: 3000, animated: true, backgroundColor: "red" })
            setIsLoader(false);
            console.log("error", err)
        })
    }

    const PasswordValidationSchema = Yup.object().shape({
        currentPassword: Yup
            .string()
            .required(t('requiredPasswordError'))
            // .min(6, ({ min }) => `Password must be at least ${min} characters`),
            .min(6, ({ min }) => t('passwordMinCharError')),
        newPassword: Yup
            .string()
            .required(t('requiredPasswordError'))
            // .min(6, ({ min }) => t('passwordMinCharError'))
            .matches(/^(?=.*[A-Za-z])(?=.*\d).{6,}$/, t('passwordMinCharErrorWithAlphaNumeric'))
            .notOneOf([Yup.ref('currentPassword')], t('newPasswordCantBeSameAsCurrent')),
        confirmNewPassword: Yup
            .string()
            .required(t('requiredPasswordError'))
            // .min(6, ({ min }) => t('passwordMinCharError'))
            .matches(/^(?=.*[A-Za-z])(?=.*\d).{6,}$/, "Password must be at least 7 characters long and include both letters and numbers.")
            .oneOf([Yup.ref('newPassword')], t('passwordMismatched'))
    })
    return (
        <TouchableWithoutFeedback onPress={() => { Keyboard.dismiss() }}>

            <View style={{ flex: 1 }}>
                <Headercomponent type={'2'} name={t('changePassword')} />
                <View style={styles.container}>
                    <View style={{ flex: 1 }}>
                        {/* Current Password */}
                        <Formik
                            initialValues={{ currentPassword: '', newPassword: '', confirmNewPassword: '' }}
                            onSubmit={values => onChangePasswordClicked(values)}
                            validationSchema={PasswordValidationSchema}
                        >
                            {({
                                values,
                                errors,
                                touched,
                                handleChange,
                                handleBlur,
                                handleSubmit,
                                setFieldTouched,
                                isSubmitting,
                                isValid,
                                handleReset
                                /* and other goodies */
                            }) => (
                                <View>

                                    {/* Current Password */}
                                    <Text style={config.AppStyle.AppStyle.inputLabel}>{t('currentPassword')}<RedStar /></Text>
                                    <View style={[config.AppStyle.AppStyle.inputField,
                                    { borderColor: touched.currentPassword && errors.currentPassword ? 'red' : '#ced4da' }
                                    ]}>
                                        <TextInput
                                            selectionColor={config.fontAttribute.cursorColor}
                                            style={{ flex: 1, color: config.fontAttribute.textInputValueColor }}
                                            value={values.currentPassword}
                                            onChangeText={(text) => {
                                                handleChange('currentPassword')(text); // Call the Formik handleChange
                                                setFieldTouched('currentPassword', true, false); // Set the field to touched without triggering validation
                                            }}
                                            placeholder={t('currentPassword')}
                                            placeholderTextColor={config.fontAttribute.placeholderColor}

                                        />
                                        {
                                            touched.currentPassword && errors.currentPassword
                                                ?
                                                <SvgXml xml={config.svgs.errorIcon} height={18} width={18} />
                                                :
                                                <></>
                                        }
                                    </View>
                                    {touched.currentPassword && errors.currentPassword && (
                                        <Text style={config.AppStyle.AppStyle.errorMessage}>{errors.currentPassword}</Text>
                                    )}

                                    {/* New Password */}
                                    <Text style={config.AppStyle.AppStyle.inputLabel}>{t('newPassword')}<RedStar /></Text>
                                    <View style={[config.AppStyle.AppStyle.inputField,
                                    { borderColor: touched.newPassword && errors.newPassword ? 'red' : '#ced4da' }
                                    ]}>
                                        <TextInput
                                            selectionColor={config.fontAttribute.cursorColor}
                                            style={{ flex: 1, color: config.fontAttribute.textInputValueColor }}
                                            value={values.newPassword}
                                            onChangeText={(text) => {
                                                handleChange('newPassword')(text); // Call the Formik handleChange
                                                setFieldTouched('newPassword', true, false); // Set the field to touched without triggering validation
                                            }}
                                            placeholder={t('newPassword')}
                                            placeholderTextColor={config.fontAttribute.placeholderColor}

                                        />
                                        {
                                            touched.newPassword && errors.newPassword
                                                ?
                                                <SvgXml xml={config.svgs.errorIcon} height={18} width={18} />
                                                :
                                                <></>
                                        }
                                    </View>
                                    {touched.newPassword && errors.newPassword && (
                                        <Text style={config.AppStyle.AppStyle.errorMessage}>{errors.newPassword}</Text>
                                    )}

                                    {/* Confirm new Password */}
                                    <Text style={config.AppStyle.AppStyle.inputLabel}>{t('confirmNewPassword')}<RedStar /></Text>
                                    <View style={[config.AppStyle.AppStyle.inputField,
                                    { borderColor: touched.confirmNewPassword && errors.confirmNewPassword ? 'red' : '#ced4da' }
                                    ]}>
                                        <TextInput
                                            selectionColor={config.fontAttribute.cursorColor}
                                            style={{ flex: 1, color: config.fontAttribute.textInputValueColor }}
                                            value={values.confirmNewPassword}
                                            onChangeText={(text) => {
                                                handleChange('confirmNewPassword')(text); // Call the Formik handleChange
                                                setFieldTouched('confirmNewPassword', true, false); // Set the field to touched without triggering validation
                                            }}
                                            placeholder={t('confirmNewPassword')}
                                            placeholderTextColor={config.fontAttribute.placeholderColor}
                                        />
                                        {
                                            touched.confirmNewPassword && errors.confirmNewPassword
                                                ?
                                                <SvgXml xml={config.svgs.errorIcon} height={18} width={18} />
                                                :
                                                <></>
                                        }
                                    </View>
                                    {touched.confirmNewPassword && errors.confirmNewPassword && (
                                        <Text style={config.AppStyle.AppStyle.errorMessage}>{errors.confirmNewPassword}</Text>
                                    )}

                                    {/* Change Password Button */}
                                    <TouchableOpacity
                                        // disabled={!isValid}
                                        onPress={() => { handleSubmit() }}
                                        style={[config.AppStyle.AppStyle.button,
                                            // { opacity: isValid ? 1 : 0.6 }
                                        ]}
                                        activeOpacity={0.8} >
                                        {
                                            isLoader ?
                                                <ActivityIndicator size="small" color={config.fontAttribute.whiteColor} /> :
                                                <Text style={config.AppStyle.AppStyle.buttonText}>{t('changePassword')}</Text>
                                        }
                                    </TouchableOpacity>
                                </View>
                            )}
                        </Formik>

                    </View>
                </View>
            </View>
        </TouchableWithoutFeedback>
    )
}

export default ChangePassword

const RedStar = () => {
    return (
        <View>
            <Text style={{ color: 'red' }}>*</Text>
        </View>
    )
}