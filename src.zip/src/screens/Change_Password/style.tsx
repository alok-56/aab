import { StyleSheet } from "react-native";
import * as config from '../../config/index'

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: config.fontAttribute.whiteColor,
        margin: 10,
        borderRadius: 10,
        padding: 20,
    },
    absoluteIcon: {
        position: 'absolute',
        bottom: 27,
        right: 15
    },
    errorMessage: {
        color: 'red', fontWeight: '400', fontSize: config.fontAttribute.labelFontSizeMedium
    }
})

export default styles;