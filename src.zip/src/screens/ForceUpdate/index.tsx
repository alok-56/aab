import { View, Text, StyleSheet, TouchableOpacity, Linking, Platform } from 'react-native'
import React from 'react'
import { Image } from 'react-native'
import * as config from '../../config/index'
import { useTranslation } from 'react-i18next'
import { pixelValue } from '../../config/GlobalVariable'

const ForceUpdate = () => {
  const { t, i18n } = useTranslation();

  const updateNowClicked = () => {
    Platform.OS == 'android' ?
      Linking.openURL('https://play.google.com/store/apps/details?id=com.finolex.retailer') :
      Linking.openURL('https://apps.apple.com/us/app/finolex-connect-retailer/id6477564222')
  }
  return (
    <View style={styles.container}>
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text style={styles.updateAvailableText}>{t('updateAvailable')}</Text>
        <Text style={styles.updateDescriptionText}>{t('updateMessage')}</Text>
      </View>
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Image
          source={require('../../Assets/images/downloadGif6.gif')}
          style={{ width: 100, height: 100 }}
        />
      </View>
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <TouchableOpacity style={config.AppStyle.AppStyle.button} activeOpacity={0.8} onPress={updateNowClicked}>
          <Text style={config.AppStyle.AppStyle.buttonText}>{t('updateNow')}</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}

export default ForceUpdate

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff', flex: 1, marginVertical: 5, borderRadius: 10, paddingHorizontal: 20
  },
  updateAvailableText: {
    color: config.fontAttribute.themeColor,
    fontWeight: '500',
    fontSize: config.fontAttribute.headingFontSizeLarge * pixelValue,
    letterSpacing: 1.5
  },
  updateDescriptionText: {
    color: config.fontAttribute.TextColor1,
    fontWeight: '300',
    fontSize: config.fontAttribute.labelFontSize * pixelValue,
    textAlign: 'center',
    letterSpacing: 0.5
  }
})