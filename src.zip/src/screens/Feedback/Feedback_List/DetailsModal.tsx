import { View, Text, Modal, TouchableOpacity, StyleSheet, FlatList, Image, Platform, PermissionsAndroid, ActivityIndicator } from 'react-native'
import React, { useState } from 'react'
import * as Icons from '../../../config/images'
import { ConvertDateFormat, capitalize, downloadFile, openDownloadedFile, pixelValue } from '../../../config/GlobalVariable'
import * as config from '../../../config/index'
import { checkStringNullOrEmpty } from '../../../config/GlobalVariable'
import { useTranslation } from 'react-i18next'
import { baseLinkURLComplain } from '../../../ApiServices/credential'
import { ScrollView } from 'react-native-gesture-handler'


const DetailModal = (props: any) => {
    const { t, i18n } = useTranslation();
    const { isOpen, onClose, feedbackDetail } = props;
    const [isDownloadLoader, setIsDownloadLoader] = useState(false)

    const checkForPermission = async () => {
        if (Platform.OS == 'android') {
            try {
                const granted = await PermissionsAndroid.request(
                    PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE
                );
                if (granted === PermissionsAndroid.RESULTS.GRANTED) {
                    return true
                } else {
                    return false
                }
            } catch (err) {
                return false
                console.warn(err);
            }
        } else {
            return true;
        }
    }
    const openAttachment = async (url: string, name: any) => {
        // console.log()

        // checkForPermission().then(async (response) => {
            setIsDownloadLoader(true)
            downloadFile(url, name, setIsDownloadLoader)
                .then(() => { })
                .catch((error) => console.error(error))
        // });
    }
    const [showFullResponse, setShowFullResponse] = useState(false)
    const [showFullComplain, setShowFullComplain] = useState(false)
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={config.AppStyle.AppStyle.ModalOuterCss}>
                    <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                        <View style={config.AppStyle.AppStyle.ModalCrossIcon}>
                            <Image source={Icons.cross} />
                        </View>
                    </TouchableOpacity>
                    <View style={[config.AppStyle.AppStyle.ModalInnerCss, { padding: 10 }]}>
                        <ScrollView showsVerticalScrollIndicator={false}>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('complainId')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(feedbackDetail?.id) ? feedbackDetail?.id : '-'}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('complainDate')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(feedbackDetail?.compainDate) ? ConvertDateFormat(feedbackDetail?.compainDate) : '-'}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('status')}</Text>
                                <Text style={styles.rowData}>{feedbackDetail?.isOpen ? 'Open' : 'Closed'}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('distributorId')}</Text>
                                <Text style={styles.rowData}>{feedbackDetail?.distributorCode == null ? '-' : feedbackDetail?.distributorCode}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('distributorName')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(feedbackDetail?.distributor?.distributorName) ? capitalize(feedbackDetail?.distributor?.distributorName) : '-'}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('complainMessage')}</Text>
                                {/* <Text style={styles.rowData}>{checkStringNullOrEmpty(feedbackDetail?.messageComplain) ? feedbackDetail?.messageComplain : '-'}</Text> */}
                                <View style={styles.viewMoreFunctionality}>
                                            <Text numberOfLines={showFullComplain ? undefined : 3} style={styles.rowData}>
                                                {checkStringNullOrEmpty(feedbackDetail?.messageComplain) ? feedbackDetail?.messageComplain : '-'}

                                                {showFullComplain && <Text onPress={() => setShowFullComplain(false)} style={[styles.nofileattached, { textAlign: 'left' }]} > View less
                                                </Text>}
                                            </Text>
                                            {!showFullComplain && <Text onPress={() => setShowFullComplain(true)} style={[styles.nofileattached,]}>
                                                View more
                                            </Text>}
                                        </View>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('complainType')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(feedbackDetail?.complainType?.name) ? feedbackDetail?.complainType?.name : '-'}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('complainFile')}</Text>

                                {
                                    feedbackDetail?.complainFileUploadName == null ? <Text style={styles.nofileattached}>No file attached</Text> :
                                        <TouchableOpacity
                                            activeOpacity={0.8}
                                            onPress={() => openAttachment(encodeURI(baseLinkURLComplain + feedbackDetail?.complainFileUploadName), feedbackDetail?.id)}>
                                            <View style={styles.openFileView}>
                                                {
                                                    isDownloadLoader ? <ActivityIndicator color={config.fontAttribute.themeColor} size={17} /> :
                                                        <View style={{ flexDirection: 'row' }}>
                                                            <Image source={config.Images.attach} style={styles.attachmentImage} />
                                                            <Text style={styles.openFileText}>{t('openFile')}</Text>
                                                        </View>
                                                }
                                            </View>
                                        </TouchableOpacity>
                                }
                            </View>
                            {
                                !feedbackDetail?.isOpen
                                &&
                                <View>
                                    <View style={styles.contactRow}>
                                        <Text style={styles.rowtitle}>{t('responseMessage')}</Text>
                                        <View style={styles.viewMoreFunctionality}>
                                            <Text numberOfLines={showFullResponse ? undefined : 3} style={styles.rowData}>
                                                {checkStringNullOrEmpty(feedbackDetail?.complainResponse) ? feedbackDetail?.complainResponse : '-'}

                                                {showFullResponse && <Text onPress={() => setShowFullResponse(false)} style={[styles.nofileattached, { textAlign: 'left' }]} > View less
                                                </Text>}
                                            </Text>
                                            {!showFullResponse && <Text onPress={() => setShowFullResponse(true)} style={[styles.nofileattached,]}>
                                                View more
                                            </Text>}
                                        </View>
                                    </View>
                                    <View style={styles.contactRow}>
                                        <Text style={styles.rowtitle}>{t('responseDate')}</Text>
                                        <Text style={styles.rowData}>{checkStringNullOrEmpty(feedbackDetail?.responseDate) ? ConvertDateFormat(feedbackDetail?.responseDate) : '-'}</Text>
                                    </View>
                                    <View style={styles.contactRow}>
                                        <Text style={styles.rowtitle}>{t('responseFile')}</Text>
                                        {
                                            feedbackDetail?.responseFileUploadName == null ? <Text style={styles.nofileattached}>No file attached</Text> :
                                                <TouchableOpacity
                                                    activeOpacity={0.8}
                                                    onPress={() => openAttachment(encodeURI(baseLinkURLComplain + feedbackDetail?.responseFileUploadName), feedbackDetail?.id)}>
                                                    <View style={styles.openFileView}>
                                                        {isDownloadLoader ? <ActivityIndicator color={config.fontAttribute.themeColor} size="small" /> :
                                                            <View style={{ flexDirection: 'row' }}>
                                                                <Image source={config.Images.attach} style={styles.attachmentImage} />
                                                                <Text style={styles.openFileText}>{t('openFile')}</Text>
                                                            </View>}
                                                    </View>
                                                </TouchableOpacity>
                                        }
                                    </View>
                                </View>
                                // : <></>
                            }
                        </ScrollView>
                    </View>
                </View>
            </Modal >
        </View>
    )
}

export default DetailModal

const openAttachmentButton = (props: any) => {
    return (
        <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => props.openAttachment(encodeURI(baseLinkURLComplain + props.feedbackDetail?.responseFileUploadName), props.feedbackDetail?.id)}>
            <View style={styles.openFileView}>
                <Image source={config.Images.attach} style={styles.attachmentImage} />
                <Text style={styles.openFileText}>Open file</Text>
            </View>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({

    companyName: {
        backgroundColor: '#fff',
        height: 65,
        padding: 15,
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    companyNameText: {
        color: '#3D5E87',
        fontWeight: '400',
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue
    },

    contactRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 10,
    },
    rowtitle: {
        color: config.fontAttribute.themeColor,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600'
    },
    rowData: {
        // maxWidth: '75%',
        color: config.fontAttribute.TextColor1,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '400',
        textAlign: 'left',
    },
    openFileView: {
        // margin: 10,
        paddingVertical: 5,
        paddingHorizontal: 10,
        backgroundColor: '#EAF4FF',
        borderWidth: 1,
        borderRadius: 10,
        borderColor: '#DEEEFF',
        flexDirection: 'row',
        alignItems: 'center'
    },
    attachmentImage: {
        width: 14,
        height: 14,
        marginRight: 8
    },
    openFileText: {
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        color: config.fontAttribute.TextColor2,
        fontWeight: '300'
    },
    nofileattached: {
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        color: config.fontAttribute.themeColor,
        fontWeight: '300'
    },
    viewMoreFunctionality: {
        flexDirection: 'column', maxWidth: '60%'
    }
})