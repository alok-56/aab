import { StyleSheet } from "react-native";
import { pixelValue } from "../../../config/GlobalVariable";
import * as config from '../../../config/index'

const styles = StyleSheet.create({
  container: {
    flex: 1, marginVertical: 5, borderRadius: 10, padding: 5 , backgroundColor:'#fff'
  },
  card: {
    height: 'auto',
    paddingHorizontal: 15,
    marginHorizontal: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    borderColor: 'rgba(102,112,133,0.4)',
    borderWidth: 1,
    marginVertical: 8,
    paddingVertical: 5
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 5,
    alignItems: 'flex-start',
    flex: 1
  },
  downloadText: {
    color: config.fontAttribute.themeColor,
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '600',
    marginRight: 10
  },
  rowTitle: {
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    color: config.fontAttribute.themeColor,
    fontWeight: '600',
    margin: 1
  },
  rowData: {
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    color: config.fontAttribute.TextColor1,
    fontWeight: '400',
    margin: 1
  },
  dashedLineBreak: {
    marginHorizontal: -10,
    borderWidth: 0.3,
    borderColor: '#D0D5DD',
    borderStyle: 'dashed',
    marginVertical: 5
  },
  ModalView: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.8)'
  },
  innerModalView: {
    // backgroundColor: '#fff',
    height: '70%',
    width: '100%',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    // padding: 15,
    paddingHorizontal: 30
  },
  crossIcon: {
    alignItems: 'flex-end',
    marginBottom: 15,
    marginRight: 20,
    padding: 10,
  }
})

export default styles;