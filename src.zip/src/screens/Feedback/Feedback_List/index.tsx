import {useFocusEffect, useIsFocused} from '@react-navigation/native';
import React, {useState} from 'react';
import {useTranslation} from 'react-i18next';
import {
  ActivityIndicator,
  FlatList,
  Image,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {shallowEqual, useSelector} from 'react-redux';
import {
  GetFeedbackDescription,
  GetFeedbackList,
} from '../../../ApiServices/httpServices';
import {IuserPorfileDto} from '../../../AppModel/UserProfileModel';
import {Headercomponent} from '../../../Components';
import NoData from '../../../Components/No_Data_Component';
import Skeleton from '../../../Components/skeleton/skeleton';
import {NavMenu} from '../../../config/GlobalVariable';
import * as config from '../../../config/index';
import DetailModal from './DetailsModal';
import styles from './style';

let pageIndex = 1;
const FeedbackList = (props: any) => {
  // try {

  const ProfileData: IuserPorfileDto = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  const {t, i18n} = useTranslation();
  const [isloader, setIsLoader] = useState(false);
  const [isLazyLoader, setIsLazyLoader] = useState(false);
  const {navigation} = props;
  const [isOpen, setIsOpen] = useState(false);
  const [isDetailModal, setIsDetailModal] = useState(false);
  const [modalImage, setModalImage] = useState('');
  const [selectedFeedback, setSelectedFeedback] = useState<any>(null);
  const [feedbackList, setFeedbackList] = useState<Array<any>>([]);
  const isFocused = useIsFocused();
  useFocusEffect(
    React.useCallback(() => {
      try {
        if (isFocused) {
          // console.log("Hey")
          setIsLoader(true);
          pageIndex = 1;
          feedbackList.length = 0;
          setFeedbackList(feedbackList);
          getAllFeedbacks();
        }
      } catch (error) {
        console.log('List Page Ctch', error);
      }
    }, [isFocused]),
  );
  const getAllFeedbacks = () => {
    console.log('Hey');
    const params = {
      status: 2,
      SearchText: 0,
      PageIndex: pageIndex,
      PageSize: 10,
      RoleId: ProfileData?.profile?.profileRole?.id,
      UserId: ProfileData?.profile?.profileId,
    };
    console.log('Feedback List params', params);
    GetFeedbackList(params)
      .then((result: any) => {
        console.log('Feedback List', result);
        if (result) {
          setIsLazyLoader(false);
          setIsLoader(false);
          let itemList = [];
          itemList = feedbackList?.concat(result?.allComplains);
          setFeedbackList(itemList);
        }
      })
      .catch((err: any) => {
        setIsLoader(false);
        console.log('FeedbackList Error', err);
      });
  };
  // const onClose = () => {
  //   setIsOpen(false);
  // }
  const onPlusIconClicked = () => {
    navigation.navigate(NavMenu.feedback.createFeedback);
  };

  const [isRefreshing, setIsRefreshing] = useState(false);

  const onListRefresh = () => {
    setIsLoader(true);
    feedbackList.length = 0;
    setFeedbackList(feedbackList);
    pageIndex = 1;
    getAllFeedbacks();
  };
  const onEndReached = () => {
    setIsLazyLoader(true);
    pageIndex = pageIndex + 1;
    getAllFeedbacks();
    console.warn('end reached');
  };

  // let feedbackDetails: any = null;
  const getFeedbackDetails = (item: any) => {
    GetFeedbackDescription(item?.complainId)
      .then((result: any) => {
        console.log('feed. Desc.', result);
        if (result) {
          setSelectedFeedback(result);
          // feedbackDetails = result
          // return result;
        }
      })
      .catch((err: any) => {
        console.log('Feed. Desc.', err);
        // return null;
      });
  };
  const onViewDetailsclicked = (item: any) => {
    setIsDetailModal(true);
    getFeedbackDetails(item);
  };
  const skaletonData = [{}, {}, {}, {}];
  const skeletonRenderItem = () => {
    return (
      <Skeleton>
        <View
          style={{
            marginVertical: 10,
            height: 'auto',
            borderWidth: 1,
            padding: 10,
            backgroundColor: '#fff',
            borderRadius: 4,
          }}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginVertical: 3,
            }}>
            <View>
              <View style={{width: 170, height: 10, marginVertical: 5}}></View>
              <View style={{width: 170, height: 10, marginVertical: 5}}></View>
            </View>
            <View>
              <View style={{width: 170, height: 10, marginVertical: 5}}></View>
              <View style={{width: 170, height: 10, marginVertical: 5}}></View>
            </View>
          </View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginVertical: 3,
            }}>
            <View>
              <View style={{width: 170, height: 10, marginVertical: 5}}></View>
              <View style={{width: 170, height: 10, marginVertical: 5}}></View>
            </View>
            <View>
              <View style={{width: 170, height: 10, marginVertical: 5}}></View>
              <View style={{width: 170, height: 10, marginVertical: 5}}></View>
            </View>
          </View>
          <View
            style={{
              borderTopWidth: 1,
              borderColor: '#EAECF0',
              marginVertical: 5,
            }}></View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'flex-end',
              marginVertical: 3,
            }}>
            <View style={{width: 170, height: 10, marginVertical: 5}}></View>
          </View>
        </View>
      </Skeleton>
    );
  };
  const renderItem = (item: any) => {
    return (
      <View style={styles.card}>
        <View style={styles.row}>
          <View style={config.AppStyle.AppStyle.flex1}>
            <Text style={styles.rowTitle}>{t('complainId')}</Text>
            <Text style={styles.rowData}>{item?.complainId}</Text>
          </View>

          <View style={config.AppStyle.AppStyle.flex1}>
            <Text style={styles.rowTitle}>{t('distributorId')}</Text>
            <Text style={styles.rowData}>{item?.distributorId}</Text>
          </View>
        </View>

        <View style={styles.row}>
          <View style={config.AppStyle.AppStyle.flex1}>
            <Text style={styles.rowTitle}>{t('status')}</Text>
            <Text style={styles.rowData}>
              {item?.status ? 'Open' : 'Closed'}
            </Text>
          </View>
        </View>
        {/* Line Break */}
        <View style={styles.dashedLineBreak}></View>

        <View
          style={[
            styles.row,
            {
              alignItems: 'center',
              marginVertical: 0,
              justifyContent: 'flex-end',
            },
          ]}>
          {/* <TouchableOpacity style={{ padding: 5 }} activeOpacity={0.8} onPress={() => attachmentIconClicked(item ? item : '')}>
            <Image style={{ width: 15, height: 15 }} source={config.Images.attach} />
          </TouchableOpacity> */}

          <TouchableOpacity
            activeOpacity={0.8}
            style={{padding: 5}}
            onPress={() => {
              onViewDetailsclicked(item);
            }}>
            <View
              style={[styles.row, {alignItems: 'center', marginVertical: 0}]}>
              <Text style={styles.downloadText}>{t('viewDetails')}</Text>
              <Image
                style={{tintColor: config.fontAttribute.themeColor}}
                source={config.Images.RightArrow}
              />
            </View>
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  return (
    <View style={{flex: 1}}>
      <Headercomponent
        type={'3'}
        isAdd={true}
        name={t('feedback')}
        onPlusIconClicked={onPlusIconClicked}
      />
      <View style={styles.container}>
        {isloader ? (
          <FlatList
            showsVerticalScrollIndicator={false}
            data={skaletonData}
            onEndReachedThreshold={0.7}
            renderItem={({item}) => skeletonRenderItem()}
          />
        ) : (
          <>
            <FlatList
              showsVerticalScrollIndicator={false}
              onRefresh={onListRefresh}
              refreshing={isRefreshing}
              data={feedbackList}
              onEndReached={onEndReached}
              onEndReachedThreshold={0.7}
              ListEmptyComponent={NoData}
              renderItem={({item}) => renderItem(item)}
            />
            {isLazyLoader ? (
              <ActivityIndicator
                size="small"
                color={config.fontAttribute.themeColor}
              />
            ) : (
              <></>
            )}
          </>
        )}
      </View>

      {/* <Modal
        transparent={true}
        visible={isOpen}
        onRequestClose={onClose}
        animationType='none'>
        <View style={styles.ModalView}>
          <View style={styles.crossIcon}>
            <TouchableOpacity style={{ padding: 10 }} activeOpacity={0.9} onPress={onClose}>
              <Image source={config.Images.cross} />
            </TouchableOpacity>
          </View>
          <View style={styles.innerModalView}>
            <Image style={{ width: '100%', height: '100%' }} source={{ uri: modalImage }} />
          </View>
        </View>
      </Modal> */}

      <DetailModal
        isOpen={isDetailModal}
        onClose={() => {
          setIsDetailModal(false);
        }}
        feedbackDetail={selectedFeedback}
      />
    </View>
  );
  // } catch (error) {
  //   console.log("UI Catch", error)
  // }
};

export default FeedbackList;
