import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Keyboard,
  PermissionsAndroid,
  Platform,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import { Headercomponent } from '../../../Components';
import * as config from '../../../config/index';
import CameraOptionsModal from './imageSelectionModal';
import { DistributorModal, ModalPage, RetailerModal } from './modal';
// import ImagePicker from 'react-native-image-picker';
import { useFocusEffect, useIsFocused } from '@react-navigation/native';
import { toString } from 'lodash';
import { useTranslation } from 'react-i18next';
import { pick } from '@react-native-documents/picker';
import { showMessage } from 'react-native-flash-message';
import { launchCamera } from 'react-native-image-picker';
import { SvgXml } from 'react-native-svg';
import { shallowEqual, useSelector } from 'react-redux';
import {
  CreateNewFeedback,
  GetComplainTypeList,
} from '../../../ApiServices/httpServices';
import { IDsrProfileDto } from '../../../AppModel/DsrProfileModal';
import { IuserPorfileDto } from '../../../AppModel/UserProfileModel';
import { formatFileSize } from '../../../config/GlobalVariable';
import styles from './style';

//Add in JSON
let MaxCharErrorMessage = 'Must have min. 10 characters.';
// Invalid format

const CreateFeedback = (props: any) => {
  const checkForPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return true;
      } else {
        return false;
      }
    } catch (err) {
      return false;
      console.warn(err);
    }
  };

  const profileDetail: IDsrProfileDto | IuserPorfileDto | any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  const isFocused = useIsFocused();
  useFocusEffect(
    React.useCallback(() => {
      if (isFocused) {
        GetAllConplainType();
      }
    }, [isFocused]),
  );
  const GetAllConplainType = () => {
    GetComplainTypeList()
      .then((result: any) => {
        // console.log('Complain Type', result);
        if (result) {
          setComplainTypeList(result);
        }
      })
      .catch((err: any) => {
        // console.log('Complain Type', err);
      });
  };
  const ProfileData: IDsrProfileDto | IuserPorfileDto | any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );
  // console.log('profile Data', profileDetail);

  const {t, i18n} = useTranslation();
  const {navigation} = props;

  const [isLoader, setIsLoader] = useState(false);
  const [modalList, setModalList] = useState<any>();

  // const [typeList, setTypeList] = useState()
  const [distributorList, setDistributorList] = useState(
    ProfileData.distributors,
  );
  const [complainTypeList, setComplainTypeList] = useState<any>(null);

  const [isMenuOpen, setMenuOpen] = useState(false);
  const [isDistributorModalOpen, setIsDistributorModalOpen] = useState(false);
  const [isRetailerModal, setIsRetailerModal] = useState(false);

  const [complainTypeValue, setComplainTypeValue] = useState<any>(null);
  const [distributorDropdownValue, setDistributorDropdownValue] =
    useState<any>(null);
  const [retailerDropdownValue, setRetailerDropdownValue] = useState<any>(null);

  // const [isClicked, setIsClicked] = useState(false);
  const [selectedId, setSelectedId] = useState(1);
  const [dropdownType, setDropdownType] = useState('');
  const [isImageMenuOpen, setIsImageMenyOpen] = useState(false);
  const [attachment, setAttachment] = useState<any>(null);

  const toggleMenu = () => {
    // setIsClicked(false);
    setMenuOpen(!isMenuOpen);
  };

  const toggleImageMenu = () => {
    setIsImageMenyOpen(!isImageMenuOpen);
  };
  const toggleDistributorModal = () => {
    // setIsClicked(false);
    setIsDistributorModalOpen(!isDistributorModalOpen);
  };
  const toggleRetailerModal = () => {
    // setIsClicked(false);
    setIsRetailerModal(!isRetailerModal);
  };
  const ListValueChanged = (value: any, valueType: string = '') => {
    switch (valueType) {
      // case 'type':
      //     typeList.filter((item: any) => {
      //         if (value.id == item.id)
      //             item.isSelected = true;
      //         else
      //             item.isSelected = false;
      //     })
      //     setDistributorDropdownValue(null);
      //     setTypeDropDownValue(value);
      //     setSelectedId(value.id);
      //     break;
      case 'complainType':
        complainTypeList.filter((item: any) => {
          if (value.id == item.id) item.isSelected = true;
          else item.isSelected = false;
        });
        setSelectedId(value.id);
        setComplainTypeValue(value);
        // console.log(value);
        break;
      case 'distributor':
        setDistributorDropdownValue(value);
        break;
      case 'retailer':
        // console.log(value);
        setRetailerDropdownValue(value);
        break;
      default:
        break;
    }
    // console.warn(value);
  };

  const dropDownClicked = (dropdownType: any) => {
    switch (dropdownType) {
      // case 'type':
      //     console.log("type on open dropdown", typeList)
      //     setModalList(typeList);
      //     setDropdownType('type')
      //     toggleMenu();
      //     break;
      case 'complainType':
        setModalList(complainTypeList);
        setDropdownType('complainType');
        toggleMenu();
        break;
      case 'distributor':
        // console.log(distributorList);
        setModalList(distributorList);
        setDropdownType('distributor');
        toggleDistributorModal();
        break;
      case 'retailer':
        setDropdownType('retailer');
        toggleRetailerModal();
        break;
      default:
        break;
    }
    // setIsClicked(true);
  };
  const onUploadDocumentClicked = () => {
    // PickFile();
    toggleImageMenu();
  };
  const PickFile = () => {
    pick({type: ['application/pdf', 'image/*']})
      .then((result: any) => {
        console.log('picked file', result);
        if (result) {
          setAttachment(result);
        }
      })
      .catch((err: any) => {
        // console.log('Error Picking file', err);
      });
  };
  const onSaveButtonclicked = () => {
    if (
      (profileDetail?.profile?.profileRole?.id == 3 &&
        distributorDropdownValue == null) ||
      (profileDetail?.profile?.profileRole?.id == 4 &&
        retailerDropdownValue == null) ||
      complainTypeValue == null ||
      // attachment == '' ||
      // (typeDropDownValue?.id == 2 && distributorDropdownValue == null) ||
      // credentials?.mobileNo == '' ||
      // credentials?.mobileNo == null ||
      credentials?.description == ''
      // credentials?.description == null
    ) {
      // Alert.alert("First Alert")
      showMessage({
        message: 'All fields are required.',
        color: 'white',
        backgroundColor: 'red',
        duration: 2000,
      });
    } else {
      // Alert.alert("Second Alert")
      createFeedback();
    }
  };

  const [credentials, setCredentials] = useState({
    mobileNo: '',
    description: '',
  });

  const OnChange = (e: any, credName: any) => {
    setCredentials({...credentials, [credName]: e});
    // console.warn(credentials);
  };

  const clickFromCamera = async () => {
    // let options: any = {}
    if (Platform.OS == 'android') {
      PermissionsAndroid.check('android.permission.CAMERA').then(response => {
        if (response === true) {
          openCamera();
          toggleImageMenu();
        } else if (response === false) {
          // console.log(false);
          checkForPermission().then(response => {
            openCamera();
          });
        }
      });
    } else {
      openCamera();
    }
    // const permission = checkForPermission();
    // console.log(permission)
  };
  function updateImageObject(imageObject: any) {
    // Destructure the original object and rename the keys
    const updatedObject = {
      ...imageObject,
      name: imageObject.fileName, // Rename fileName to name
      size: imageObject.fileSize, // Rename fileSize to size
    };

    // Remove the original keys: fileName and fileSize
    delete updatedObject.fileName;
    delete updatedObject.fileSize;

    return updatedObject;
  }
  const openCamera = () => {
    // console.log('open camera');
    // setTimeout(() => {
    //   ImagePicker.openCamera({
    //     width: 300,
    //     height: 400,
    //     cropping: true,
    //   })
    //     .then(image => {
    //       let s: SetStateAction<string> | null = '';
    //       s = image?.path ? image?.path : '';
    //       let updatedImageObject = {
    //         ...image,
    //         name: image.path?.split('/')[image.path?.split('/').length - 1],
    //       };
    //       console.log(updatedImageObject, 'camera image');
    //       setAttachment(updatedImageObject);
    //     })
    //     .catch((error: any) => {
    //       console.log(error);
    //     });
    // }, 100);
    const options: any = {
      mediaType: 'photo',
      maxWidth: 1024,
      maxHeight: 1024,
      quality: 0.8, // Set quality between 0 (low) and 1 (high)
      includeBase64: false,
    };

    // const handleCapture = async () => {
    launchCamera(options, response => {
      if (response.didCancel) {
        Alert.alert('Cancelled', 'User cancelled the image picker.');
      } else if (response.errorCode) {
        Alert.alert('Error', `Image picker error: ${response.errorMessage}`);
      } else if (response.assets) {
        const fileType = response.assets[0].type; // Check file type
        if (fileType === 'image/jpeg' || fileType === 'image/png') {
          console.log(response, 'from camera');
          setAttachment(updateImageObject(response?.assets[0]));
          // setImageUri(response.assets[0].uri);
        } else {
          Alert.alert('Invalid Format', 'Please select a JPEG or PNG image.');
        }
      }
    });
    // };
    toggleImageMenu();
  };
  const chooseFromGallery = async () => {
    // setTimeout(() => {
    //   ImagePicker.openPicker({
    //     mediaType: 'any',
    //     width: 300,
    //     height: 400,
    //     cropping: true,
    //   }).then(image => {
    //     console.log(image);
    //     let s: SetStateAction<string> | null = '';
    //     s = image?.path ? image?.path : '';
    //     setAttachment(s);
    //   });
    // }, 100);
    PickFile();
    toggleImageMenu();
  };
  const onattachmentCrossButtonClicked = () => {
    setAttachment(null);
  };

  const createFeedback = () => {
    try {
      setIsLoader(true);
      const params = new FormData();
      params.append(
        'DistributorId',
        toString(
          profileDetail?.profile?.profileRole?.id == 4
            ? profileDetail?.distributorCode
            : distributorDropdownValue?.distributorCode,
        ),
      );
      params.append('MessageComplain', credentials.description);
      params.append('ComplainType', complainTypeValue?.id);
      params.append(
        'RetailerId',
        toString(
          profileDetail?.profile?.profileRole?.id == 4
            ? retailerDropdownValue?.retailerCode
            : ProfileData?.retailerCode,
        ),
      );
      params.append('fileUpload', attachment);
      params.append('CreatedByUser', profileDetail?.profile?.profileId);
      params.append('CreatedByRoleId', profileDetail?.profile?.profileRole?.id);

      console.log('Create Feedback Params', params);

      CreateNewFeedback(params)
        .then((result: any) => {
          // Alert.alert(`Third Alert`)

          console.log('Create Feedback Result', result);
          if (result) {
            // Alert.alert(`Result Alert => ${result}`)
            setIsLoader(false);
            navigation.goBack();
          }
        })
        .catch((err: any) => {
          setIsLoader(false);
          // Alert.alert(`Error Alert => ${err}`)
          console.log('Create Feedback Error', err);
        });
    } catch (error) {
      console.log('Catch Errro', error);
    }
  };
  return (
    <TouchableWithoutFeedback
      onPress={() => {
        Keyboard.dismiss();
      }}>
      <View style={{flex: 1}}>
        <Headercomponent type={'2'} name={t('createFeedback')} />
        <View style={styles.container}>
          {/* Type */}
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={{flex: 1}}>
              {/* Updated for DSR */}
              {ProfileData?.profile?.profileRole?.id == 4 && (
                <>
                  <Text style={config.AppStyle.AppStyle.inputLabel}>
                    {t('retailerName')}
                    <RedStar />
                  </Text>
                  <TouchableOpacity
                    onPress={() => {
                      dropDownClicked('retailer');
                    }}
                    activeOpacity={1}>
                    <View style={config.AppStyle.AppStyle.inputField}>
                      <TextInput
                        style={{color: config.fontAttribute.TextColor1}}
                        placeholder={t('retailerName')}
                        placeholderTextColor={
                          config.fontAttribute.placeholderColor
                        }
                        editable={false}
                        value={retailerDropdownValue?.retailerName}
                      />
                      {/* {isClicked ? <Image style={styles.downArrow} source={config.Images.upArrowBlack} /> : */}
                      <Image
                        style={styles.downArrow}
                        source={config.Images.DownArrow}
                      />
                    </View>
                  </TouchableOpacity>
                </>
              )}
              {/* <Text style={config.AppStyle.AppStyle.inputLabel}>{t('type')}<RedStar /></Text>
                            <TouchableOpacity onPress={() => { dropDownClicked('type') }} activeOpacity={1}>
                                <View style={config.AppStyle.AppStyle.inputField} >
                                    <TextInput placeholder='-- Select type --' editable={false} value={typeDropDownValue?.name} />
                                    <Image style={styles.downArrow} source={config.Images.DownArrow} />
                                </View>
                            </TouchableOpacity> */}

              {/* Distributor */}
              {/* {
                                 typeDropDownValue?.id == 2
                                     ?
                                     <> */}
              {ProfileData?.profile?.profileRole?.id == 3 && (
                <>
                  <Text style={config.AppStyle.AppStyle.inputLabel}>
                    {t('distributorName')}
                    <RedStar />
                  </Text>
                  <TouchableOpacity
                    onPress={() => {
                      dropDownClicked('distributor');
                    }}
                    activeOpacity={1}>
                    <View style={config.AppStyle.AppStyle.inputField}>
                      <TextInput
                        style={{color: config.fontAttribute.TextColor1}}
                        placeholder={t('selectDistributorPlaceholder')}
                        placeholderTextColor={
                          config.fontAttribute.placeholderColor
                        }
                        editable={false}
                        value={
                          distributorDropdownValue?.distributor?.distributorName
                        }
                      />
                      {/* {isClicked ? <Image style={styles.downArrow} source={config.Images.upArrowBlack} /> : */}
                      <Image
                        style={styles.downArrow}
                        source={config.Images.DownArrow}
                      />
                    </View>
                  </TouchableOpacity>
                </>
              )}
              {/* </>
                                     : <></>
                             } */}

              {/* Complain Type */}
              <Text style={config.AppStyle.AppStyle.inputLabel}>
                {t('complainType')}
                <RedStar />
              </Text>
              <TouchableOpacity
                onPress={() => {
                  dropDownClicked('complainType');
                }}
                activeOpacity={1}>
                <View style={config.AppStyle.AppStyle.inputField}>
                  <TextInput
                    style={{color: config.fontAttribute.TextColor1}}
                    placeholder={t('selectComplainTypePlaceholder')}
                    placeholderTextColor={config.fontAttribute.placeholderColor}
                    editable={false}
                    value={complainTypeValue?.name}
                  />
                  {/* {isClicked ? <Image style={styles.downArrow} source={config.Images.upArrowBlack} /> : */}
                  <Image
                    style={styles.downArrow}
                    source={config.Images.DownArrow}
                  />
                </View>
              </TouchableOpacity>

              {/* Mobile Number */}

              {/* <Text style={config.AppStyle.AppStyle.inputLabel}>{t('mobileNo')}<RedStar /></Text> 
                            <TextInputWithError
                                onChangeText={(e: any) => OnChange(e, 'mobileNo')}
                                isErrorMessageVisible={isMobileNo_MinCharError}
                                keyboardType={'numeric'}
                                maxLength={10}
                                errorMessage={isMobileNo_MinCharError ? MaxCharErrorMessage : ''}
                            /> */}

              {/* Description */}
              <Text style={config.AppStyle.AppStyle.inputLabel}>
                {t('description')}
                <RedStar />
              </Text>
              <ScrollView
                style={[config.AppStyle.AppStyle.textArea, {maxHeight: 100}]}
                showsVerticalScrollIndicator={false}>
                <TextInput
                  selectionColor={config.fontAttribute.cursorColor}
                  textAlignVertical="top"
                  onChangeText={e => OnChange(e, 'description')}
                  style={[
                    {
                      minHeight: 100,
                      color: config.fontAttribute.textInputValueColor,
                    },
                  ]}
                  multiline={true}
                  // numberOfLines={4}
                />
              </ScrollView>

              {/* Attachment */}
              <Text style={config.AppStyle.AppStyle.inputLabel}>
                {t('attachment')}
              </Text>
              <TouchableOpacity
                activeOpacity={1}
                onPress={() => (attachment ? {} : {onUploadDocumentClicked})}>
                <View
                  style={[
                    styles.attachmentArea,
                    {height: attachment ? 'auto' : 100},
                  ]}>
                  {attachment ? (
                    // <View style={styles.attachmentImageView}>
                    //     <Image
                    //         resizeMode='contain'
                    //         style={{
                    //             width: 100,
                    //             height: 200,
                    //         }} source={{ uri: attachment?.uri }} />
                    //     <View style={{ height: '100%', justifyContent: 'flex-start', paddingTop: 10 }}>
                    //         <TouchableOpacity
                    //             activeOpacity={0.8}
                    //             style={styles.attachmentCrossIcon}
                    //             onPress={onattachmentCrossButtonClicked}>
                    //             <Image style={{
                    //                 width: 20,
                    //                 height: 20,
                    //                 tintColor: config.fontAttribute.themeColor
                    //             }} source={config.Images.crossBlack} />
                    //         </TouchableOpacity>
                    //     </View>
                    // </View>
                    <View
                      style={{
                        margin: 10,
                        paddingVertical: 5,
                        paddingHorizontal: 10,
                        backgroundColor: '#EAF4FF',
                        borderWidth: 1,
                        borderRadius: 10,
                        borderColor: '#DEEEFF',
                        flexDirection: 'row',
                        alignItems: 'center',
                      }}>
                      <Image
                        source={config.Images.file}
                        style={{width: 25, height: 25, marginRight: 10}}
                      />
                      <Text
                        style={{
                          maxWidth: '100%',
                          flex: 1,
                          fontSize: config.fontAttribute.labelFontSizeMedium,
                          color: 'black',
                          fontWeight: '300',
                        }}>
                        {attachment?.name}
                        <Text
                          style={{
                            fontSize: config.fontAttribute.labelFontSizeSmall,
                            color: 'gray',
                          }}>
                          {' '}
                          ({formatFileSize(attachment?.size)})
                        </Text>
                      </Text>
                      <TouchableOpacity
                        style={{
                          // backgroundColor: 'red',
                          padding: 10,
                        }}
                        onPress={onattachmentCrossButtonClicked}>
                        {/* <Image style={{
                                                        width: 20,
                                                        height: 20,
                                                        tintColor: config.fontAttribute.themeColor
                                                    }} source={config.Images.crossBlack} /> */}
                        <SvgXml
                          xml={config.svgs.crossBlue}
                          height={10}
                          width={10}
                        />
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <View style={styles.withoutAttachmentView}>
                      {/* Previously on Click of this button => onPress={onUploadDocumentClicked} */}
                      <TouchableOpacity
                        activeOpacity={0.8}
                        onPress={onUploadDocumentClicked}>
                        <Image
                          style={styles.addButton}
                          source={config.Images.addCircleBlack}
                        />
                      </TouchableOpacity>
                      <Text style={{color: config.fontAttribute.TextColor1}}>
                        {t('uploadDocument')}
                      </Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            </View>
          </ScrollView>
          <View>
            <TouchableOpacity
              activeOpacity={0.8}
              style={config.AppStyle.AppStyle.button}
              onPress={onSaveButtonclicked}>
              {isLoader ? (
                <ActivityIndicator
                  size="small"
                  color={config.fontAttribute.whiteColor}
                />
              ) : (
                <Text style={config.AppStyle.AppStyle.buttonText}>
                  {t('submit')}
                </Text>
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* Modal for Dropdown */}
        <ModalPage
          isOpen={isMenuOpen}
          onClose={toggleMenu}
          modalList={modalList}
          TypeValueChanged={ListValueChanged}
          selectedId={selectedId}
          dropdownType={dropdownType}
        />

        {/* DistributorListModal */}
        <DistributorModal
          isOpen={isDistributorModalOpen}
          onClose={toggleDistributorModal}
          modalList={modalList}
          ListValueChanged={ListValueChanged}
        />

        <RetailerModal
          isOpen={isRetailerModal}
          onClose={toggleRetailerModal}
          modalList={ProfileData?.retailers}
          ListValueChanged={ListValueChanged}
        />

        {/* Modal for Image selection */}
        <CameraOptionsModal
          isOpen={isImageMenuOpen}
          onClose={toggleImageMenu}
          fromCamera={clickFromCamera}
          fromGallery={chooseFromGallery}
        />
      </View>
    </TouchableWithoutFeedback>
  );
};

export default CreateFeedback;

const RedStar = () => {
  return (
    <View>
      <Text style={{color: 'red'}}>*</Text>
    </View>
  );
};
