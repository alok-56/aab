import { StyleSheet } from "react-native";
import * as config from '../../../config/index'

const styles = StyleSheet.create({
    downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 20
    },
    container: {
        backgroundColor: config.fontAttribute.whiteColor,
        margin: 10,
        borderRadius: 10,
        padding: 20,
        flex: 1
    },
    attachmentArea: {
        borderWidth: 2,
        borderColor: '#ced4da',
        borderStyle: 'dashed',
        borderRadius: 10,
        margin: 10
    },
    addButton: {
        tintColor: config.fontAttribute.themeColor,
        width: 30,
        height: 30
    },
    attachmentImageView: {
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        margin: 5,
        overflow: 'hidden'
    },
    attachmentCrossIcon: {
        borderRadius: 100,
        borderColor: config.fontAttribute.themeColor,
        borderWidth: 1,
        padding: 2
    },
    withoutAttachmentView: {
        justifyContent: 'center',
        alignItems: 'center',
        height: '100%'
    }
})
export default styles;