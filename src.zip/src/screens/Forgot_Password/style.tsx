import { StyleSheet } from "react-native";
import { pixelValue } from "../../config/GlobalVariable";
import * as config from "../../config"

const styles = StyleSheet.create({
    loginArea:{
        backgroundColor:config.fontAttribute.whiteColor,
        height:'55%',
        borderTopLeftRadius:35,
        borderTopRightRadius:35,
        padding:30
    },
    loginMessageArea:{
        flex:1,
        margin:30,
        marginTop:40,
        justifyContent:'flex-end',
    },
    login:{
        color:config.fontAttribute.whiteColor,
        fontWeight:'700',
        fontSize:config.fontAttribute.headingFontSize * pixelValue,
        lineHeight:30
    },
    loginText:{
        marginTop:5,
        color:config.fontAttribute.whiteColor,
        fontWeight:'400',
        fontSize:config.fontAttribute.labelFontSizeLarge * pixelValue,
        lineHeight:25
    },
    downArrow:{
        position:'absolute',
        right : 15,
        bottom:30
    }
    ,loginWithOTP:{
        fontWeight:'600',
        fontSize:config.fontAttribute.labelFontSize*pixelValue,
        color:config.fontAttribute.themeColor,
        marginTop:20
    },
    backButtonArea:{
        margin:30
    }
})

export default styles;