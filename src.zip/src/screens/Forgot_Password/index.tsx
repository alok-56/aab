import { View, Text, StyleSheet, TextInput, Image, TouchableOpacity, TouchableWithoutFeedback, Keyboard, ImageBackground, ActivityIndicator, KeyboardAvoidingView, Platform } from 'react-native'
import React, { useEffect, useRef, useState } from 'react'
import * as config from '../../config'
import { useTranslation } from 'react-i18next';

import styles from './style';
// import ModalPage from './modal';
import { Formik } from 'formik';
import * as Yup from 'yup'
import { SvgXml } from 'react-native-svg';
import { ForgotPassword } from '../../ApiServices/httpServices';
import { result } from 'lodash';
import { showMessage } from 'react-native-flash-message';

// import Profile from '../../Profile';

const LoginScreen = (props: any) => {
    const { route, navigation } = props;
    console.log("navigation", navigation)
    const { t, i18n } = useTranslation();
    const [isLoading, setIsLoading] = useState(false);

    const onResetPasswordClicked = (values: any) => {
        setIsLoading(true);
        const params = {
            Email: values.emailId,
            MobileNo: values.mobileNo
        }
        console.log("Forgot Password Params", params)
        ForgotPassword(params).then((result) => {
            console.log("Forgot Pass Resuilt", result)
            if (result?.statusCode) {
                setIsLoading(false);
                showMessage({ message: result?.message, duration: 3000, backgroundColor: 'green', color: 'white' })
                navigation.goBack();
            }
            else {
                setIsLoading(false);
                showMessage({ message: result?.message, duration: 3000, backgroundColor: 'red', color: 'white' })
            }
        }).catch((err: any) => {
            setIsLoading(false);
            console.log("Forgot Pass Error", err)
            showMessage({ message: err?.message, duration: 3000, backgroundColor: 'red', color: 'white' })
        })
    }

    const backArrowClicked = () => {
        navigation.goBack();
    }
    const PasswordValidationSchema = Yup.object().shape({
        emailId: Yup
            .string()
            .required(t('emailRequiredError'))
            .matches(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, t('invalidEmailFormatError')),
        mobileNo: Yup
            .string()
            .required(t('mobileRequiredError'))
            .min(10, ({ min }) => t('invalidMobileNoFormatError'))
    })

    return (
        <KeyboardAvoidingView
            style={{ flex: 1 }}
            behavior={Platform.OS == 'ios' ? 'padding' : undefined}
            keyboardVerticalOffset={65}>
            <TouchableWithoutFeedback onPress={() => { Keyboard.dismiss() }}>
                <ImageBackground resizeMode='cover' style={config.AppStyle.AppStyle.flex1} source={config.Images.loginBackground}>
                    <View style={config.AppStyle.AppStyle.flex1}>
                        <TouchableOpacity activeOpacity={0.8} onPress={backArrowClicked}>
                            <View style={styles.backButtonArea}>
                                <Image source={config.Images.backArrowWhite} />
                            </View>
                        </TouchableOpacity>
                        <View style={styles.loginMessageArea}>
                            <Text style={styles.login}>{t('resetPassword')}</Text>
                            <Text style={styles.loginText}>{t('resetPasswordMessage')}</Text>
                        </View>
                        <View style={styles.loginArea}>
                            <Formik
                                initialValues={{ emailId: '', mobileNo: '' }}
                                onSubmit={values => onResetPasswordClicked(values)}
                                validationSchema={PasswordValidationSchema}
                            >
                                {({
                                    values,
                                    errors,
                                    touched,
                                    handleChange,
                                    handleBlur,
                                    handleSubmit,
                                    setFieldTouched,
                                    isSubmitting,
                                    isValid,
                                    handleReset
                                    /* and other goodies */
                                }) => (
                                    <View>

                                        {/* Current Password */}
                                        <Text style={config.AppStyle.AppStyle.inputLabel}>{t('emailId')}<RedStar /></Text>
                                        <View style={[config.AppStyle.AppStyle.inputField,
                                        { borderColor: touched.emailId && errors.emailId ? 'red' : '#ced4da' }
                                        ]}>
                                            <TextInput
                                                style={{ flex: 1, color: config.fontAttribute.textInputValueColor }}
                                                placeholderTextColor={config.fontAttribute.placeholderColor}
                                                selectionColor={config.fontAttribute.cursorColor}
                                                value={values.emailId}
                                                onChangeText={(text) => {
                                                    handleChange('emailId')(text); // Call the Formik handleChange
                                                    setFieldTouched('emailId', true, false); // Set the field to touched without triggering validation
                                                }}
                                                placeholder={t('emailId')}                                        
                                            />
                                            {
                                                touched.emailId && errors.emailId
                                                    ?
                                                    <SvgXml xml={config.svgs.errorIcon} height={18} width={18} />
                                                    :
                                                    <></>
                                            }
                                        </View>
                                        {touched.emailId && errors.emailId && (
                                            <Text style={config.AppStyle.AppStyle.errorMessage}>{errors.emailId}</Text>
                                        )}

                                        {/* New Password */}
                                        <Text style={config.AppStyle.AppStyle.inputLabel}>{t('mobileNo')}<RedStar /></Text>
                                        <View style={[config.AppStyle.AppStyle.inputField,
                                        { borderColor: touched.mobileNo && errors.mobileNo ? 'red' : '#ced4da' }
                                        ]}>
                                            <TextInput
                                                maxLength={10}
                                                keyboardType='numeric'
                                                style={{ flex: 1, color: config.fontAttribute.textInputValueColor }}
                                                placeholderTextColor={config.fontAttribute.placeholderColor}
                                                selectionColor={config.fontAttribute.cursorColor}
                                                value={values.mobileNo}
                                                onChangeText={(text) => {
                                                    handleChange('mobileNo')(text); // Call the Formik handleChange
                                                    setFieldTouched('mobileNo', true, false); // Set the field to touched without triggering validation
                                                }}
                                                placeholder={t('mobileNo')}

                                            />
                                            {
                                                touched.mobileNo && errors.mobileNo
                                                    ?
                                                    <SvgXml xml={config.svgs.errorIcon} height={18} width={18} />
                                                    :
                                                    <></>
                                            }
                                        </View>
                                        {touched.mobileNo && errors.mobileNo && (
                                            <Text style={config.AppStyle.AppStyle.errorMessage}>{errors.mobileNo}</Text>
                                        )}

                                        <TouchableOpacity
                                            onPress={() => { handleSubmit() }}
                                            activeOpacity={0.8}
                                            style={[config.AppStyle.AppStyle.button]}>
                                            <Text style={config.AppStyle.AppStyle.buttonText}>{!isLoading ? t('submit') : <ActivityIndicator size="small" color="#ffffff" />}</Text>
                                        </TouchableOpacity>
                                    </View>
                                )}
                            </Formik>


                        </View>

                    </View>
                </ImageBackground>
            </TouchableWithoutFeedback>
        </KeyboardAvoidingView>

    )
}

export default LoginScreen

const RedStar = () => {
    return (
        <View>
            <Text style={{ color: 'red' }}>*</Text>
        </View>
    )
}