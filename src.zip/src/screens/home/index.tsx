import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SvgXml } from 'react-native-svg';
import { shallowEqual, useSelector } from 'react-redux';
import Headercomponent from '../../Components/Header';
import {
  NavMenu,
  capitalize,
  checkStringNullOrEmpty,
  pixelValue,
} from '../../config/GlobalVariable';
import * as config from '../../config/index';
import { SafeAreaView } from 'react-native-safe-area-context';
import Slider from './slider';

const Home = (props: any) => {
  const { t } = useTranslation();

  const menuList: any = useSelector(
    (state: any) => state.auth.menuList,
    shallowEqual,
  );

  const profileDetail: any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  // ✅ Check access
  const hasAccess = (menuCode: number) => {
    return menuList?.some((item: any) => item?.menuCode === menuCode);
  };

  // ✅ Dynamic Quick Links
  const quickLinks = [
    { label: 'order', code: 2, route: NavMenu.order.order },
    { label: 'productCatalogue', code: 3, route: NavMenu.productCatalog },
    { label: 'ledger', code: 4, route: NavMenu.ledger.distributorLedger },
    { label: 'feedback', code: 7, route: NavMenu.feedback.feedbackList },
    { label: 'Scheme', code: 7, route: NavMenu.Scheme.Dashboard },
    { label: 'addNewRetailer', code: 10, route: NavMenu.beatPlanManagement.addRetailer },
    { label: 'visitList', code: 12, route: NavMenu.beatPlanManagement.visitDetailsList },
  ];

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Headercomponent type={'1'} name={t('dashboard')} />

      <View style={styles.container}>
        {/* 👤 User Info */}
        <View style={styles.userDetails}>
          <SvgXml
            style={styles.userProfilePic}
            height={50}
            width={50}
            xml={config?.svgs?.profileIcon}
          />

          <View style={styles.userInfo}>
            <Text style={styles.hi}>
              Hi,
              <Text style={styles.userNameText}>
                {' '}
                {capitalize(profileDetail?.profile?.profileName)}
              </Text>
            </Text>

            <Text style={styles.userEmailText}>
              {checkStringNullOrEmpty(profileDetail?.emailId)
                ? profileDetail?.emailId.toLowerCase()
                : '-'}
            </Text>
          </View>
        </View>

        {/* 🚀 Quick Links */}
        <View style={styles.quickLinksArea}>
          <View style={styles.cardRow}>
            {quickLinks
              .filter(item => hasAccess(item.code))
              .map((item, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.card}
                  activeOpacity={0.8}
                  onPress={() => props.navigation.navigate(item.route)}
                >
                  <Text
                    style={[
                      styles.userNameText,
                      {
                        color: config.fontAttribute.themeColor,
                        textAlign: 'center',
                      },
                    ]}
                  >
                    {t(item.label)}
                  </Text>
                </TouchableOpacity>
              ))}
          </View>
        </View>
         <Slider></Slider>
      </View>
     
    </SafeAreaView>
  );
};

export default React.memo(Home);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginVertical: 5,
    borderRadius: 10,
    paddingHorizontal: 15,
  },
  userDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 10,
  },
  userInfo: {
    marginLeft: 15,
    maxWidth: '80%',
  },
  userProfilePic: {
    height: 70,
    width: 70,
    borderColor: config.fontAttribute.TextColor1,
    borderRadius: 100,
  },
  userNameText: {
    fontWeight: '600',
    color: config.fontAttribute.TextColor1,
    fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
  },
  userEmailText: {
    fontWeight: '400',
    color: config.fontAttribute.TextColor1,
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
  },
  hi: {
    fontSize: config.fontAttribute.headingFontSizeLarge * pixelValue,
    fontWeight: '600',
    color: config.fontAttribute.themeColor,
  },
  quickLinksArea: {
    backgroundColor: '#fff',
    borderRadius: 10,
  },
  cardRow: {
    flexDirection: 'row',
    flexWrap: 'wrap', // ✅ allows grid layout
    justifyContent: 'space-between',
  },
  card: {
    backgroundColor: '#EAF4FF',
    width: '48%', // ✅ 2 cards per row
    marginVertical: 8,
    height: 80,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#DEEEFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
});