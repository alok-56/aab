import React from 'react';
import {
  Dimensions,
  Image,
  Linking,
  TouchableOpacity,
  View,
} from 'react-native';
import Carousel from 'react-native-reanimated-carousel';

const Slider = () => {
  const data = [
    {
      image: require('../../Assets/images/banner.jpeg'),
      link: 'https://www.finolex.com/',
    },
    {
      image: require('../../Assets/images/banner1.jpeg'),
      link: 'https://www.finolex.com/products',
    },
  ];

  const width = Dimensions.get('window').width;

  return (
    <View style={{ marginVertical: 15 }}>
      <Carousel
        data={data}
        width={width * 0.9}
        height={150}
        autoPlay
        loop
        scrollAnimationDuration={2000}
        renderItem={({ item }) => (
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => {
              if (item.link) {
                Linking.openURL(item.link);
              }
            }}
          >
            <Image
              source={item.image} // ✅ FIXED
              style={{
                height: 150,
                width: '100%',
                borderRadius: 10,
              }}
              resizeMode="cover"
            />
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

export default Slider;