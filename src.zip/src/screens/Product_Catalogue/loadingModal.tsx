import { View, Text, Modal, Image, StyleSheet, TextInput, ActivityIndicator } from 'react-native'
import React from 'react'
import { themeColor, whiteColor } from '../../config/fontConfig';

const LoadingModal = (props: any) => {

    const { isOpen, onClose } = props;


    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={styles.ModalView}>
                    <View style={styles.innerModalView}>
                        <ActivityIndicator size='large' color={themeColor} />
                    </View>
                </View>
            </Modal>
        </View>
    )
}

export default LoadingModal

const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0,0,0,0.5)'
    },
    innerModalView: {
        backgroundColor: 'rgba(0,0,0,0.6)',
        height: 100,
        width: 100,
        borderRadius: 10,
        padding: 15,
        paddingHorizontal: 30,
        justifyContent: 'center',
        alignItems: 'center'
    },
    crossIcon: {
        alignItems: 'flex-end',
        marginBottom: 15,
        marginRight: 20,
        padding: 10
    }, downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 30
    },
})