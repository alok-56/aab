import { useFocusEffect, useIsFocused } from '@react-navigation/native';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  ActivityIndicator,
  FlatList,
  Image,
  Platform,
  Text,
  ToastAndroid,
  TouchableOpacity,
  View,
} from 'react-native';
import { TextInput } from 'react-native-gesture-handler';
import { SvgXml } from 'react-native-svg';
import { shallowEqual, useSelector } from 'react-redux';
//import RNFetchBlob from 'rn-fetch-blob';
import { baseLinkURLProductCatalogue } from '../../ApiServices/credential';
import {
  GetCatalogueCategoryList,
  GetCatalogueList,
} from '../../ApiServices/httpServices';
import { IDsrProfileDto } from '../../AppModel/DsrProfileModal';
import { IuserPorfileDto } from '../../AppModel/UserProfileModel';
import { Headercomponent } from '../../Components';
import NoData from '../../Components/No_Data_Component';
import * as config from '../../config/index';
import CategoryListModal from './CategoryListModal';
import LoadingModal from './loadingModal';
import styles from './style';
// import RNFetchBlob from 'rn-fetch-blob';
import Skeleton from '../../Components/skeleton/skeleton';
import { downloadFile } from '../../config/GlobalVariable';

let category: any | null = '';
let pageIndex = 0;
let Templist = Array<any>();
const ProductCatalogue = () => {
  const { t, i18n } = useTranslation();
  const [isMenuOpen, setMenuOpen] = useState(false);
  const [isClicked, setIsClicked] = useState(false);
  const [filterLable, setFilterLable] = useState(null);
  const [isDownloadLoader, setIsDownloadLoader] = useState(false);
  // const [categoryValue, setCategoryValue] = useState<any>('')
  const [isCategoryModal, setIsCategoryModal] = useState(false);
  const [categoryList, setCategoryList] = useState<any>();
  const [catalogueList, setCatalogueList] = useState<Array<any>>([]);
  // const [pageIndex, setPageIndex] = useState(0);
  const [isLazyLoader, setIsLazyLoader] = useState(false);
  const [isCatalogueLoader, setIsCatalogueLoader] = useState(false);

  const isFocused = useIsFocused();

  const profileInfo: IDsrProfileDto | IuserPorfileDto | any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  useFocusEffect(
    React.useCallback(() => {
      if (isFocused) {
        setIsLazyLoader(false);
        setIsCatalogueLoader(true);
        catalogueList.length = 0;
        Templist = [];
        setCatalogueList(catalogueList);
        getCategoryList();
        pageIndex = 0;
        category = '';
        getProductCatalogues(pageIndex, category);
        pageIndex = 0;
      }
    }, [isFocused]),
  );
  // useEffect(() => {
  // }, [categoryValue])

  const getCategoryList = () => {
    GetCatalogueCategoryList()
      .then((result: any) => {
        console.log('Category list', result);
        setCategoryList(result);
      })
      .catch((err: any) => {
        console.log('error', err);
      });
  };
  const getProductCatalogues = (PageIndex: any, category: any) => {
    let salesoffice = '';
    profileInfo?.profile?.profileRole.id == 4
      ? (salesoffice = profileInfo?.distributor?.salesOffice)
      : '';
    profileInfo?.profile?.profileRole.id == 3
      ? (salesoffice = profileInfo?.salesOffice)
      : '';
    const params = {
      // SalesOffice: profileInfo?.salesOffice,
      SalesOffice: salesoffice,
      CategoryId: category,
      PageSize: 10,
      PageIndex: PageIndex,
    };
    console.log('cata params', params);
    GetCatalogueList(params)
      .then(result => {
        setIsCatalogueLoader(false);
        setIsLazyLoader(false);
        console.log('catalogue List', result);
        // console.log(catalogueList)
        Templist = Templist?.concat(result);
        // console.log("termplist",Templist)
        setCatalogueList(Templist);
        // console.log(catalogueList)
      })
      .catch((err: any) => {
        setIsCatalogueLoader(false);
        setIsLazyLoader(false);
        console.log('error', err);
      });
  };
  const toggleCategoryModal = () => {
    setIsCategoryModal(!isCategoryModal);
  };
  const dropDownClicked = () => {
    console.log('opened');
    toggleCategoryModal();
  };
  const onApplyButtonClicked = (e: any) => {
    if (e != null) {
      pageIndex = 0;
      setIsCatalogueLoader(true);
      toggleCategoryModal();
      catalogueList.length = 0;
      Templist = [];

      setCatalogueList(catalogueList);
      pageIndex = 0;
      category = e;
      getProductCatalogues(pageIndex, category?.item1);
      console.log(e);
    } else {
      toggleCategoryModal();
      // onListRefresh()
    }
  };

  // const checkForPermission = async () => {
  //   if (Platform.OS == 'android') {
  //     try {
  //       const granted = await PermissionsAndroid.request(
  //         PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE
  //       );
  //       console.log(granted)
  //       if (granted === PermissionsAndroid.RESULTS.GRANTED) {
  //         console.log("granted")
  //         return true
  //       } else {
  //         console.log("denided")
  //         return false
  //       }
  //     } catch (err) {
  //       console.log("denided")
  //       return false
  //     }
  //   } else {
  //     return true;
  //   }
  // }

  async function downloadPdfAndroid(url: string, name: string) {
    console.log(url);
    try {
      //const {config, fs} = RNFetchBlob;
      const downloads = fs.dirs.DownloadDir;
      let filePath = `${downloads}/${name}.${
        url.split('.')[url.split('.').length - 1]
      }`;

      const getNewFilePath = async (
        path: string,
        counter: number,
      ): Promise<string> => {
        const newFilePath = `${downloads}/${name}(${counter}).${
          url.split('.')[url.split('.').length - 1]
        }`;
        const fileExists = await fs.exists(newFilePath);
        return fileExists ? getNewFilePath(path, counter + 1) : newFilePath;
      };
      const exists = await fs.exists(filePath);
      if (exists) {
        // If the file exists, get a new file path
        filePath = await getNewFilePath(filePath, 1);
      }
      const result = await config({
        fileCache: true,
        addAndroidDownloads: {
          useDownloadManager: true,
          notification: true,
          path: filePath,
          description: 'Downloading PDF document',
          mime: 'application/pdf',
          mediaScannable: true,
        },
      }).fetch('GET', url);
      console.log('PDF document downloaded successfully', result.path());
      // Alert.alert(`${name} downloaded successfully to ${result.path()}`);
      Platform.OS == 'android' &&
        ToastAndroid.show(
          `${name} downloaded successfully to ${result.path()}`,
          500,
        );
    } catch (err) {
      console.warn('Error downloading PDF document:', err);
      Platform.OS == 'android' &&
        ToastAndroid.show(`Error downloading PDF document : ${err}`, 500);
    }
  }

  //Is Part of Opendownloaded File Functionality
  // const downloadFile = async (url: any, name: any) => {
  //   console.log(url)
  //   setIsDownloadLoader(true)
  //   const localFilePath = `${RNFS.DocumentDirectoryPath}/${name}.pdf`;
  //   console.log("Here 1")
  //   try {
  //     await RNFS.downloadFile({
  //       fromUrl: url,
  //       toFile: localFilePath,
  //     }).promise;
  //     console.log("Here 2")

  //     return localFilePath;
  //   } catch (error) {
  //     setIsDownloadLoader(false);
  //     console.error('File download error:', error);
  //     throw error;
  //   }
  // };

  // const openDownloadedFile = async (filePath: any) => {

  //   try {
  //     console.log("Here 3")

  //     setTimeout(() => {
  //       FileViewer.open(filePath).then((result: any) => {
  //         console.log("file open result", result)
  //       }).catch((err: any) => {
  //         console.log(err)
  //       });
  //     }, 50);
  //     setIsDownloadLoader(false)
  //     console.log("Here 4")

  //     // File opened successfully
  //   } catch (error) {
  //     setIsDownloadLoader(false)
  //     console.error('Error opening file:', error);
  //   }
  // };

  const ViewPDF = (item: any) => {
    // if (Platform.OS == 'ios') {
    // downloadFile("http://dmsdev.finolex.com:8089/images/ProductCatalog/Wires%20Catalogue_Silver%20(210x297mm)%20F_2024_02_05_164427.pdf")
    // checkForPermission().then(async (response: any) => {
    //   if (response) {
    setIsDownloadLoader(true);
    downloadFile(
      encodeURI(baseLinkURLProductCatalogue + item?.pdfName),
      item?.productName,
      setIsDownloadLoader,
    )
      .then(() => {})
      .catch(error => {
        console.error(error);
      });
    // }
    // });
    // await downloadPdf(baseLinkURLProductCatalogue + item?.pdfName, item?.productName);
    // } else {
    //   checkForPermission().then(async (response) => {
    //     downloadPdfAndroid(encodeURI(baseLinkURLProductCatalogue + item?.pdfName), item?.productName);
    //   });
    // }
  };
  const downloadPdf = (item: any) => {
    downloadPdfAndroid(
      encodeURI(baseLinkURLProductCatalogue + item?.pdfName),
      item?.productName,
    );
  };

  const [isRefreshing, setIsRefreshing] = useState(false);
  const onListRefresh = async () => {
    setIsLazyLoader(false);
    setIsCatalogueLoader(true);
    catalogueList.length = 0;
    setCatalogueList(catalogueList);
    category = '';
    pageIndex = 0;
    getProductCatalogues(pageIndex, category);
    // console.warn('hey')
  };
  const onEndReached = async () => {
    // if (pageIndex > 0) {
    console.log('end');
    setIsLazyLoader(true);
    setTimeout(() => {
      getProductCatalogues(++pageIndex, category ? category?.item1 : '');
    }, 1000);

    // }
  };

  const View_Download_Button = (props: any) => {
    const { downloadPdf, item, name } = props;
    return (
      <TouchableOpacity
        activeOpacity={0.8}
        style={{ padding: 10 }}
        onPress={async () => {
          downloadPdf(item);
        }}
      >
        {/* <View style={styles.downloadDocument}>
          <Text
            style={{ marginRight: 8, color: config.fontAttribute.themeColor, fontSize: 12 }}>
            {t(name)}
          </Text>
          <Image style={{ tintColor: config.fontAttribute.themeColor }} source={RightArrow} />
        </View> */}
        <Image
          source={name}
          style={{
            width: 15,
            height: 15,
            tintColor: config.fontAttribute.themeColor,
          }}
        />
      </TouchableOpacity>
    );
  };

  const renderItem = (item: any) => {
    console.log(encodeURI(baseLinkURLProductCatalogue + item?.imageName));
    return (
      <View>
        <View style={styles.card}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            {/* <SvgXml height={70} width={70} xml={config.svgs.profileIcon} /> */}
            {/* <Image height={70} width={70} source={config.Images.book} style={{ tintColor: 'rgba(102,112,133,1)' }} /> */}
            <Image
              style={{ borderRadius: 10 }}
              height={70}
              width={70}
              source={{
                uri: encodeURI(baseLinkURLProductCatalogue + item?.imageName),
              }}
            />
            <View
              style={{
                marginLeft: 15,
                flexDirection: 'row',
                flex: 1,
                alignItems: 'center',
              }}
            >
              <View style={{ flex: 1 }}>
                <Text style={styles.productName}>{item?.productName}</Text>
                {/* <Text style={{ maxWidth: '80%', fontSize: 10, fontWeight: '500', color: config.fontAttribute.TextColor1 }}>
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
                </Text> */}
              </View>

              {/* <TouchableOpacity activeOpacity={0.8}
                style={{ padding: 5 }}
                onPress={async () => {
                  downloadPdf(item);
                }}
              >
                <View style={styles.downloadDocument}>
                  <Text
                    style={{ marginRight: 8, color: config.fontAttribute.themeColor, fontSize: 12 }}>
                    {t('download')}
                  </Text>
                  <Image style={{ tintColor: config.fontAttribute.themeColor }} source={RightArrow} />
                </View>
              </TouchableOpacity> */}

              <View style={{ flexDirection: 'row' }}>
                <View_Download_Button
                  downloadPdf={ViewPDF}
                  item={item}
                  name={config.Images.eye}
                />
                <View_Download_Button
                  downloadPdf={downloadPdf}
                  item={item}
                  name={config.Images.download}
                />
              </View>
            </View>
          </View>
          {/* </View> */}
        </View>
      </View>
    );
  };
  const skaletonData = [{}, {}, {}, {}, {}];
  const skeletonRenderItem = () => {
    return (
      <Skeleton>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginVertical: 10,
            borderWidth: 1,
            padding: 10,
            backgroundColor: '#fff',
            borderRadius: 4,
          }}
        >
          <View style={{ height: 70, width: 70, marginRight: 20 }}>
            {/* <View style={{ width: 150, height: 10, marginVertical: 3 }}></View>
                      <View style={{ width: 180, height: 10, marginVertical: 3 }}></View>
                      <View style={{ width: 60, height: 10, marginVertical: 3 }}></View> */}
          </View>
          <View>
            <View style={{ width: 170, height: 10, marginVertical: 3 }}></View>
            <View style={{ width: 200, height: 10, marginVertical: 3 }}></View>
            <View style={{ width: 80, height: 10, marginVertical: 3 }}></View>
          </View>
        </View>
      </Skeleton>
    );
  };
  return (
    <>
      <Headercomponent name={t('productCatalogue')} type={'2'} />
      <View style={styles.container}>
        <View style={{ flex: 1 }}>
          {/* Filter Lables Css Adjustment remaining and i18 for FilterModal */}
          {/* {
          filterLable != null ? <View style={styles.filterLable}>
            <Text ellipsizeMode='tail' numberOfLines={1} style={{ color: '#fff' }}>{filterLable}</Text>
            <TouchableOpacity activeOpacity={0.8} onPress={() => setFilterLable(null)}>
              <Image style={{ width: 10, height: 10, marginLeft: 5 }} source={config.Images.cross} />
            </TouchableOpacity>
          </View> : null
        } */}

          {/* <Text style={config.AppStyle.AppStyle.inputLabel}>{t('category')}</Text> */}
          <TouchableOpacity
            onPress={() => {
              dropDownClicked();
            }}
            activeOpacity={1}
          >
            <View
              style={[
                config.AppStyle.AppStyle.inputField,
                { justifyContent: 'space-between' },
              ]}
            >
              <TextInput
                style={{ color: config.fontAttribute.TextColor1 }}
                placeholderTextColor={config.fontAttribute.placeholderColor}
                placeholder={t('selectCategory')}
                editable={false}
                value={
                  category ? category?.item1 + ' - ' + category?.item2 : ''
                }
              />
              {/* {isClicked ? <Image style={styles.downArrow} source={config.Images.upArrowBlack} /> : */}
              <SvgXml
                xml={config.svgs.downArrowBlack}
                height={10}
                width={10}
                style={{ marginRight: 10 }}
              />
            </View>
          </TouchableOpacity>

          {isCatalogueLoader ? (
            <FlatList
              showsVerticalScrollIndicator={false}
              data={skaletonData}
              onEndReachedThreshold={0.7}
              renderItem={({ item }) => skeletonRenderItem()}
            />
          ) : (
            <>
              <FlatList
                // style={{ flexGrow: 0 ,backgroundColor:'red'}}
                showsVerticalScrollIndicator={false}
                onRefresh={onListRefresh}
                refreshing={isRefreshing}
                data={catalogueList}
                onEndReached={onEndReached}
                onEndReachedThreshold={0.7}
                ListEmptyComponent={NoData}
                renderItem={({ item }) => renderItem(item)}
                keyExtractor={item => item.id}
              />
              {isLazyLoader ? (
                <ActivityIndicator
                  size="small"
                  color={config.fontAttribute.themeColor}
                />
              ) : (
                <></>
              )}
            </>
          )}

          {/* <FAB
          size='large'
          onPress={onFilterIconClicked}
          placement='right'
          color={config.fontAttribute.themeColor}
          icon={(<SvgXml xml={config.svgs.filterIcon} height={27} width={27} />)} /> */}
        </View>
      </View>

      {/* Filter Modal */}
      {/* <FilterModal
        isOpen={isMenuOpen}
        onClose={toggleMenu}
        dropDownClicked={(e: any) => { onFilterdropDownClicked(e) }}
        isClicked={isClicked}
        onApplyButtonClicked={(e: any) => { onFilterApplyButtonClicked(e) }}
      /> */}

      {/* Category (List) Modal */}

      <CategoryListModal
        isOpen={isCategoryModal}
        onClose={toggleCategoryModal}
        data={categoryList}
        onApplyButtonClicked={(e: any) => {
          onApplyButtonClicked(e);
        }}
      />

      <LoadingModal isOpen={isDownloadLoader} onClose={toggleCategoryModal} />
    </>
  );
};

export default ProductCatalogue;
