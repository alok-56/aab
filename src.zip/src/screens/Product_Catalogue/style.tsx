import { StyleSheet } from "react-native";
import * as config from '../../config/index'
import { pixelValue } from "../../config/GlobalVariable";
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    flex: 1,
    marginTop: 5,
    padding: 20
  },
  card: {
    borderColor: 'rgba(102,112,133,0.4)',
    borderWidth: 1,
    // margin: 10,
    marginVertical: 5,
    width: 'auto',
    height: 'auto',
    borderRadius: 10,
    padding: 10,
    backgroundColor: config.fontAttribute.whiteColor,
    // elevation:5
  },
  productName: {
    maxWidth: '80%',
    fontSize: 12,
    fontWeight: '600',
    color: config.fontAttribute.themeColor
  },
  // '#EAF4FF'
  imageArea: {
    height: 100,
    borderRadius: 10,
    // borderColor: 'rgba(102,112,133,0.4)',
    // borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  DetailsRows: {
    flex: 1,
  },
  TypeRowItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 5
  },
  descriptionRowItem: {
    marginVertical: 3,
  },
  TypeTitle: {
    fontSize: 13 * pixelValue,
    color: config.fontAttribute.themeColor,
    fontWeight: '500',
    margin: 1
  },
  lineBreak: {
    borderColor: 'rgba(102,112,133,0.5)',
    borderWidth: 0.3,
    margin: 10,
  },
  downloadDocument: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginHorizontal: 5,
    marginTop: 2,
    // width:'85%'
    // backgroundColor:'red'
  },
  TypeValue: {
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    color: config.fontAttribute.TextColor1,
    fontWeight: '500',
    margin: 1
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    backgroundColor: config.fontAttribute.whiteColor,
    elevation: 5,
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 100
  },
  filterLable: {
    backgroundColor: config.fontAttribute.themeColor,
    width: 100,
    margin: 10,
    padding: 5,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start'
  },
  dashedLineBreak: {
    borderWidth: 0.3,
    borderColor: '#D0D5DD',
    borderStyle: 'dashed',
    marginVertical: 5
  },
  downArrow: {
    position: 'absolute',
    right: 15,
    bottom: 20
  },
})

export default styles;