import { View, Text, Modal, Image, StyleSheet, TextInput } from 'react-native'
import React, { SetStateAction, useState } from 'react'
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import * as config from '../../config/index'
import FilterListModal from './filterListModal';
import { pixelValue } from '../../config/GlobalVariable';

const FilterModal = (props: any) => {
    const { t, i18n } = useTranslation();

    const { isOpen, onClose, dropDownClicked, isClicked, onDropDownTextChanged, onApplyButtonClicked } = props;
    const [modalList, setModalList] = useState<any>(null);
    const [isListModalOpen, setIsListModalOpen] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState<any>(null);

    const toggleListModal = () => {
        setIsListModalOpen(!isListModalOpen);
    }
    const data = [
        {
            id: 1,
            isSelected: true,
            name: 'Category 1'
        },
        {
            id: 2,
            isSelected: false,
            name: 'Category 2'
        },
        {
            id: 3,
            isSelected: false,
            name: 'Category 3'
        }
    ]
    const listItemClicked = (item: any) => {
        setSelectedCategory(item?.name);
        toggleListModal();
    }
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={config.AppStyle.AppStyle.ModalOuterCss}>
                    <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                        <View style={config.AppStyle.AppStyle.ModalCrossIcon}>
                            <Image source={config.Images.cross} />
                        </View>
                    </TouchableOpacity>
                    <View style={[config.AppStyle.AppStyle.ModalInnerCss, { padding: 15, paddingHorizontal: 30 }]}>
                        <Text style={{ color: config.fontAttribute.themeColor, fontWeight: "500", fontSize: 20 * pixelValue, marginBottom: 15 }}>
                            {t('filter')}
                        </Text>
                        <Text style={config.AppStyle.AppStyle.inputLabel}>{t('productCategory')}</Text>
                        {/* <TextInput placeholder='--Select category--' style={config.AppStyle.AppStyle.inputField}/> */}

                        <TouchableOpacity
                            onPress={() => {
                                dropDownClicked('productCategory');
                                toggleListModal();
                                setModalList(data);
                            }}
                            activeOpacity={1}>
                            <View>
                                <TextInput
                                    onChangeText={onDropDownTextChanged}
                                    value={selectedCategory}
                                    editable={false}
                                    placeholder={t('selectCategory')}
                                    style={config.AppStyle.AppStyle.inputField} />
                                {isClicked ? <Image style={styles.downArrow} source={config.Images.upArrowBlack} /> :
                                    <Image style={styles.downArrow} source={config.Images.DownArrow} />}
                            </View>
                        </TouchableOpacity>

                        <TouchableOpacity style={config.AppStyle.AppStyle.button} activeOpacity={0.8} onPress={() => { onApplyButtonClicked(selectedCategory); setSelectedCategory(null) }}>
                            <Text style={config.AppStyle.AppStyle.buttonText}>{t('apply')}</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
            <FilterListModal
                isOpen={isListModalOpen}
                onClose={toggleListModal}
                modalList={modalList}
                listItemClicked={(e: any) => { listItemClicked(e) }} />
        </View>
    )
}

export default FilterModal

const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.8)'
    },
    innerModalView: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '100%',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        padding: 15,
        paddingHorizontal: 30
    },
    crossIcon: {
        alignItems: 'flex-end',
        marginBottom: 15,
        marginRight: 20,
        padding: 10
    }, downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 30
    },
})