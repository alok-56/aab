import { View, Text, Modal, Image, StyleSheet, TextInput, Switch, FlatList } from 'react-native'
import React, { SetStateAction, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import * as config from '../../config/index'
import { pixelValue } from '../../config/GlobalVariable';
import { ICategoryModel } from '../../AppModel/CommonListModel';

const CategoryListModal = (props: any) => {
    const { t, i18n } = useTranslation();

    const { isOpen, onClose, dropDownClicked, data, onApplyButtonClicked } = props;
    const [isListModalOpen, setIsListModalOpen] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState<any>(null);

    const toggleListModal = () => {
        setIsListModalOpen(!isListModalOpen);
    }
    useEffect(() => {
        setSelectedCategory(null)
    }, [])

    // const [isEnabled, setIsEnabled] = useState(false);

    const toggleSwitch = (item: any) => {
        item.item1 == selectedCategory?.item1
            ? setSelectedCategory('')
            : setSelectedCategory(item)
    }
    const renderItem = (item: any) => {
        return (
            <TouchableOpacity
                onPress={() => toggleSwitch(item)}
                activeOpacity={1}>
                <View
                    style={{
                        flexDirection: 'row',
                        borderColor: 'rgba(102,112,133,0.4)',
                        borderWidth: 0.5,
                        paddingHorizontal: 10,
                        paddingVertical: 15,
                        borderRadius: 10,
                        marginVertical: 10,
                        alignItems: 'center',
                        backgroundColor: '#fff'
                    }}>
                    <Switch
                        trackColor={{ false: '#EAECF0', true: '#1D93D1' }}
                        thumbColor={'#fff'}
                        ios_backgroundColor="#3e3e3e"
                        onValueChange={() => toggleSwitch(item)}
                        value={item.item1 == selectedCategory?.item1 ? true : false}
                    />
                    <Text style={{ marginLeft: 10, color: config.fontAttribute.TextColor1, fontWeight: '500', fontSize: 16 }}>
                        {item ? item?.item1 + '-' + item?.item2 : ''}
                    </Text>
                </View>
            </TouchableOpacity>
        )
    }
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={config.AppStyle.AppStyle.ModalOuterCss}>
                    <TouchableOpacity style={{ padding: 10 }} activeOpacity={0.9} onPress={onClose}>
                        <View style={config.AppStyle.AppStyle.ModalCrossIcon}>
                            <Image source={config.Images.cross} />
                        </View>
                    </TouchableOpacity>
                    <View style={[config.AppStyle.AppStyle.ModalInnerCss, { padding: 10, paddingHorizontal: 20 }]}>

                        <View style={{ padding: 10 }}>
                            <View>
                                <Text style={{ color: config.fontAttribute.TextColor1, fontSize: 12, fontWeight: '600' }}>{t('filterByCategory')}</Text>
                                <Text style={{ color: config.fontAttribute.TextColor1, fontSize: 10, fontWeight: '400' }} >{t('selectCategoryToViewCatalogues')}</Text>
                            </View>
                        </View>

                        <View style={{ borderWidth: 0.5, borderColor: 'rgba(102,112,133,0.4)', marginHorizontal: -30 }}></View>

                        <FlatList
                            showsVerticalScrollIndicator={false}
                            data={data}
                            onEndReachedThreshold={.7}
                            renderItem={({ item }) => renderItem(item)}
                            keyExtractor={item => item}
                        />

                        <View style={{ alignItems: 'flex-end' }}>
                            <TouchableOpacity style={[config.AppStyle.AppStyle.button,
                            {
                                marginTop: 10,
                                width: '30%'
                            }]} activeOpacity={0.8} onPress={() => { onApplyButtonClicked(selectedCategory); setSelectedCategory(null) }}>
                                <Text style={config.AppStyle.AppStyle.buttonText}>{t('add')}</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    )
}

export default CategoryListModal

const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.8)'
    },
    innerModalView: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '100%',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        padding: 15,
        paddingHorizontal: 30
    },
    crossIcon: {
        alignItems: 'flex-end',
        marginBottom: 15,
        marginRight: 20,
        padding: 10
    }, downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 30
    },
})