import { View, Text, Modal, TouchableOpacity, Image, StyleSheet, FlatList } from 'react-native'
import React from 'react'
import * as config from '../../config/index'
import { pixelValue } from '../../config/GlobalVariable';

const FilterListModal = (props: any) => {
  const { isOpen, onClose, modalList, listItemClicked } = props;
  return (
    <View>
      <Modal
        transparent={true}
        visible={isOpen}
        onRequestClose={onClose}
        animationType='none'>
        <View style={config.AppStyle.AppStyle.ModalOuterCss}>
          <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
            <View style={config.AppStyle.AppStyle.ModalCrossIcon}>
              <Image source={config.Images.cross} />
            </View>
          </TouchableOpacity>
          <View style={config.AppStyle.AppStyle.ModalInnerCss}>
            <FlatList style={{ marginTop: 20 }}
              data={modalList}
              renderItem={({ item }) =>
                <TouchableOpacity
                  onPress={() => listItemClicked(item)}
                  style={[styles.listItem]}
                  activeOpacity={0.7} >
                  <Text style={[styles.listItemText]}>{item.name}</Text>
                </TouchableOpacity>
              }
            />
          </View>
        </View>
      </Modal>
    </View>
  )
}

export default FilterListModal

const styles = StyleSheet.create({

  listItem: {
    backgroundColor: '#fff',
    height: 65,
    padding: 15,
    // borderColor :'#667085',
    // borderBottomWidth:0.7
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  listItemText: {
    color: '#3D5E87',
    fontWeight: '400',
    fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
  },
})