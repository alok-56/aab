import React, { useState, useCallback } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ActivityIndicator,
  Alert,
  ScrollView,
} from 'react-native';
import { Headercomponent } from '../../../Components';
import { useTranslation } from 'react-i18next';
import { AppStyle } from '../../../config/Style';
import { NavMenu } from '../../../config/GlobalVariable';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useSelector, shallowEqual } from 'react-redux';
import { useFocusEffect } from '@react-navigation/native';
import {
  GetBankingstatus,
  GetRetailerBankDetails,
  Sendbankingforverification,
} from '../../../ApiServices/httpServices';

const defaultBankData = {
  accountholdername: '',
  accountnumber: '',
  ifscCode: '',
  bankName: '',
  benaficeryId: '',
  gstin: '',
  panNumber: '',
  isbenverified: false,
  aadharnumber: '',
  isaadharverified: false,
  statusText: '',
};

const LoyalityProfile = (props: any) => {
  const { navigation } = props;
  const { t } = useTranslation();

  const profileDetail = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  const [bankData, setBankData] = useState<any>(defaultBankData);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);

  /* ================= Fetch On Focus ================= */
  useFocusEffect(
    useCallback(() => {
      fetchAllDetails();

    }, [profileDetail?.retailerCode]),
  );

  /* ================= Fetch Both APIs ================= */
  const fetchAllDetails = async () => {
    try {
      setInitialLoading(true);
      /* ---------- 1️⃣ Get Status API ---------- */
      const statusRes: any = await GetBankingstatus(
        profileDetail.retailerCode,
      );

      let statusData = statusRes?.data?.[0] || {};

      console.log(JSON.stringify(statusData,null,2))

      /* ---------- 2️⃣ Get Full Bank Details API ---------- */
      const params = {
        FromDate: '',
        ToDate: '',
        Status: '',
        RetailerCode: profileDetail?.retailerCode,
        SearchText: '',
        PageNumber: 1,
        PageSize: 10,
        GetAll: false,
      };

      const detailsRes: any = await GetRetailerBankDetails(params);
      let detailData = detailsRes?.details?.[0] || {};

      console.log(JSON.stringify(detailData,null,2))

      /* ---------- 3️⃣ Merge Data ---------- */
      setBankData({
        accountholdername:
          detailData?.AccountHolderName || '',
        accountnumber:
          detailData?.BankAccountNo || '',
        ifscCode:
          detailData?.IFSCCode || '',
        bankName:
          detailData?.BankName || '',
        benaficeryId:
          statusData?.benaficeryId || '',
        gstin:
          detailData?.GSTIN || '',
        panNumber:
          detailData?.PANNo || '',
        isbenverified:
          statusData?.isbenverified === true,
        aadharnumber:
          statusData?.aadharnumber || '',
        isaadharverified:
          statusData?.isaadharverified === true,
        statusText:
          detailData?.Status || '',
      });
    } catch (error) {
      console.log('Error fetching details:', error);
      setBankData(defaultBankData);
    } finally {
      setInitialLoading(false);
    }
  };

  /* ================= Send For Verification ================= */
  const handleBankVerification = async () => {
    try {
      setLoading(true);

      const response: any = await Sendbankingforverification(
        profileDetail.retailerCode,
      );

      if (response.status) {
        Alert.alert('Success', response.message);
        fetchAllDetails();
      } else {
        Alert.alert('Error', response.message);
      }
    } catch (error) {
      Alert.alert('Error', 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  if (initialLoading) {
    return (
      <SafeAreaView style={styles.loaderContainer}>
        <ActivityIndicator
          size="large"
          color={AppStyle.container.backgroundColor}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#F5F7FB' }}>
      <Headercomponent type={'2'} name={t('Profile')} />

      <ScrollView contentContainerStyle={styles.container}>
        {/* ================= Aadhaar Card ================= */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Aadhaar Status</Text>

          <DetailRow
            label="Aadhaar Number"
            value={bankData.aadharnumber || '—'}
          />

          <StatusBadge
            verified={bankData.isaadharverified}
          />

          {!bankData.isaadharverified && (
            <TouchableOpacity
              style={styles.secondaryButton}
              onPress={() =>
                navigation.navigate(NavMenu.Scheme.Kyc)
              }
            >
              <Text style={styles.secondaryButtonText}>
                Complete KYC
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {/* ================= Bank Card ================= */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Bank Details</Text>

          <DetailRow label="Account Holder" value={bankData.accountholdername || '—'} />
          <DetailRow label="Account Number" value={bankData.accountnumber || '—'} />
          <DetailRow label="IFSC Code" value={bankData.ifscCode || '—'} />
          <DetailRow label="Bank Name" value={bankData.bankName || '—'} />
          <DetailRow label="Beneficiary ID" value={bankData.benaficeryId || '—'} />
          <DetailRow label="GSTIN" value={bankData.gstin || '—'} />
          <DetailRow label="PAN Number" value={bankData.panNumber || '—'} />
          <DetailRow label="Application Status" value={bankData.statusText || '—'} />

          <StatusBadge verified={bankData.isbenverified} />

          {!bankData.isbenverified && (
            <View style={styles.buttonGroup}>
              <TouchableOpacity
                style={styles.primaryButton}
                onPress={handleBankVerification}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    <Icon
                      name="bank-check"
                      size={20}
                      color="#fff"
                    />
                    <Text style={styles.primaryButtonText}>
                      {' '}Send For Verification
                    </Text>
                  </>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.secondaryUpdateButton}
                onPress={() =>
                  navigation.navigate(
                    NavMenu.updateBankDetails,
                  )
                }
              >
                <Icon
                  name="bank-edit"
                  size={20}
                  color={
                    AppStyle.container.backgroundColor
                  }
                />
                <Text style={styles.secondaryUpdateText}>
                  {' '}Update Bank Details
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

/* ================= Reusable Components ================= */

const DetailRow = ({ label, value }: any) => (
  <View style={styles.detailRow}>
    <Text style={styles.label}>{label}</Text>
    <Text style={styles.value}>{value}</Text>
  </View>
);

const StatusBadge = ({ verified }: any) => (
  <View style={styles.statusRow}>
    <Text style={styles.label}>Verification</Text>
    <View style={styles.badgeContainer}>
      <Icon
        name={
          verified ? 'check-circle' : 'clock-outline'
        }
        size={18}
        color={verified ? '#4CAF50' : '#FF9800'}
      />
      <Text
        style={[
          styles.badgeText,
          { color: verified ? '#4CAF50' : '#FF9800' },
        ]}
      >
        {verified ? 'Verified' : 'Pending'}
      </Text>
    </View>
  </View>
);

export default LoyalityProfile;

/* ================= Styles ================= */

const styles = StyleSheet.create({
  container: { padding: 20 },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    elevation: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 15,
  },
  detailRow: { marginBottom: 12 },
  label: { fontSize: 13, color: '#777' },
  value: {
    fontSize: 15,
    fontWeight: '600',
    color: '#333',
  },
  statusRow: { marginTop: 10 },
  badgeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
  },
  badgeText: {
    marginLeft: 6,
    fontWeight: '600',
  },
  primaryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:
      AppStyle.container.backgroundColor,
    paddingVertical: 14,
    borderRadius: 12,
    marginTop: 12,
  },
  primaryButtonText: {
    color: '#fff',
    fontWeight: '700',
  },
  secondaryButton: {
    backgroundColor: '#E8F0FE',
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 12,
  },
  secondaryButtonText: {
    color:
      AppStyle.container.backgroundColor,
    fontWeight: '600',
  },
  buttonGroup: { marginTop: 10 },
  secondaryUpdateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 12,
    marginTop: 12,
    borderWidth: 1.5,
    borderColor:
      AppStyle.container.backgroundColor,
    backgroundColor: '#F4F8FF',
  },
  secondaryUpdateText: {
    color:
      AppStyle.container.backgroundColor,
    fontWeight: '700',
  },
});