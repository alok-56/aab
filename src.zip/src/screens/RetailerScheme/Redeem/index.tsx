import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Headercomponent } from '../../../Components';
import { useTranslation } from 'react-i18next';
import { AppStyle } from '../../../config/Style';
import { shallowEqual, useSelector } from 'react-redux';
import { getLocation } from '../../../config/GlobalVariable';
import {
  ReedemPoints,
  GetBankingstatus,
  GetDashboard,
} from '../../../ApiServices/httpServices';

const Redeem = (props: any) => {
  const { t } = useTranslation();

  const [points, setPoints] = useState('');
  const [holderName, setHolderName] = useState('');
  const [bankName, setBankName] = useState('');
  const [branchName, setBranchName] = useState('');
  const [accountNo, setAccountNo] = useState('');
  const [ifscCode, setIfscCode] = useState('');

  const [isRedeeming, setIsRedeeming] = useState(false);
  const [isLoadingBankDetails, setIsLoadingBankDetails] = useState(true);
  const [isLoadingDashboard, setIsLoadingDashboard] = useState(true);

  const [bankingDetails, setBankingDetails] = useState<any>(null);
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [canRedeem, setCanRedeem] = useState(false);

  const profileDetail: any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  const availablePoints = dashboardData?.availableamount || 0;

  useEffect(() => {
    fetchBankingDetails();
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setIsLoadingDashboard(true);
      const retailerCode = profileDetail?.retailerCode;

      if (!retailerCode) return;

      const result = await GetDashboard(retailerCode);
      if (result.status && result.data?.length) {
        setDashboardData(result.data[0]);
      }
    } catch (e) {
      console.log(e);
    } finally {
      setIsLoadingDashboard(false);
    }
  };

  const fetchBankingDetails = async () => {
    try {
      setIsLoadingBankDetails(true);
      const retailerCode = profileDetail?.retailerCode;

      if (!retailerCode) return;

      const result = await GetBankingstatus(retailerCode);

      if (result.status && result.data?.length) {
        const bank = result.data[0];
        setBankingDetails(bank);

        const valid = bank.benaficeryId && bank.accountnumber && bank.ifscCode;

        setCanRedeem(valid);

        if (valid) {
          setHolderName(bank.accountholdername || '');
          setAccountNo(bank.accountnumber || '');
          setIfscCode(bank.ifscCode || '');
          setBankName(bank.bankName || '');
        }
      } else {
        setCanRedeem(false);
      }
    } catch (e) {
      setCanRedeem(false);
    } finally {
      setIsLoadingBankDetails(false);
    }
  };

  const validateForm = () => {
    if (!canRedeem) {
      Alert.alert('Error', 'Complete banking details first');
      return false;
    }

    const num = parseInt(points);
    if (!points || isNaN(num) || num <= 0) {
      Alert.alert('Error', 'Enter valid points');
      return false;
    }

    if (num > availablePoints) {
      Alert.alert('Error', `Max redeem: ${availablePoints}`);
      return false;
    }

    return true;
  };

  const handleRedeem = async () => {
    if (!validateForm()) return;

    try {
      setIsRedeeming(true);

      const loc = await getLocation();

      const params = {
        Points: points,
        Retailercode: profileDetail?.retailerCode || '',
        ReedemAccType: 'Bank',
        Lat: loc?.latitude ? String(loc.latitude) : '',
        Long: loc?.longitude ? String(loc.longitude) : '',
        BeneficiaryId: bankingDetails?.benaficeryId || '',
        HolderName: holderName,
        AccountNo: accountNo,
        IfscCode: ifscCode,
        BankName: bankName,
        BranchName: branchName,
      };

      const res = await ReedemPoints(params);

      if (res.status) {
        await fetchDashboardData();
        Alert.alert('Success', res.message || 'Redeemed');

        setPoints('');
        props.navigation?.goBack();
      } else {
        Alert.alert('Error', res.message);
      }
    } catch (e) {
      Alert.alert('Error', 'Something went wrong');
    } finally {
      setIsRedeeming(false);
    }
  };

  const disableAll = isRedeeming || !canRedeem || availablePoints === 0;

  return (
    <SafeAreaView style={styles.container}>
      <Headercomponent
        type={'2'}
        name={t('Redeem Point')}
        onPress={() => props.navigation?.goBack()}
      />

      {isLoadingBankDetails || isLoadingDashboard ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color="#6B46C1" />
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {canRedeem ? null : (
            <Text style={{marginBottom:5,fontWeight:"bold",color:"red"}}>
              Please complete Kyc under Profile secetion then update banking
              details and send for verification
            </Text>
          )}

          {/* BLOCK INTERACTION SAFELY */}
          <View pointerEvents={disableAll ? 'none' : 'auto'}>
            <Text style={styles.questionText}>
              Redeem from ₹{availablePoints}
            </Text>

            <TextInput
              style={[styles.input, disableAll && styles.disabledInput]}
              value={points}
              onChangeText={setPoints}
              keyboardType="numeric"
              placeholder="Enter Points"
            />

            {/* Read-only fields */}
            <Text
              style={{
                fontSize: 14,
                color: 'blue',
                fontWeight: '600',
                padding: 5,
              }}
            >
              Bank Name
            </Text>
            <TextInput
              style={styles.readOnlyInput}
              value={bankName}
              pointerEvents="none"
              editable={false}
            />
            <Text
              style={{
                fontSize: 14,
                color: 'blue',
                fontWeight: '600',
                padding: 5,
              }}
            >
              Account Number
            </Text>
            <TextInput
              style={styles.readOnlyInput}
              value={accountNo}
              pointerEvents="none"
              editable={false}
            />
            <Text
              style={{
                fontSize: 14,
                color: 'blue',
                fontWeight: '600',
                padding: 5,
              }}
            >
              IFSC Code
            </Text>
            <TextInput
              style={styles.readOnlyInput}
              value={ifscCode}
              pointerEvents="none"
              editable={false}
            />

            {/* <TextInput
              style={styles.input}
              value={branchName}
              onChangeText={setBranchName}
              placeholder="Branch"
            /> */}

            <TouchableOpacity
              style={[
                styles.redeemButton,
                disableAll && { backgroundColor: '#ccc' },
              ]}
              onPress={handleRedeem}
              disabled={disableAll}
            >
              <Text style={styles.redeemButtonText}>Redeem</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      )}

      {/* Overlay handles blocking safely */}
      {isRedeeming && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color="#fff" />
          <Text style={{ color: '#fff', marginTop: 10 }}>Processing...</Text>
        </View>
      )}
    </SafeAreaView>
  );
};

export default Redeem;

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scrollContent: { padding: 20 },
  input: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  readOnlyInput: {
    backgroundColor: '#eee',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    borderWidth: 1,
  },
  disabledInput: { backgroundColor: '#f2f2f2' },
  questionText: { fontSize: 18, marginBottom: 10 },
  redeemButton: {
    backgroundColor: '#6B46C1',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  redeemButtonText: { color: '#fff', fontSize: 16 },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
