import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native'
import React, { SetStateAction, useEffect, useState } from 'react'
import { AppStyle } from '../../config/Style'
import * as config from '../../config/index'
import styles from './style'
import { useTranslation } from 'react-i18next'
import { Ilanguage } from '../../redux/datamodel/langDataModal'
import { shallowEqual, useDispatch, useSelector } from 'react-redux'
import { setSelecteLanguage } from '../../redux/actions/langAction'
import { SvgXml } from 'react-native-svg'

const ChangeLanguage = (props: any) => {

    const dispatch = useDispatch();
    const storeLanguage = useSelector((state: any) => state.lang.language,
        shallowEqual,)
    const [selectedLang, setSelectedLang] = useState<Ilanguage>({ languageId: 0, languageCode: "", languageName: "" })
    const { t, i18n } = useTranslation();
    const [isHindiSelected, setIsHindiSelected] = useState(false);
    const [isEnglishSelected, setIsEnglishSelected] = useState(false);

    useEffect(() => {
        console.log(storeLanguage);
        setSelectedLang(storeLanguage)
        switch (storeLanguage?.languageId) {
            case 1:
                setIsHindiSelected(true)
                break;
            case 2:
                setIsEnglishSelected(true)
                break;

            default:
                break;
        }
    }, [storeLanguage])


    const { navigation } = props;
    const onBackButtonClicked = () => {
        navigation.goBack();
    }
    const setLanuguageAsync = (selectedLanguage: string) => {
        let tempLang: Ilanguage = {
            languageCode: "",
            languageId: 0,
            languageName: ""
        }
        switch (selectedLanguage) {
            case "hi":
                tempLang.languageCode = selectedLanguage;
                tempLang.languageId = 1;
                tempLang.languageName = "Hindi"
                setSelectedLang(tempLang)
                break
            case "en":
                tempLang.languageCode = selectedLanguage;
                tempLang.languageId = 2;
                tempLang.languageName = "English"
                setSelectedLang(tempLang)
                break
            default:
                break;
        }
    };
    const changeLanuguageAsync = () => {
        console.log(selectedLang)
        dispatch(setSelecteLanguage(selectedLang));
        navigation.reset({
            index: 0,
            routes: [{ name: 'Home' }],
        });
    };
    return (
        <View style={[AppStyle.container, styles.Internalcontainer]}>
            <TouchableOpacity activeOpacity={0.8} onPress={onBackButtonClicked}>
                <Image source={config.Images.backArrowWhite} />
            </TouchableOpacity>
            <View style={[AppStyle.flex1, styles.section1]}>
                <Image source={config.Images.languageIcon} style={styles.languageIconImage} />
                <Text style={styles.languageText}>{t('language')}</Text>
            </View>
            <View style={[AppStyle.flex1, styles.section2]}>
                <TouchableOpacity style={[styles.languageOptions, { backgroundColor: isEnglishSelected ? 'rgba(255,255,255, 0.3)' : 'transparent' }]}
                    onPress={() => {
                        setLanuguageAsync("en");
                        setIsHindiSelected(false);
                        setIsEnglishSelected(true);
                    }} >
                    <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }} >
                        {
                            isEnglishSelected ?
                                <SvgXml xml={config.svgs.checkedCheckbox} height={18} width={18} />
                                : <SvgXml xml={config.svgs.uncheckedCheckbox} height={18} width={18} />
                        }
                        <Text style={styles.languageOptionsText}>{t('english')}</Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.languageOptions, { backgroundColor: isHindiSelected ? 'rgba(255,255,255, 0.3)' : 'transparent' }]}
                    onPress={() => {
                        setLanuguageAsync("hi");
                        setIsHindiSelected(true);
                        setIsEnglishSelected(false);
                    }} >

                    <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                        {
                            isHindiSelected ?
                                <SvgXml xml={config.svgs.checkedCheckbox} height={18} width={18} /> :
                                <SvgXml xml={config.svgs.uncheckedCheckbox} height={18} width={18} />
                        }
                        <Text style={styles.languageOptionsText}>{t('hindi')}</Text>
                    </View>
                </TouchableOpacity>
            </View>
            <View style={[AppStyle.flex1, styles.section3]}>
                <TouchableOpacity onPress={changeLanuguageAsync} activeOpacity={0.8} style={[AppStyle.button, { backgroundColor: 'white', width: '70%' }]}>
                    <Text style={[AppStyle.buttonText, { color: config.fontAttribute.themeColor }]}>{t('changeLanguage')}</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}



export default ChangeLanguage
