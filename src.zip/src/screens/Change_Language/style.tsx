import { StyleSheet } from "react-native";
import * as config from '../../config/index'
import { pixelValue } from "../../config/GlobalVariable";

const styles = StyleSheet.create({
    Internalcontainer: {
        padding: 20
    },
    languageText: {
        fontSize: config.fontAttribute.headingFontSizeSmall * pixelValue,
        fontWeight: '600',
        color: 'white',
        marginTop: 30,
        // backgroundColor:'blue'
    },
    languageIconImage: {
        tintColor: config.fontAttribute.whiteColor,
        height: 80,
        width: 80,
        // backgroundColor:'purple'
    },
    section1: {
        justifyContent: 'center',
        alignItems: 'center',
        // backgroundColor:'red'
    },
    section2: {
        flexDirection: 'row',
        alignItems: 'flex-start'
    },
    languageOptions: {
        borderColor: 'white',
        borderWidth: 1,
        borderRadius: 10,
        flex: 1,
        margin: 5,
        height: 80,
        alignItems: 'center',
        justifyContent: 'center',
    },
    languageOptionsText: {
        fontSize: config.fontAttribute.labelFontSizeExtraLarge * pixelValue,
        color: 'white',
        fontWeight: '500',
        marginLeft:8
    },
    section3: {
        alignItems: 'center'
    }
})
export default styles;