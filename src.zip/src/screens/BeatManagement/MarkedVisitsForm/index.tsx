import { View, Text, ScrollView, ActivityIndicator, ToastAndroid } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Headercomponent } from '../../../Components'
import { useTranslation } from 'react-i18next';
import { styles } from './style'
import { TextInput } from 'react-native-gesture-handler';
import * as config from '../../../config/index'
import { SvgXml } from 'react-native-svg';
import { TouchableOpacity } from 'react-native';
import ListViewModal from './listViewModal';
import Entypo from 'react-native-vector-icons/Entypo';
import { IDsrProfileDto } from '../../../AppModel/DsrProfileModal';
import { shallowEqual, useSelector } from 'react-redux';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { RadioButton, Text as PaperText } from 'react-native-paper';



const MarkedVisitsForm = (props: any) => {
    const { route, navigation } = props
    // const { selectedVisit } = props;
    const { t, i18n } = useTranslation();
    const [isOpenModal, setIsOpenModal] = useState(false)
    const [modalList, setModalList] = useState<any>([]);
    const [listType, setListType] = useState('')
    const [textField, setTextField] = useState({ remark: '' })
    const [currentLocation, setCurrentLocation] = useState(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.address)

    const [isOrder, setIsOrder] = useState<any>()
    const [isComplain, setIsComplain] = useState<any>()
    const [reason, setReason] = useState<any>()
    const [selectedRetailer, setSelectedRetailer] = useState<any>();
    const [isAttendenceMarked, setIsAttendenceMarked] = useState(false);
    const [visitId, setVisitId] = useState();
    const [allowRetailerSelection, setAllowRetailerSelection] = useState(true);
    const [isMarkVisitLoader, setIsMarkVisitLoader] = useState(false)
    const [selectedValue, setSelectedValue] = useState<any>()
    const profileDetail: IDsrProfileDto = useSelector(
        (state: any) => state.auth.profileData,
        shallowEqual,
    );
    const toggleModal = () => {
        setIsOpenModal(!isOpenModal)
    }
    const TypeOrders = 'IsOrders'
    const TypeComplains = 'IsComplain'
    const TypeReasons = 'Reasons'
    const TypeRetailers = 'Retailers'
    useEffect(() => {
        // console.log(route?.params?.selectedVisit)
        // setSelectedValue(retailers[0])
        // setListType(TypeRetailers)
        setTextField({ remark: props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.remark })
        setSelectedRetailer(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0])
        setIsAttendenceMarked(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isMarked)
        setVisitId(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.id)
        setIsOrder(
            props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isOrder ? {
                id: 1,
                name: "Yes"
            } : {
                id: 0,
                name: "No"
            }
        )
        setIsComplain(
            props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.complain
        )
        setReason(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.reason)
    }, [])

    const onDropdownClicked = (type: any) => {

        switch (type) {
            // case TypeOrders:
            //     setModalList(orderList)
            //     setListType(TypeOrders)
            //     toggleModal()
            //     setSelectedValue(isOrder)
            //     break;
            // case TypeComplains:
            //     setModalList(complainList)
            //     setListType(TypeComplains)
            //     toggleModal()
            //     setSelectedValue(isComplain)
            //     break;
            // case TypeReasons:
            //     setModalList(reasonsList)
            //     setListType(TypeReasons)
            //     toggleModal()
            //     setSelectedValue(reason)
            //     break;
            case TypeRetailers:
                // setModalList(retailersList)
                setModalList(props?.route?.params?.selectedVisit?.beat?.beatRetailers)
                setListType(TypeRetailers)
                toggleModal()
                setSelectedValue(selectedRetailer)
                break;
            default:
                break;
        }
    }
    const onListItemClicked = (item: any, type: any) => {
        console.log("here", item, type)
        switch (type) {
            // case TypeOrders:
            //     setIsOrder(item)
            //     setIsOpenModal(false)
            //     break;
            // case TypeComplains:
            //     setIsComplain(item?.name);
            //     setIsOpenModal(false)
            //     break;
            // case TypeReasons:
            //     setReason(item?.name)
            //     setIsOpenModal(false)
            //     break;
            case TypeRetailers:
                setSelectedRetailer(item)
                setIsOpenModal(false)
                setIsAttendenceMarked(item?.visits[0]?.isMarked)
                setVisitId(item?.visitId)
                setDropdownFields(item)
                setCurrentLocation(item?.visits[0]?.address)
                setTextField({ remark: item?.visits[0]?.remark })
                break;
            default:
                break;
        }
    }

    const setDropdownFields = (item: any = null) => {
        setIsOrder(
            item ? (item?.visits[0]?.isOrder != null ? (item?.visits[0]?.isOrder ? {
                id: 1,
                name: "Yes"
            } : {
                id: 0,
                name: "No"
            }) : null) : (selectedRetailer?.visits[0]?.isOrder !== null ? (selectedRetailer?.visits[0]?.isOrder ? {
                id: 1,
                name: "Yes"
            } : {
                id: 0,
                name: "No"
            }) : null)
        )
        setIsComplain(
            item ? item?.visits[0]?.complain : selectedRetailer?.visits[0]?.complain
        )
        setReason(item ? item?.visits[0]?.reason : selectedRetailer?.visits[0]?.reason)
    }
    return (
        <>
            <Headercomponent type={'2'} name={t('markedVisits')} />
            <View style={styles.container}>
                <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>

                    {/* Beat Name */}
                    <Text style={config.AppStyle.AppStyle.inputLabel}>{t('beatName')}</Text>
                    <TextInput
                        placeholder={t('beatName')}
                        editable={false}
                        style={[config.AppStyle.AppStyle.inputField, { color: config.fontAttribute.TextColor2 }]}
                        value={props?.route?.params?.selectedVisit?.beat?.beatName}
                    />

                    {/* Retailer Name */}
                    <Text style={config.AppStyle.AppStyle.inputLabel}>{t('retailerName')}</Text>
                    {/* <TextInput
                        placeholder={t('retailerName')}
                        editable={false}
                        style={[config.AppStyle.AppStyle.inputField, { color: config.fontAttribute.TextColor2 }]}
                        value={props?.route?.params?.selectedVisit?.retailerName}
                    /> */}
                    <TouchableOpacity
                        onPress={() =>
                            allowRetailerSelection
                                ? onDropdownClicked(TypeRetailers)
                                : ToastAndroid.show('Please Confirm your Attendence first !', ToastAndroid.SHORT)}
                        activeOpacity={0.9}>
                        <View style={[config.AppStyle.AppStyle.inputField, { flexDirection: 'row', justifyContent: 'space-between' }]}>
                            <TextInput editable={false}
                                style={{ color: config.fontAttribute.TextColor2 }}
                                value={selectedRetailer?.retailer?.retailerName}
                                placeholder={t('retailerName')}
                            />
                            <SvgXml xml={config.svgs.downArrowBlack} style={{ marginRight: 5 }} />
                        </View>
                    </TouchableOpacity>

                    {/* location */}
                    {isAttendenceMarked ?
                        <>
                            <Text style={config.AppStyle.AppStyle.inputLabel}>{t('location')}</Text>
                            <View style={config.AppStyle.AppStyle.inputField}>
                                <MaterialCommunityIcons name="map-marker" size={20} color={config.fontAttribute.themeColor} style={{ marginRight: 10 }} />
                                <Text style={styles.currentLocation}>{currentLocation}</Text>
                            </View>
                        </>
                        : <></>
                    }

                    {/* Attendence (marked) */}
                    <View>
                        <Text style={config.AppStyle.AppStyle.inputLabel}>{t('attendance')}{' (marked)'}</Text>
                        {isAttendenceMarked ?
                            <SvgXml
                                xml={config.svgs.checkedCheckbox}
                                height={14}
                                width={14}
                                style={{ marginVertical: 5, marginLeft: 1, marginTop: 4 }} />
                            :
                            <Entypo name='circle-with-cross' size={17} color={'red'} style={{ marginVertical: 5, }} />
                        }
                    </View>
                    {/* Attendence (confirmed) */}
                    <View>
                        <Text style={config.AppStyle.AppStyle.inputLabel}>{t('attendance')}{' (confirmed)'}</Text>
                        {selectedRetailer?.visits?.[0]?.isConfirmed ?
                            <SvgXml
                                xml={config.svgs.checkedCheckbox}
                                height={14}
                                width={14}
                                style={{ marginVertical: 5, marginLeft: 1, marginTop: 4 }} />
                            :
                            <Entypo name='circle-with-cross' size={17} color={'red'} style={{ marginVertical: 5, }} />
                        }
                    </View>
                    {/* </View> */}

                    {
                        selectedRetailer?.visits?.[0]?.isConfirmed &&
                        <>
                            {/* isOrder */}
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Text style={config.AppStyle.AppStyle.inputLabel}>{t('isOrder')}</Text>
                                <RadioButton.Group
                                    onValueChange={newValue => { }}
                                    value={isOrder?.name == 'Yes' ? 'yes' : 'no'}>
                                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                        <View style={styles.radioRow}>
                                            <View style={{ transform: [{ scale: 0.8 }] }}>
                                                <RadioButton
                                                    value="yes"
                                                    color={config.fontAttribute.themeColor}
                                                    disabled={true}
                                                // uncheckedColor="transparent" 
                                                />
                                            </View>
                                            <PaperText style={styles.radioLabel}>Yes</PaperText>
                                        </View>
                                        <View style={styles.radioRow}>
                                            <View style={{ transform: [{ scale: 0.8 }] }}>
                                                <RadioButton
                                                    value="no"
                                                    color={config.fontAttribute.themeColor}
                                                    disabled={true}
                                                // uncheckedColor="transparent" 
                                                />
                                            </View>
                                            <PaperText style={styles.radioLabel}>No</PaperText>
                                        </View>
                                    </View>
                                </RadioButton.Group>
                            </View>

                            {/* isComplain */}
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Text style={config.AppStyle.AppStyle.inputLabel}>{t('isComplain')}</Text>
                                <RadioButton.Group onValueChange={newValue => { }} value={isComplain == 'Yes' ? 'yes' : 'no'}>
                                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                        <View style={styles.radioRow}>
                                            <View style={{ transform: [{ scale: 0.8 }] }}>
                                                <RadioButton
                                                    value="yes"
                                                    color={config.fontAttribute.themeColor}
                                                    disabled={true}
                                                // uncheckedColor="transparent" 
                                                />
                                            </View>
                                            <PaperText style={styles.radioLabel}>Yes</PaperText>
                                        </View>
                                        <View style={styles.radioRow}>
                                            <View style={{ transform: [{ scale: 0.8 }] }}>
                                                <RadioButton
                                                    value="no"
                                                    color={config.fontAttribute.themeColor}
                                                    disabled={true}
                                                // uncheckedColor="transparent" 
                                                />
                                            </View>
                                            <PaperText style={styles.radioLabel}>No</PaperText>
                                        </View>
                                    </View>
                                </RadioButton.Group>
                            </View>

                            {/* Reasons */}
                            <Text style={[config.AppStyle.AppStyle.inputLabel, { marginTop: 5 }]}>{t('reason')}</Text>
                            <TouchableOpacity onPress={() => selectedRetailer?.visits[0]?.isConfirmed ? {} : onDropdownClicked(TypeReasons)} activeOpacity={0.9}>
                                <View style={[config.AppStyle.AppStyle.inputField, { flexDirection: 'row', justifyContent: 'space-between' }]}>
                                    <TextInput editable={false}
                                        style={{ color: config.fontAttribute.TextColor2 }}
                                        value={reason}
                                        placeholder={t('reason')}
                                    />
                                    <SvgXml xml={config.svgs.downArrowBlack} style={{ marginRight: 5 }} />
                                </View>
                            </TouchableOpacity>

                            {/* remarks  */}
                            {/* Have to add condition to show this if remark exists */}
                            <Text style={config.AppStyle.AppStyle.inputLabel}>{t('remark')}</Text>
                            <ScrollView style={[config.AppStyle.AppStyle.textArea, { maxHeight: 100 }]} showsVerticalScrollIndicator={false}>
                                <TextInput
                                    editable={false}
                                    value={textField.remark}
                                    selectionColor={config.fontAttribute.cursorColor}
                                    textAlignVertical='top'
                                    // onChangeText={e => selectedRetailer?.visits[0]?.isConfirmed ? {} : OnTextAreasChange(e, 'description')}
                                    style={[{ minHeight: 100, color: config.fontAttribute.textInputValueColor }]}
                                    multiline={true}
                                // numberOfLines={4} 
                                />
                            </ScrollView>
                        </>
                    }
                </ScrollView>
            </View>

            <ListViewModal
                isOpen={isOpenModal}
                onClose={toggleModal}
                modalList={modalList}
                listItemClicked={(type: any, item: any) => onListItemClicked(type, item)}
                listType={listType}
                selectedTypeValue={selectedValue} />
        </>
    )
}

export default MarkedVisitsForm