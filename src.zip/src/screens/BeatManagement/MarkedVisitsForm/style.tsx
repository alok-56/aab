import { StyleSheet } from "react-native";
import * as config from '../../../config/index'
import { pixelValue } from "../../../config/GlobalVariable";

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: config.fontAttribute.whiteColor,
        // margin: 10,
        padding: 20,
    },
    card: {
        borderColor: 'rgba(102,112,133,0.4)',
        borderWidth: 1,
        margin: 10,
        width: 'auto',
        height: 'auto',
        borderRadius: 10,
        padding: 10,
        backgroundColor: config.fontAttribute.whiteColor,
        // elevation:5
    },
    cardRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginVertical: 2
    },
    markVisitButton: {
        paddingVertical: 2,
        paddingHorizontal: 15,
        backgroundColor: '#EAF4FF',
        borderWidth: 1,
        borderRadius: 5,
        borderColor: '#DEEEFF',
        flexDirection: 'row',
        alignItems: 'center',
    },
    markVisitText: {
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        color: config.fontAttribute.TextColor2,
        fontWeight: '300'
    },
    currentLocation: {
        flex: 1,
        fontSize: config.fontAttribute.labelFontSize * pixelValue,
        color: config.fontAttribute.TextColor2,
        fontWeight: '300',
    },
    radioRow: {
        flexDirection: 'row',
        alignItems: 'center',
        // marginBottom: 8,
    },
    radioLabel: {
        fontSize: config.fontAttribute.labelFontSizeMedium,
    },
})