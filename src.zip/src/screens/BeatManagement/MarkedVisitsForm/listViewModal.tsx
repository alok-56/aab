import { View, Text, Modal, TouchableOpacity, Image, StyleSheet, FlatList } from 'react-native'
import React from 'react'
import * as config from '../../../config/index'
import { pixelValue } from '../../../config/GlobalVariable';
import { useTranslation } from 'react-i18next';

const ListViewModal = (props: any) => {
    const { t, i18n } = useTranslation();
    const { isOpen, onClose, modalList, listItemClicked, listType, selectedTypeValue } = props;
    const TypeOrders = 'IsOrders'
    const TypeComplains = 'IsComplain'
    const TypeReasons = 'Reasons'
    const TypeRetailers = 'Retailers'
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={styles.ModalView}>
                    <TouchableOpacity style={{ flex: 1 }} onPress={onClose}></TouchableOpacity>
                    <View style={styles.innerModalView}>
                        <View style={styles.crossIcon}>
                            <Text
                                style={{
                                    color: config.fontAttribute.themeColor,
                                    fontWeight: '500',
                                    fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
                                    textAlign: 'center',
                                    margin: 10
                                }}>{listType == TypeRetailers ? t('selectRetailer') : t('selectDistributor')}</Text>
                            <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                                <Image source={config.Images.crossBlack} />
                            </TouchableOpacity>
                        </View>
                        <FlatList style={{ marginTop: 20 }}
                            data={modalList}
                            renderItem={({ item }) =>
                                listType == TypeRetailers ?
                                    <TouchableOpacity
                                        onPress={() => listItemClicked(item, listType)}
                                        style={[styles.listItem]}
                                        activeOpacity={0.7} >
                                        <Text style={[styles.listItemText, { color: selectedTypeValue?.retailer?.retailerCode == item?.retailer?.retailerCode ? '#0051AC' : config.fontAttribute.TextColor1 }]}>{item?.retailer?.retailerName}</Text>
                                        {
                                            selectedTypeValue?.retailer?.retailerCode  == item?.retailer?.retailerCode ?
                                                <Image source={config.Images.tick} /> : null
                                        }
                                    </TouchableOpacity>
                                    :
                                    <TouchableOpacity
                                        onPress={() => listItemClicked(item, listType)}
                                        style={[styles.listItem]}
                                        activeOpacity={0.7} >
                                        <Text style={[styles.listItemText, { color: selectedTypeValue?.name == item?.name ? '#0051AC' : config.fontAttribute.TextColor1 }]}>{item?.name}</Text>
                                        {
                                            selectedTypeValue?.name == item?.name ?
                                                <Image source={config.Images.tick} /> : null
                                        }
                                    </TouchableOpacity>
                            }
                        />
                    </View>
                </View>
            </Modal>
        </View>
    )
}

export default ListViewModal

const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.8)'
    },
    innerModalView: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '100%',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        padding: 5,
        maxHeight:'60%',
    },
    crossIcon: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginHorizontal: 10
    },
    listItem: {
        backgroundColor: '#fff',
        height: 65,
        padding: 15,
        // borderColor :'#667085',
        // borderBottomWidth:0.7
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    listItemText: {
        color: '#3D5E87',
        fontWeight: '400',
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
    },
})