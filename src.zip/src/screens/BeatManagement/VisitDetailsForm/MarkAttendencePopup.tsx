import { View, Text, Modal, Image, StyleSheet, TextInput, Switch, FlatList, ActivityIndicator } from 'react-native'
import React, { SetStateAction, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import * as config from '../../../config/index'
import { RadioButton } from 'react-native-paper';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { pixelValue } from '../../../config/GlobalVariable';
// import RadioGroup from 'react-native-radio-buttons-group';

const MarkAttendencePopup = (props: any) => {
    const { t, i18n } = useTranslation();

    const { isOpen, onClose, submit, location, AttendanceLoader } = props;

    useEffect(() => {
        // setValue(filterValues[2])
    }, [])

    // const [isEnabled, setIsEnabled] = useState(false);

    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                {/* <View>
                    <TouchableOpacity activeOpacity={1}> */}
                <View style={styles.ModalView}>
                    <View style={[styles.innerModalView]}>
                        <View style={styles.titleView}>
                            <Text style={{
                                color: '#fff',
                                fontWeight: '600',
                                fontSize: 15,
                                textAlign: 'center'
                            }}>{t('Mark attendance')}</Text>
                        </View>

                        <View style={{
                            paddingHorizontal: 10,
                            marginVertical: 10
                            // alignItems: 'flex-start'
                        }}>
                            <View style={{ flexDirection: 'row', padding: 10, alignItems: 'center' }}>
                                {/* map-marker */}
                                <MaterialCommunityIcons name="map-marker" size={25} color={config.fontAttribute.themeColor} style={{ marginRight: 10 }} />
                                <Text style={styles.locationText}>{location}</Text>
                            </View>
                            {/* {
                                filterValues != null ? <Text>No filter available</Text> : */}
                            {/* <RadioButton.Group onValueChange={newValue => { onClose(); setValue(newValue) }} value={value}>
                                <FlatList
                                    data={filterValues}
                                    onEndReachedThreshold={.7}
                                    renderItem={({ item }) => renderItem(item)}
                                // keyExtractor={item => item?.id}
                                />
                            </RadioButton.Group> */}
                            {/* } */}
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <TouchableOpacity
                                activeOpacity={0.5}
                                onPress={onClose}
                                style={[styles.cancelButtonView,
                                { borderRightWidth: 0.5, borderRightColor: 'rgba(102,112,133,0.2)' }
                                ]}>
                                {/* <View > */}
                                <Text style={{ color: config.fontAttribute.TextColor1, fontWeight: '500' }}>{t('cancel')}</Text>
                                {/* </View> */}
                            </TouchableOpacity>
                            <TouchableOpacity
                                activeOpacity={0.5}
                                onPress={submit}
                                style={styles.cancelButtonView}>
                                {/* <View > */}
                                <Text style={{ color: config.fontAttribute.themeColor, fontWeight: '500' }}>{t('submit')}</Text>
                                {
                                    AttendanceLoader ?
                                        <ActivityIndicator size="small" color={config.fontAttribute.themeColor} style={{ marginLeft: 2 }} /> : <></>
                                }
                                {/* </View> */}
                            </TouchableOpacity>
                        </View>

                    </View>
                </View>
                {/* </TouchableOpacity></View> */}
            </Modal>
        </View>
    )
}

export default MarkAttendencePopup

const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0,0,0,0.8)'
    },
    innerModalView: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '90%',
        borderRadius: 10
    },
    crossIcon: {
        alignItems: 'flex-end',
        marginBottom: 15,
        marginRight: 20,
        padding: 10
    },
    downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 30
    },
    titleView: {
        backgroundColor: config.fontAttribute.themeColor,
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        padding: 15,
        justifyContent: 'center',
        alignItems: 'center'
    },
    cancelButtonView: {
        flex: 1,
        flexDirection: 'row',
        padding: 15,
        justifyContent: 'center',
        alignItems: 'center',
        borderTopColor: 'rgba(102,112,133,0.2)',
        borderTopWidth: 0.3
    },
    locationText: {
        flex: 1,
        fontSize: config.fontAttribute.labelFontSize * pixelValue,
        color: config.fontAttribute.TextColor2,
        fontWeight: '300'
    }
})