import { View, Text, ScrollView, ActivityIndicator, ToastAndroid, Platform, Alert } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Headercomponent } from '../../../Components'
import { useTranslation } from 'react-i18next';
import { styles } from './style'
import { TextInput } from 'react-native-gesture-handler';
import * as config from '../../../config/index'
import { SvgXml } from 'react-native-svg';
import { TouchableOpacity } from 'react-native';
import ListViewModal from './listViewModal';
import Entypo from 'react-native-vector-icons/Entypo';
import GetLocation from 'react-native-get-location'
import Geocoder from 'react-native-geocoding';
import { ConfirmAttendenceAgainstVisit, MarkAttendenceAgainstVisit } from '../../../ApiServices/httpServices';
import { result } from 'lodash';
import { IDsrProfileDto } from '../../../AppModel/DsrProfileModal';
import { shallowEqual, useSelector } from 'react-redux';
import { showMessage } from 'react-native-flash-message';
import MarkAttendancePopup from './MarkAttendencePopup';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { RadioButton, Text as PaperText } from 'react-native-paper';




const VisitDetailsForm = (props: any) => {
    const { route, navigation } = props
    // const { selectedVisit } = props;
    const { t, i18n } = useTranslation();

    const [orderValue, setOrderValue] = useState('');
    const [complainValue, setComplainValue] = useState('');

    const [isOpenModal, setIsOpenModal] = useState(false)
    const [isMarkAttendanceModal, setisMarkAttendanceModal] = useState(false)
    const [modalList, setModalList] = useState<any>([]);
    const [currentLocation, setCurrentLocation] = useState('Location not available.')
    const [listType, setListType] = useState('')
    const [textFields, setTextFields] = useState({ remark: '' })

    const [isOrder, setIsOrder] = useState<any>()
    const [isComplain, setIsComplain] = useState<any>()
    const [reason, setReason] = useState<any>()
    const [selectedRetailer, setSelectedRetailer] = useState<any>();
    const [isAttendanceMarked, setIsAttendanceMarked] = useState(false);
    const [visitId, setVisitId] = useState();
    const [allowRetailerSelection, setAllowRetailerSelection] = useState(
        (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits?.[0]?.isMarked
            &&
            props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits?.[0]?.isConfirmed)
        ||
        (!props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits?.[0]?.isMarked
            &&
            !props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits?.[0]?.isConfirmed)
    );
    const [isMarkVisitLoader, setIsMarkVisitLoader] = useState(false)
    const [isConfirmVisitLoader, setIsConfirmVisitLoader] = useState(false)
    const [selectedValue, setSelectedValue] = useState<any>()
    const profileDetail: IDsrProfileDto = useSelector(
        (state: any) => state.auth.profileData,
        shallowEqual,
    );
    const toggleModal = () => {
        setIsOpenModal(!isOpenModal)
    }
    const toggleMarkAttendanceModal = () => {
        setisMarkAttendanceModal(!isMarkAttendanceModal)
    }
    const TypeOrders = 'IsOrders'
    const TypeComplains = 'IsComplain'
    const TypeReasons = 'Reasons'
    const TypeRetailers = 'Retailers'
    useEffect(() => {
        console.log("location", currentLocation)
        // console.log("",props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits?.[0]?.isMarked
        //     && !props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits?.[0]?.isConfirmed)
        // console.log(route?.params?.selectedVisit)
        // setSelectedValue(retailers[0])
        // setListType(TypeRetailers)
        setTextFields({ remark: props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.remark })
        setCurrentLocation(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.address)
        setSelectedRetailer(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0])
        setIsAttendanceMarked(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isMarked)
        setVisitId(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.id)
        // setIsOrder(
        //     (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isConfirmed ?
        //         (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isOrder != null ?
        //             (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isOrder ? {
        //                 id: 1,
        //                 name: "Yes"
        //             } : {
        //                 id: 0,
        //                 name: "No"
        //             })
        //             : null)
        //         : null
        //     )
        // )
        setOrderValue(
            (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isConfirmed ?
                (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isOrder != null ?
                    (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isOrder ? 'yes' : 'no')
                    : '')
                : ''
            )
        )
        // setIsComplain(
        //     props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.complain
        // )
        setComplainValue(
            (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.isConfirmed ?
                (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.complain != null ?
                    (props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.complain ? 'yes' : 'no')
                    : '')
                : ''
            )
        )
        setReason(props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.reason ?
            props?.route?.params?.selectedVisit?.beat?.beatRetailers[0]?.visits[0]?.reason :
            reasonsList[0]?.name
        )
    }, [])

    const orderList = [
        {
            id: 0,
            name: "No"
        },
        {
            id: 1,
            name: "Yes"
        }
    ]
    const complainList = [
        {
            id: 0,
            name: "No"
        },
        {
            id: 1,
            name: "Yes"
        }
    ]
    const reasonsList = [
        {
            id: 0,
            name: "-- Select --"
        },
        {
            id: 1,
            name: "Reason 1"
        },
        {
            id: 2,
            name: "Reason 2"
        },
        {
            id: 3,
            name: "Reason 3"
        }
    ]
    const onDropdownClicked = (type: any) => {

        switch (type) {
            case TypeOrders:
                setModalList(orderList)
                setListType(TypeOrders)
                toggleModal()
                setSelectedValue(isOrder)
                break;
            case TypeComplains:
                setModalList(complainList)
                setListType(TypeComplains)
                toggleModal()
                setSelectedValue(isComplain)
                break;
            case TypeReasons:
                setModalList(reasonsList)
                setListType(TypeReasons)
                toggleModal()
                setSelectedValue(reason)
                break;
            case TypeRetailers:
                // setModalList(retailersList)
                setModalList(props?.route?.params?.selectedVisit?.beat?.beatRetailers)
                setListType(TypeRetailers)
                toggleModal()
                setSelectedValue(selectedRetailer)
                break;
            default:
                break;
        }
    }
    const onListItemClicked = (item: any, type: any) => {
        console.log("here", item, type)
        switch (type) {
            case TypeOrders:
                setIsOrder(item)
                setIsOpenModal(false)
                break;
            case TypeComplains:
                setIsComplain(item?.name);
                setIsOpenModal(false)
                break;
            case TypeReasons:
                setReason(item?.name)
                setIsOpenModal(false)
                break;
            case TypeRetailers:
                setSelectedRetailer(item)
                setIsOpenModal(false)
                setIsAttendanceMarked(item?.visits[0]?.isMarked)
                setVisitId(item?.visits?.[0]?.id)
                setCurrentLocation(item?.visits[0]?.address)
                setDropdownFields(item)
                if (
                    item?.visits?.[0]?.isMarked && !item?.visits?.[0]?.isConfirmed
                ) { setAllowRetailerSelection(false) } else { setAllowRetailerSelection(true) }
                break;
            default:
                break;
        }
    }

    const reverseGeocode = async (latitude: any, longitude: any) => {
        const apiKey = 'cfdbaa69fbe95a3906f0702295a2176f'; //have to make global
        try {
            const response = await fetch(`https://apis.mapmyindia.com/advancedmaps/v1/${apiKey}/rev_geocode?lat=${latitude}&lng=${longitude}    `);
            const data = await response.json();

            // Extract address from the response
            const address = data

            return address;
        } catch (error) {
            console.error(error);
            return null;
        }
    };
    const getLocation = () => {
        GetLocation.getCurrentPosition({
            enableHighAccuracy: true,
            timeout: 60000,
        })
            .then(location => {
                setIsMarkVisitLoader(false)
                console.log("currentLocation", location);

                reverseGeocode(location?.latitude, location?.longitude)
                    .then(address => {
                        console.log("Address:", address);
                        if (address?.responseCode == 200) {
                            setCurrentLocation(address?.results?.[0]?.formatted_address)
                            setisMarkAttendanceModal(true)
                            // MarkAttendance(address?.results?.[0]?.formatted_address)
                        } else {
                            showMessage({ message: address?.error, color: "white", duration: 3000, animated: true, backgroundColor: "red" })
                        }
                        // Display address in your app UI
                    })
                    .catch(error => {
                        console.error("Error:", error?.message);
                        showMessage({ message: error?.message, color: "white", duration: 3000, animated: true, backgroundColor: "red" })
                        // Handle errors
                    });
            })
            .catch(error => {
                setIsMarkVisitLoader(false)
                const { code, message } = error;
                showMessage({ message: message, color: "white", duration: 3000, animated: true, backgroundColor: "red" })
                console.warn("location Error", code, message);
            })
    }

    const setDropdownFields = (item: any = null) => {
        setTextFields({
            remark:
                item
                    ? item?.visits[0]?.remark
                    : selectedRetailer?.visits[0]?.remark
        })
        // if (item) {
        //     setCurrentLocation(
        //         item
        //             ? item?.visits[0]?.address
        //             : selectedRetailer?.visits[0]?.address
        //     )
        // }
        setOrderValue(
            item?.visits[0]?.isConfirmed ?
                (item ? (item?.visits[0]?.isOrder != null ? (item?.visits[0]?.isOrder ? 'yes' : 'no') : '')
                    : (selectedRetailer?.visits[0]?.isOrder != null ? (selectedRetailer?.visits[0]?.isOrder ? 'yes' : 'no') : '')) : ''
        )
        // setIsComplain(
        //     item ? item?.visits[0]?.complain : selectedRetailer?.visits[0]?.complain
        // )
        setComplainValue(
            item
                ? (item?.visits[0]?.complain != null ? item?.visits[0]?.complain == 'Yes' ? 'yes' : 'no' : '')
                : (selectedRetailer?.visits[0]?.complain != null ? selectedRetailer?.visits[0]?.complain == 'Yes' ? 'yes' : 'no' : '')
        )
        setReason(item ? item?.visits[0]?.reason : selectedRetailer?.visits[0]?.reason)
    }
    const MarkAttendance = (address: any) => {
        setIsMarkVisitLoader(true)
        const date = new Date();
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is zero-based, so add 1
        const day = String(date.getDate()).padStart(2, '0');

        // Combine into the desired format
        const formattedString = `${year}-${month}-${day} 00:00:00.000`;
        const params = {
            "DSRId": profileDetail?.dsrId,
            "BeatId": props?.route?.params?.selectedVisit?.beatId,
            "VisitDate": formattedString,
            "RetailerCode": selectedRetailer?.retailerCode,
            "Address": address
        }
        console.log("mark attendance params", params)
        MarkAttendenceAgainstVisit(params).then((result: any) => {
            console.log("markAttendance", result)
            toggleMarkAttendanceModal()
            setIsMarkVisitLoader(false)
            setAllowRetailerSelection(false)
            setIsAttendanceMarked(result?.isMarked)
            setVisitId(result?.id)
            setCurrentLocation(result?.address)
            setDropdownFields()
        }).catch((error: any) => {
            setIsMarkVisitLoader(false)
            // showMessage({ message: error?.message, color: "white", duration: 3000, animated: true, backgroundColor: "red" })
            console.log("mark Attendance", error)
        })
    }
    const onMarkVisitClicked = () => {
        setIsMarkVisitLoader(true)
        // MarkAttendance()
        getLocation();
    }
    const ConfirmAttendance = () => {
        if (
            // isOrder == null ||
            // isComplain == null ||
            orderValue == '' ||
            complainValue == ''
            // reason == null
        ) {
            showMessage({ message: "All fields are required !", backgroundColor: 'red', color: 'white', duration: 1000 });
            return;
        } else {
            setIsConfirmVisitLoader(true)
        }
        const params = {
            "VisitId": visitId,
            // "IsOrder": isOrder?.id,
            // "Complain": isComplain,
            "IsOrder": orderValue == 'yes' ? 1 : 0,
            "Complain": complainValue == 'yes' ? 'Yes' : 'No',
            "Reason": reason == '-- Select --' ? 'None' : reason,
            "Remark": textFields.remark
        }
        console.log("Confirm Attendance params", params)
        ConfirmAttendenceAgainstVisit(params, visitId).then((result: any) => {
            console.log("confirm Attendance", result)
            if (result) {
                setIsConfirmVisitLoader(false)
                navigation.goBack()
            }
        }).catch((error: any) => {
            setIsConfirmVisitLoader(false)
            console.log("confirm Attendance", error)
        })
    }
    const onSubmitPressed = () => {
        ConfirmAttendance()
    }
    const onMarkSubmitPressed = () => {
        // toggleMarkAttendanceModal()
        console.log(currentLocation, "currentLocation")
        MarkAttendance(currentLocation)
    }
    const OnTextAreasChange = (text: any, type: any) => {
        switch (type) {
            case 'description':
                setTextFields({ remark: text })
                break;
            default:
                break;
        }
    }
    return (
        <>
            <Headercomponent type={'2'} name={t('visitDetails')} />
            <View style={styles.container}>
                <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>

                    {/* Beat Name */}
                    <Text style={config.AppStyle.AppStyle.inputLabel}>{t('beatName')}</Text>
                    <TextInput
                        placeholder={t('beatName')}
                        editable={false}
                        style={[config.AppStyle.AppStyle.inputField, { color: config.fontAttribute.TextColor2 }]}
                        value={props?.route?.params?.selectedVisit?.beat?.beatName}
                    />

                    {/* Retailer Name */}
                    <Text style={config.AppStyle.AppStyle.inputLabel}>{t('retailerName')}</Text>
                    {/* <TextInput
                        placeholder={t('retailerName')}
                        editable={false}
                        style={[config.AppStyle.AppStyle.inputField, { color: config.fontAttribute.TextColor2 }]}
                        value={props?.route?.params?.selectedVisit?.retailerName}
                    /> */}
                    <TouchableOpacity
                        onPress={() =>
                            allowRetailerSelection
                                ? onDropdownClicked(TypeRetailers)
                                :
                                (Platform.OS == 'android'
                                    ? ToastAndroid.show('Please Confirm your Attendance for selected retailer first !', ToastAndroid.SHORT)
                                    : Alert.alert('Please Confirm your Attendance for selected retailer first !'))
                        }
                        activeOpacity={0.9}>
                        <View style={[config.AppStyle.AppStyle.inputField, { flexDirection: 'row', justifyContent: 'space-between' }]}>
                            <TextInput editable={false}
                                style={{ color: config.fontAttribute.TextColor2 }}
                                value={selectedRetailer?.retailer?.retailerName}
                                placeholder={t('retailerName')}
                            />
                            <SvgXml xml={config.svgs.downArrowBlack} style={{ marginRight: 5 }} />
                        </View>
                    </TouchableOpacity>

                    {/* Attendance */}
                    {/* <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginVertical: 10, alignItems: 'center' }}> */}
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 5 }}>
                        <View>

                            <Text style={config.AppStyle.AppStyle.inputLabel}>{t('attendance')}</Text>
                            {isAttendanceMarked ?
                                <SvgXml xml={config.svgs.checkedCheckbox} height={15} width={15} style={{ marginVertical: 5 }} />
                                :
                                <Entypo name='circle-with-cross' size={17} color={'red'} style={{ marginVertical: 5 }} />
                            }
                        </View>
                        {/* Mark Visit Button */}
                        {
                            !isAttendanceMarked &&
                            <TouchableOpacity style={styles.markVisitButton} activeOpacity={0.8} onPress={onMarkVisitClicked}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={styles.markVisitText}>{t('markvisit')}</Text>
                                    {
                                        isMarkVisitLoader ?
                                            <ActivityIndicator size={10} color={config.fontAttribute.whiteColor} style={{ marginLeft: 5 }} />
                                            : <></>
                                    }
                                </View>
                            </TouchableOpacity>
                        }
                    </View>

                    {/* </View> */}

                    {
                        isAttendanceMarked &&
                        <>
                            {/* location */}
                            <Text style={config.AppStyle.AppStyle.inputLabel}>{t('location')}</Text>
                            <View style={[config.AppStyle.AppStyle.inputField, { height: 'auto',paddingVertical:10 }]}>
                                <MaterialCommunityIcons name="map-marker" size={20} color={config.fontAttribute.themeColor} style={{ marginRight: 10 }} />
                                <Text style={styles.currentLocation}>{currentLocation}</Text>
                            </View>
                            {/* isOrder */}
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Text style={config.AppStyle.AppStyle.inputLabel}>{t('isOrder')}<RedStar /></Text>
                                <RadioButton.Group onValueChange={newValue => setOrderValue(newValue)} value={orderValue}>
                                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                        <View style={styles.radioRow}>
                                            <View style={{ transform: [{ scale: 0.8 }] }}>
                                                <RadioButton
                                                    value="yes"
                                                    color={config.fontAttribute.themeColor}
                                                    disabled={selectedRetailer?.visits[0]?.isConfirmed ? true : false}
                                                // uncheckedColor="transparent" 
                                                />
                                            </View>
                                            <PaperText style={styles.radioLabel}>Yes</PaperText>
                                        </View>
                                        <View style={styles.radioRow}>
                                            <View style={{ transform: [{ scale: 0.8 }] }}>
                                                <RadioButton
                                                    value="no"
                                                    color={config.fontAttribute.themeColor}
                                                    disabled={selectedRetailer?.visits[0]?.isConfirmed ? true : false}
                                                // uncheckedColor="transparent" 
                                                />
                                            </View>
                                            <PaperText style={styles.radioLabel}>No</PaperText>
                                        </View>
                                    </View>
                                </RadioButton.Group>
                            </View>
                            {/* <TouchableOpacity onPress={() => selectedRetailer?.visits[0]?.isConfirmed ? {} : onDropdownClicked(TypeOrders)} activeOpacity={0.9}>
                                <View style={[config.AppStyle.AppStyle.inputField, { flexDirection: 'row', justifyContent: 'space-between' }]}>
                                    <TextInput
                                        editable={false}
                                        style={{ color: config.fontAttribute.TextColor2 }}
                                        value={isOrder?.name}
                                        placeholder={t('isOrder')}
                                    />
                                    <SvgXml xml={config.svgs.downArrowBlack} style={{ marginRight: 5 }} />
                                </View>
                            </TouchableOpacity> */}

                            {/* isComplain */}
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Text style={config.AppStyle.AppStyle.inputLabel}>{t('isComplain')}<RedStar /></Text>
                                <RadioButton.Group onValueChange={newValue => setComplainValue(newValue)} value={complainValue}>
                                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                        <View style={styles.radioRow}>
                                            <View style={{ transform: [{ scale: 0.8 }] }}>
                                                <RadioButton
                                                    value="yes"
                                                    color={config.fontAttribute.themeColor}
                                                    disabled={selectedRetailer?.visits[0]?.isConfirmed ? true : false}
                                                // uncheckedColor="transparent" 
                                                />
                                            </View>
                                            <PaperText style={styles.radioLabel}>Yes</PaperText>
                                        </View>
                                        <View style={styles.radioRow}>
                                            <View style={{ transform: [{ scale: 0.8 }] }}>
                                                <RadioButton
                                                    value="no"
                                                    color={config.fontAttribute.themeColor}
                                                    disabled={selectedRetailer?.visits[0]?.isConfirmed ? true : false}
                                                // uncheckedColor="transparent" 
                                                />
                                            </View>
                                            <PaperText style={styles.radioLabel}>No</PaperText>
                                        </View>
                                    </View>
                                </RadioButton.Group>
                            </View>
                            {/* <TouchableOpacity onPress={() => selectedRetailer?.visits[0]?.isConfirmed ? {} : onDropdownClicked(TypeComplains)} activeOpacity={0.9}>
                                <View style={[config.AppStyle.AppStyle.inputField, { flexDirection: 'row', justifyContent: 'space-between' }]}>
                                    <TextInput editable={false}
                                        style={{ color: config.fontAttribute.TextColor2 }}
                                        value={isComplain}
                                        placeholder={t('isComplain')}
                                    />
                                    <SvgXml xml={config.svgs.downArrowBlack} style={{ marginRight: 5 }} />
                                </View>
                            </TouchableOpacity> */}

                            {/* Reasons */}
                            <Text style={[config.AppStyle.AppStyle.inputLabel, { marginTop: 5 }]}>{t('reason')}</Text>
                            <TouchableOpacity onPress={() => selectedRetailer?.visits[0]?.isConfirmed ? {} : onDropdownClicked(TypeReasons)} activeOpacity={0.9}>
                                <View style={[config.AppStyle.AppStyle.inputField, { flexDirection: 'row', justifyContent: 'space-between' }]}>
                                    <TextInput editable={false}
                                        style={{ color: config.fontAttribute.TextColor2 }}
                                        value={reason}
                                        placeholder={t('-- select --')}
                                    />
                                    <SvgXml xml={config.svgs.downArrowBlack} style={{ marginRight: 5 }} />
                                </View>
                            </TouchableOpacity>

                            {/* Remark */}
                            <Text style={config.AppStyle.AppStyle.inputLabel}>{t('remark')}</Text>
                            <ScrollView style={[config.AppStyle.AppStyle.textArea, { maxHeight: 100 }]} showsVerticalScrollIndicator={false}>
                                <TextInput
                                    editable={selectedRetailer?.visits[0]?.isConfirmed ? false : true}
                                    value={textFields.remark}
                                    selectionColor={config.fontAttribute.cursorColor}
                                    textAlignVertical='top'
                                    onChangeText={e => selectedRetailer?.visits[0]?.isConfirmed ? {} : OnTextAreasChange(e, 'description')}
                                    style={[{ minHeight: 100, color: config.fontAttribute.textInputValueColor }]}
                                    multiline={true}
                                // numberOfLines={4} 
                                />
                            </ScrollView>
                        </>
                    }
                </ScrollView>
            </View>
            {
                isAttendanceMarked && !selectedRetailer?.visits[0]?.isConfirmed &&
                <View style={{ backgroundColor: config.fontAttribute.whiteColor }}>
                    <TouchableOpacity
                        style={[config.AppStyle.AppStyle.button, { marginTop: 0, margin: 10, flexDirection: 'row', alignItems: 'center' }]}
                        activeOpacity={0.8}
                        onPress={onSubmitPressed}>
                        <Text style={config.AppStyle.AppStyle.buttonText}>{t('submit')}</Text>
                        {
                            isConfirmVisitLoader &&
                            <ActivityIndicator size={15} color={config?.fontAttribute?.whiteColor} style={{ marginLeft: 10 }} />
                        }
                    </TouchableOpacity>
                </View>
            }
            <ListViewModal
                isOpen={isOpenModal}
                onClose={toggleModal}
                modalList={modalList}
                listItemClicked={(type: any, item: any) => onListItemClicked(type, item)}
                listType={listType}
                selectedTypeValue={selectedValue} />

            <MarkAttendancePopup
                isOpen={isMarkAttendanceModal}
                onClose={toggleMarkAttendanceModal}
                location={currentLocation}
                submit={onMarkSubmitPressed}
                AttendanceLoader={isMarkVisitLoader}
            />
        </>
    )
}

export default VisitDetailsForm

const RedStar = () => {
    return (
        <View>
            <Text style={{ color: 'red' }}>*</Text>
        </View>
    )
}