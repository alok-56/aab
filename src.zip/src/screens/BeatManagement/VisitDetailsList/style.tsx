import { StyleSheet } from "react-native";
import * as config from '../../../config/index'
import { pixelValue } from "../../../config/GlobalVariable";

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: config.fontAttribute.whiteColor,
        // margin: 10,
        padding: 10,
    },
    card: {
        borderColor: 'rgba(102,112,133,0.4)',
        borderWidth: 1,
        margin: 10,
        width: 'auto',
        height: 'auto',
        borderRadius: 10,
        // padding: 10,
        backgroundColor: config.fontAttribute.whiteColor,
        // flexDirection:'row'
        // elevation:5
    },
    cardRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginVertical: 5
    },
    rowValue: {
        color: config.fontAttribute.TextColor1,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600'
    },
    rowTitle: {
        color: config.fontAttribute.TextColor2,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600'
    },
    cardTitle: {
        color: config.fontAttribute.whiteColor,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
    },
    cardTitleContainer: {
        backgroundColor: config.fontAttribute.themeColor,  // Background color behind the text
        paddingHorizontal: 15,       // Horizontal padding for some space around the text
        paddingVertical: 5,          // Vertical padding for some space around the text
        alignSelf: 'flex-end',
        borderTopRightRadius: 9,
        borderBottomLeftRadius: 9,
        borderColor: config.fontAttribute.themeColor,
        borderWidth: 1 // Align the container to the right
        // borderRadius: 5,             // Optional: Rounded corners
    },
    chooseDate: {
        color: config.fontAttribute.TextColor2,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
        marginLeft: 2,
        letterSpacing: 1
    },
    chooseDateFieldValue: {
        flex: 1,
        color: config.fontAttribute.TextColor2,
        fontSize: config.fontAttribute.labelFontSizeMedium
    },
    iconContainer: {
        marginLeft: 10,
        width: 30,
        height: 30,
        borderRadius: 30,
        backgroundColor: config.fontAttribute.themeColor,
        justifyContent: 'center',
        alignItems: 'center',
        transform: [{ rotate: '45deg' }],
    },
})