import {useFocusEffect, useIsFocused} from '@react-navigation/native';
import React, {useState} from 'react';
import {useTranslation} from 'react-i18next';
import {
  Dimensions,
  FlatList,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import DatePicker from 'react-native-date-picker';
import IonIcons from 'react-native-vector-icons/Ionicons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {shallowEqual, useSelector} from 'react-redux';
import {GetAssignedBeatsForDSRByDate} from '../../../ApiServices/httpServices';
import {IDsrProfileDto} from '../../../AppModel/DsrProfileModal';
import {Headercomponent} from '../../../Components';
import NoData from '../../../Components/No_Data_Component';
import Skeleton from '../../../Components/skeleton/skeleton';
import {
  ConvertDateFormat,
  NavMenu,
  pixelValue,
} from '../../../config/GlobalVariable';
import * as config from '../../../config/index';
import {styles} from './style';

const VisitDetailsList = ({navigation, route}: any) => {
  const {t, i18n} = useTranslation();
  const [date, setDate] = useState(new Date());
  const [openDatePicker, setOpenDatePicker] = useState(false);
  const [allVisits, setAllVisits] = useState<Array<any>>();
  const [isVisitsLoader, setIsVisitsLoader] = useState(false);
  const [ViewHeight, setViewHeight] = useState(65);
  const onDatePickerIconClicked = () => {
    setOpenDatePicker(true);
  };
  const isFocused = useIsFocused();
  useFocusEffect(
    React.useCallback(() => {
      if (isFocused) {
        getAllVisits(date);
      }
    }, [isFocused]),
  );
  // useEffect(() => {

  // }, [])

  const profileDetail: IDsrProfileDto = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );
  const getAllVisits = (date: any) => {
    setIsVisitsLoader(true);
    // Input date string
    // const dateString = date.toString();
    // Creating a moment object from the string with the specific timezone
    // const date1 = moment(dateString);
    // Formatting the date in the desired format
    // const formattedString = date1.format('YYYY-MM-DDTHH:mm:ss.SSSSSSS');
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is zero-based, so add 1
    const day = String(date.getDate()).padStart(2, '0');

    // Combine into the desired format
    const formattedString = `${year}-${month}-${day} 00:00:00.000`;
    GetAssignedBeatsForDSRByDate(profileDetail?.dsrId, formattedString)
      .then(result => {
        console.log('all visits', result);
        setIsVisitsLoader(false);
        if (result?.statusCode == false) {
          setAllVisits([]);
        } else {
          setAllVisits(result);
        }
      })
      .catch((error: any) => {
        setIsVisitsLoader(false);
        console.log('all visits', error);
      });
  };

  const onPressOnCard = (item: any) => {
    route?.params?.fromPage == NavMenu?.beatPlanManagement?.markedVisits
      ? navigation.navigate(NavMenu.beatPlanManagement.markedVisitsForm, {
          selectedVisit: item,
        })
      : navigation.navigate(NavMenu.beatPlanManagement.visitDetailsForm, {
          selectedVisit: item,
        });
  };
  // Skeleton placeholder
  const skaletonData = [{}, {}, {}, {}, {}, {}, {}];
  const skeletonRenderItem = () => {
    return (
      <Skeleton>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            marginVertical: 10,
            backgroundColor: '#fff',
            borderRadius: 4,
          }}>
          <View
            style={{
              borderWidth: 1,
              padding: 5,
              borderColor: '#EAECF0',
              borderRadius: 10,
            }}>
            <View
              style={{
                height: 10,
                marginVertical: 5,
                width: Dimensions.get('window').width * 0.85,
              }}></View>
            <View
              style={{
                height: 10,
                marginVertical: 5,
                width: Dimensions.get('window').width * 0.85,
              }}></View>
            <View
              style={{
                height: 10,
                marginVertical: 5,
                width: Dimensions.get('window').width * 0.85,
              }}></View>
          </View>
        </View>
      </Skeleton>
    );
  };
  const onLayout = (event: any) => {
    const {height} = event.nativeEvent.layout;
    console.log('height', height);
    setViewHeight(height);
  };
  const renderItem = (index: any, item: any) => {
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={() => onPressOnCard(item)}>
        <View style={styles.card}>
          <View style={{flexGrow: 1, marginBottom: 10}}>
            <View style={styles.cardTitleContainer}>
              <Text style={styles.cardTitle}>Today's visit</Text>
            </View>
          </View>
          <View
            style={{
              flexDirection: 'row',
              padding: 10,
              paddingTop: 0,
              height: 'auto',
              alignItems: 'center',
            }}
            onLayout={onLayout}>
            <View
              style={{
                justifyContent: 'center',
                backgroundColor: '#EAF4FF',
                borderWidth: 1,
                borderRadius: 5,
                borderColor: '#DEEEFF',
                flexDirection: 'row',
                alignItems: 'center',
                marginRight: 10,
                width: ViewHeight - 10,
                height: '100%',
              }}>
              <Text
                style={{
                  color: config.fontAttribute.TextColor1,
                  fontSize:
                    config.fontAttribute.headingFontSizeSmall * pixelValue,
                  fontWeight: '500',
                }}>
                {index + 1}
              </Text>
            </View>
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
              }}>
              <Text
                style={{
                  color: config.fontAttribute.TextColor2,
                  fontSize:
                    config.fontAttribute.labelFontSizeLarge * pixelValue,
                  fontWeight: '600',
                }}>
                {item?.beatId}
              </Text>
              <Text
                style={{
                  color: config.fontAttribute.TextColor1,
                  fontSize: config.fontAttribute.labelFontSize * pixelValue,
                  fontWeight: '500',
                }}
                numberOfLines={1}>
                {item?.beat?.beatName}
              </Text>
              <Text
                style={{
                  color: config.fontAttribute.TextColor1,
                  fontSize:
                    config.fontAttribute.labelFontSizeMedium * pixelValue,
                  fontWeight: '500',
                }}>
                {item?.beat?.noOfRetailers} Retailers
              </Text>
            </View>
            <View
              style={{
                justifyContent: 'flex-end',
                alignSelf: 'flex-end',
              }}>
              <MaterialIcons
                name="arrow-forward"
                size={20}
                color={config.fontAttribute.TextColor2}
              />
            </View>
          </View>
          {/* <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Text style={[styles.cardTitle, { flex: 1 }]}>Today's visit</Text>
                        <View style={styles.iconContainer}>
                            <MaterialIcons name="arrow-upward" size={15} color="#fff" />
                        </View>
                    </View> */}
          {/* <View style={{flex:1}}> */}

          {/* <View style={{ padding: 10 }}>
                        <View style={styles.cardRow}>
                            <Text style={styles.rowTitle}>{t('beatID')}</Text>
                            <Text style={styles.rowValue}>{item?.beatId}</Text>
                        </View>
                        <View style={styles.cardRow}>
                            <Text style={styles.rowTitle}>{t('beatName')}</Text>
                            <Text style={styles.rowValue}>{item?.beat?.beatName}</Text>
                        </View>
                        <View style={styles.cardRow}>
                            <Text style={styles.rowTitle}>{t('assignedRetailers')}</Text>
                            <Text style={styles.rowValue}>{item?.beat?.noOfRetailers}</Text>
                        </View>
                    </View> */}

          {/* </View> */}
          {/* <View style={styles.cardRow}>
                        <Text style={styles.rowTitle}>{t('Retailers (Marked)')}</Text>
                        <Text style={styles.rowValue}>5</Text>
                    </View> */}
          {/* <View style={styles.cardRow}>
                        <Text style={styles.rowTitle}>{t('Retailers (Confirmed)')}</Text>
                        <Text style={styles.rowValue}>7</Text>
                    </View> */}
        </View>
      </TouchableOpacity>
    );
  };
  const onDateChanged = (date: any) => {
    setOpenDatePicker(false);
    setDate(date);
    getAllVisits(date);
  };
  const onListRefresh = () => {
    console.warn('hey');
    getAllVisits(date);
  };
  const onEndReached = () => {};
  const [isRefreshing, setIsRefreshing] = useState(false);

  return (
    <>
      <Headercomponent
        type={'2'}
        name={t(
          route?.params?.fromPage == NavMenu?.beatPlanManagement?.markedVisits
            ? 'markedVisits'
            : 'visitList',
        )}
      />
      <View style={styles.container}>
        {
          // route?.params?.fromPage == NavMenu?.beatPlanManagement?.markedVisits &&
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-around',
            }}>
            {/* Choose Date */}
            {/* <Text style={config.AppStyle.AppStyle.inputLabel}>Choose Date :</Text> */}
            <Text style={styles.chooseDate}>{t('chooseDate')}</Text>
            {/* Date field */}
            <View
              style={[
                config.AppStyle.AppStyle.inputField,
                {flex: 0.8, height: 40},
              ]}>
              <TextInput
                style={styles.chooseDateFieldValue}
                value={ConvertDateFormat(date)}
                editable={false}
              />
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={onDatePickerIconClicked}
                style={{padding: 5}}>
                <IonIcons
                  name="calendar"
                  size={20}
                  color={config.fontAttribute.themeColor}
                />
              </TouchableOpacity>
            </View>
          </View>
        }
        {isVisitsLoader ? (
          <FlatList
            showsVerticalScrollIndicator={false}
            data={skaletonData}
            // onEndReachedThreshold={.7}
            renderItem={({item}) => skeletonRenderItem()}
          />
        ) : (
          <FlatList
            showsVerticalScrollIndicator={false}
            onRefresh={onListRefresh}
            refreshing={isRefreshing}
            onEndReached={onEndReached}
            ListEmptyComponent={NoData}
            onEndReachedThreshold={0.7}
            data={allVisits}
            renderItem={({index, item}) => renderItem(index, item)}
          />
        )}

        <DatePicker
          open={openDatePicker}
          onCancel={() => setOpenDatePicker(false)}
          onConfirm={date => {
            onDateChanged(date);
          }}
          buttonColor={config.fontAttribute.themeColor}
          date={date}
          minimumDate={
            route?.params?.fromPage == NavMenu?.beatPlanManagement?.markedVisits
              ? undefined
              : new Date()
          }
          maximumDate={new Date()}
          mode="date"
          modal
        />
      </View>
    </>
  );
};

export default VisitDetailsList;
