import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert, TouchableWithoutFeedback, Keyboard, Image, ActivityIndicator, ScrollView } from 'react-native'
import React, { useRef, useState } from 'react'
import { Headercomponent } from '../../Components'
import * as config from '../../config/index'
import styles from './style'
import { useTranslation } from 'react-i18next'
import { showMessage } from 'react-native-flash-message'
import { Formik, FormikProps, useFormikContext } from 'formik';
import * as Yup from 'yup'
import { SvgXml } from 'react-native-svg'
import { shallowEqual, useSelector } from 'react-redux'
import Formik_Text_Input from '../../Components/FormikTextInput'
import { AddRetailerRequest } from '../../ApiServices/httpServices'
import { IDsrProfileDto } from '../../AppModel/DsrProfileModal'

const ChangePassword = (props: any) => {

    const { navigation } = props;
    const [personalDetailsShow, setPersonalDetailsShow] = useState(true)
    const [AddressDetailsShow, setAddressDetailsShow] = useState(false)
    const { t, i18n } = useTranslation();
    const [isLoader, setIsLoader] = useState(false);

    const profileDetail: IDsrProfileDto = useSelector(
        (state: any) => state.auth.profileData,
        shallowEqual,
    );
    const onSaveButtonClicked = (values: any, errors: any) => {
        // setIsLoader(true);
        console.log("values", values)
        AddRetailers(values)
    }

    const AddRetailers = (values: any) => {
        setIsLoader(true)
        const params = {
            "DSRCode": profileDetail?.dsrCode,
            "RetailerName": values?.retailerName,
            "Station": "Some Station Name",
            "ContactPerson": values?.contactPersonName,
            "MobileNumber": values?.mobileNumber,
            "EmailId": values?.emailId,
            "Address": values?.addressLine1 + ' ' +
                values?.addressLine2 + ', ' +
                values?.city + ', ' +
                values?.district + ', ' +
                values?.state + ', ' +
                values?.country + ', ' +
                values?.pinCode
        }
        console.log("add retailer params", params)
        AddRetailerRequest(params).then((result) => {
            console.log("add retailer", result)
            if (result) {
                setIsLoader(false)
                navigation.goBack();
            }
        }).catch((error) => {
            setIsLoader(false)
            console.log("add retailer", error)
        })
    }
    const RetailerDetailsSchema = Yup.object().shape({
        retailerName: Yup
            .string()
            .required(t('Retailer name is required')),
        contactPersonName: Yup
            .string()
            .required(t('Contact person name is required')),
        mobileNumber: Yup
            .string()
            .required(t('Mobile number is required'))
            .min(10, ({ min }) => `Invalid mobile number`),
        emailId: Yup
            .string()
            .required('Email id is required')
            .matches(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, 'Invalid email id'),
        addressLine1: Yup
            .string()
            .required('Address line 1 is required'),
        addressLine2: Yup
            .string(),
        city: Yup
            .string()
            .required('City is required'),
        district: Yup
            .string()
            .required('District is required'),
        state: Yup
            .string()
            .required('State is required'),
        country: Yup
            .string()
            .required('Country is required'),
        pinCode: Yup
            .string()
            .required('Pincode is required')
            .min(6, ({ min }) => `Invalid Pincode`),
    })
    // const { submitForm } = useFormikContext();
    // Define the form values type
    interface MyFormValues {
        retailerName: string;
        contactPersonName: string;
        mobileNumber: string;
        emailId: string;
        addressLine1: string;
        addressLine2: string;
        city: string;
        state: string;
        district: string;
        country: string;
        pinCode: string;
    }
    const formRef = useRef<FormikProps<MyFormValues>>(null)
    return (
        <TouchableWithoutFeedback onPress={() => { Keyboard.dismiss() }}>

            <View style={{ flex: 1 }}>
                <Headercomponent type={'2'} name={t('addRetailer')} />
                <View style={styles.container}>
                    <View style={{ flex: 1 }}>
                        <ScrollView showsVerticalScrollIndicator={false}>
                            {/* Current Password */}
                            <Formik
                                innerRef={formRef}
                                initialValues={{
                                    retailerName: '',
                                    contactPersonName: '',
                                    mobileNumber: '',
                                    emailId: '',
                                    addressLine1: '',
                                    addressLine2: '',
                                    city: '',
                                    state: '',
                                    district: '',
                                    country: 'India',
                                    pinCode: ''
                                }}
                                onSubmit={(values, errors) => { onSaveButtonClicked(values, errors) }}
                                validationSchema={RetailerDetailsSchema}
                            >
                                {({
                                    values,
                                    errors,
                                    touched,
                                    handleChange,
                                    handleBlur,
                                    handleSubmit,
                                    setFieldTouched,
                                    isSubmitting,
                                    isValid,
                                    handleReset
                                    /* and other goodies */
                                }) => (
                                    <View>
                                        <View style={styles.borderCard}>
                                            {/* Personal Details Dropdown*/}
                                            <TouchableOpacity activeOpacity={0.8} onPress={() => setPersonalDetailsShow(!personalDetailsShow)}>
                                                <View style={{
                                                    flexDirection: 'row',
                                                    justifyContent: 'space-between',
                                                    alignItems: 'center',
                                                }}>
                                                    <Text style={styles.headLineText}>{t('personalDetails')}
                                                        {
                                                            (errors.contactPersonName || errors.retailerName || errors.emailId || errors.mobileNumber) &&
                                                            <Text style={{ color: 'red', fontSize: 10 }}> (required)</Text>
                                                        }
                                                    </Text>
                                                    {
                                                        personalDetailsShow ?
                                                            <SvgXml xml={config.svgs.upArrowSvgThemeColored} height={10} width={10} />
                                                            :
                                                            <SvgXml xml={config.svgs.downArrowSvgThemeColored} height={10} width={10} />
                                                    }
                                                </View>
                                            </TouchableOpacity>

                                            {
                                                personalDetailsShow &&
                                                <>
                                                    {/* Retailer Name */}
                                                    <Formik_Text_Input
                                                        touched={touched.retailerName}
                                                        errors={errors.retailerName}
                                                        values={values.retailerName}
                                                        onChangeText={(text: any) => {
                                                            handleChange('retailerName')(text); // Call the Formik handleChange
                                                            setFieldTouched('retailerName', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'retailerName'}
                                                    />

                                                    {/* Contact Person Name */}
                                                    <Formik_Text_Input
                                                        touched={touched.contactPersonName}
                                                        errors={errors.contactPersonName}
                                                        values={values.contactPersonName}
                                                        onChangeText={(text: any) => {
                                                            handleChange('contactPersonName')(text); // Call the Formik handleChange
                                                            setFieldTouched('contactPersonName', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'contactPersonName'}
                                                    />

                                                    {/* Mobile Number */}
                                                    <Formik_Text_Input
                                                        numericKeyboard={true}
                                                        touched={touched.mobileNumber}
                                                        errors={errors.mobileNumber}
                                                        values={values.mobileNumber}
                                                        maxCharacters={10}
                                                        onChangeText={(text: any) => {
                                                            handleChange('mobileNumber')(text); // Call the Formik handleChange
                                                            setFieldTouched('mobileNumber', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'mobileNo'}
                                                    />

                                                    {/* Email Id */}
                                                    <Formik_Text_Input
                                                        touched={touched.emailId}
                                                        errors={errors.emailId}
                                                        values={values.emailId}
                                                        onChangeText={(text: any) => {
                                                            handleChange('emailId')(text); // Call the Formik handleChange
                                                            setFieldTouched('emailId', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'emailId'}
                                                    />
                                                </>
                                            }
                                        </View>


                                        <View style={styles.borderCard}>
                                            {/* Address Details */}
                                            <TouchableOpacity activeOpacity={0.8} onPress={() => setAddressDetailsShow(!AddressDetailsShow)}>
                                                <View style={{
                                                    flexDirection: 'row',
                                                    justifyContent: 'space-between',
                                                    alignItems: 'center'
                                                }}>
                                                    <Text style={[styles.headLineText]}>{t('addressDetails')}
                                                        {
                                                            (errors.addressLine1
                                                                || errors.city
                                                                || errors.district
                                                                || errors.state
                                                                || errors.country
                                                                || errors.pinCode)
                                                            &&
                                                            <Text style={{ color: 'red', fontSize: 10 }}> (required)</Text>
                                                        }
                                                    </Text>
                                                    {
                                                        AddressDetailsShow ?
                                                            <SvgXml
                                                                xml={config.svgs.upArrowSvgThemeColored}
                                                                height={10}
                                                                width={10}
                                                            />
                                                            :
                                                            <SvgXml
                                                                xml={config.svgs.downArrowSvgThemeColored}
                                                                height={10}
                                                                width={10}
                                                            />
                                                    }
                                                </View>
                                            </TouchableOpacity>

                                            {
                                                AddressDetailsShow &&
                                                <>
                                                    {/* Address Line 1 */}
                                                    <Formik_Text_Input
                                                        touched={touched.addressLine1}
                                                        errors={errors.addressLine1}
                                                        values={values.addressLine1}
                                                        onChangeText={(text: any) => {
                                                            handleChange('addressLine1')(text);
                                                            setFieldTouched('addressLine1', true, false);
                                                        }}
                                                        labelText={'addressLine1'}
                                                    />

                                                    {/* Address Line 2 */}
                                                    <Formik_Text_Input
                                                        required={false}
                                                        touched={touched.addressLine2}
                                                        errors={errors.addressLine2}
                                                        values={values.addressLine2}
                                                        onChangeText={(text: any) => {
                                                            handleChange('addressLine2')(text); // Call the Formik handleChange
                                                            setFieldTouched('addressLine2', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'addressLine2'}
                                                    />

                                                    {/* City */}
                                                    <Formik_Text_Input
                                                        touched={touched.city}
                                                        errors={errors.city}
                                                        values={values.city}
                                                        onChangeText={(text: any) => {
                                                            handleChange('city')(text); // Call the Formik handleChange
                                                            setFieldTouched('city', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'city'}
                                                    />

                                                    {/* District */}
                                                    <Formik_Text_Input
                                                        touched={touched.district}
                                                        errors={errors.district}
                                                        values={values.district}
                                                        onChangeText={(text: any) => {
                                                            handleChange('district')(text); // Call the Formik handleChange
                                                            setFieldTouched('district', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'district'}
                                                    />

                                                    {/* State */}
                                                    <Formik_Text_Input
                                                        touched={touched.state}
                                                        errors={errors.state}
                                                        values={values.state}
                                                        onChangeText={(text: any) => {
                                                            handleChange('state')(text); // Call the Formik handleChange
                                                            setFieldTouched('state', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'state'}
                                                    />

                                                    {/* Country */}
                                                    <Formik_Text_Input
                                                        editable={false}
                                                        touched={touched.country}
                                                        errors={errors.country}
                                                        values={values.country}
                                                        onChangeText={(text: any) => {
                                                            handleChange('country')(text); // Call the Formik handleChange
                                                            setFieldTouched('country', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'country'}
                                                    />

                                                    {/* Pincode */}
                                                    <Formik_Text_Input
                                                        numericKeyboard={true}
                                                        touched={touched.pinCode}
                                                        errors={errors.pinCode}
                                                        values={values.pinCode}
                                                        maxCharacters={6}
                                                        onChangeText={(text: any) => {
                                                            handleChange('pinCode')(text); // Call the Formik handleChange
                                                            setFieldTouched('pinCode', true, false); // Set the field to touched without triggering validation
                                                        }}
                                                        labelText={'pinCode'}
                                                    />
                                                </>
                                            }
                                        </View>


                                    </View>
                                )}
                            </Formik>
                        </ScrollView>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 20 }}>
                        {/* Cancel Button */}
                        <TouchableOpacity
                            // disabled={!isValid}
                            onPress={() => { navigation.goBack() }}
                            style={[config.AppStyle.AppStyle.button2, styles.buttons, { marginTop: 0 }]}
                            activeOpacity={0.8} >
                            <Text style={config.AppStyle.AppStyle.buttonText2}>{t('cancel')}</Text>
                        </TouchableOpacity>
                        {/* Save Button */}
                        <TouchableOpacity
                            // disabled={!isValid}
                            onPress={() => { formRef?.current?.submitForm() }}
                            style={[config.AppStyle.AppStyle.button, styles.buttons,
                            { marginTop: 0, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }]}
                            activeOpacity={0.8} >
                            <Text style={config.AppStyle.AppStyle.buttonText}>{t('send')}</Text>
                            {
                                isLoader &&
                                <ActivityIndicator size={15} color={config.fontAttribute.whiteColor} style={{ marginLeft: 5 }} />
                            }
                        </TouchableOpacity>
                    </View>
                </View >
            </View >
        </TouchableWithoutFeedback >
    )
}

export default ChangePassword

const RedStar = () => {
    return (
        <View>
            <Text style={{ color: 'red' }}>*</Text>
        </View>
    )
}