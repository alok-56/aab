import { StyleSheet } from "react-native";
import * as config from '../../config/index'

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: config.fontAttribute.whiteColor,
        // margin: 10,
        borderRadius: 10,
        padding: 10,
    },
    absoluteIcon: {
        position: 'absolute',
        bottom: 27,
        right: 15
    },
    errorMessage: {
        color: 'red', fontWeight: '400', fontSize: config.fontAttribute.labelFontSizeMedium
    },
    buttons: {
        flex: 1, marginHorizontal: 5
    },
    headLineText:
        { fontSize: 12, marginVertical: 5, letterSpacing: 1, color: config.fontAttribute.themeColor },
    borderCard:
    {
        borderWidth: 1,
        borderColor: 'rgba(102,112,133,0.1)',
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 10,
        marginVertical:10
    }


})

export default styles;