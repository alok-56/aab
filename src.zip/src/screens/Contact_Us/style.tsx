import { StyleSheet } from "react-native";
import * as config from '../../config/index'
import { pixelValue } from "../../config/GlobalVariable";

const styles = StyleSheet.create({
    card: {
        borderColor: 'rgba(102,112,133,0.4)',
        borderWidth: 1,
        margin: 10,
        width: 'auto',
        height: 'auto',
        borderRadius: 10,
        padding: 10,
        backgroundColor: config.fontAttribute.whiteColor,
        // elevation:5
    },
    row: {
        flex: 1, flexDirection: 'row', margin: 5
    },
    rowtitle: {
        color: config.fontAttribute.themeColor,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
        margin: 1
    },
    rowData: {
        maxWidth: '95%',
        color: config.fontAttribute.TextColor1,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '400',
        margin: 1
    },
    addressData: {
        fontSize: config.fontAttribute.labelFontSize * pixelValue,
        fontWeight: '500'
    },
    lineBreak: {
        borderColor: 'rgba(102,112,133,0.5)',
        borderWidth: 0.3,
        margin: 10,
    },
    viewDetails: {
        marginTop: 5,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    dashedLineBreak: {
        borderWidth: 0.3,
        borderColor: '#D0D5DD',
        borderStyle: 'dashed',
        marginVertical: 5
    },
    viewDetailsText: {
        color: config.fontAttribute.themeColor,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
        marginRight:10
    }
})

export default styles;