import { View, Text, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native'
import React, { useState } from 'react'
import { Headercomponent } from '../../Components'
import { IuserPorfileDto } from '../../AppModel/UserProfileModel';
import { shallowEqual, useSelector } from 'react-redux';
import styles from './style';
import { capitalize, checkStringNullOrEmpty } from '../../config/GlobalVariable'
import * as config from '../../config/index'
import { useTranslation } from 'react-i18next';
import ContactDetailModal from './contactDetailModal';
import NoData from '../../Components/No_Data_Component';


const ContactUs = () => {
    const { t, i18n } = useTranslation();
    const [isMenuOpen, setMenuOpen] = useState(false);
    const [modalList, setModalList] = useState();


    const toggleMenu = () => {
        setMenuOpen(!isMenuOpen);
    };
    const profileDetail: IuserPorfileDto = useSelector(
        (state: any) => state.auth.profileData,
        shallowEqual,
    );
    const [isRefreshing, setIsRefreshing] = useState(false);

    const onListRefresh = () => {
        console.warn('hey')
    }
    const onEndReached = () => {
        console.warn('end reached')
    }
    const ViewDetails = (item: any) => {

        console.warn(item)
        setModalList(item);
        toggleMenu();

    }
    const renderItem = (item: any) => {
        return (
            <View style={styles.card}>
                <View style={styles.row}>
                    <View style={{ flex: 2 }}>
                        <Text style={styles.rowtitle}>{t('distributorName')}</Text>
                        <Text style={styles.rowData}>{checkStringNullOrEmpty(item?.distributor?.distributorName) ? capitalize(item?.distributor?.distributorName) : '-'}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.rowtitle}>{t('distributorCode')}</Text>
                        <Text style={styles.rowData}>{item?.distributor?.distributorCode == 0 ? '-' : item?.distributor?.distributorCode}</Text>
                    </View>
                </View>
                <View style={styles.row}>
                    <View style={{ flex: 2 }}>
                        <Text style={styles.rowtitle}>{t('telephoneNo')}</Text>
                        <Text style={styles.rowData}>{checkStringNullOrEmpty(item?.distributor?.telephone) ? item?.distributor?.telephone : '-'}</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                        <Text style={styles.rowtitle}>{t('status')}</Text>
                        <Text style={styles.rowData}>{checkStringNullOrEmpty(item?.distributor?.status) ? item?.distributor?.status : '-'}</Text>
                    </View>
                </View>

                <View style={styles.row}>

                    <View style={{ flex: 2 }}>
                        <Text style={styles.rowtitle}>{t('emailId')}</Text>
                        <Text style={styles.rowData}>{checkStringNullOrEmpty(item?.distributor?.emailId) ? item?.distributor?.emailId.toLowerCase() : '-'}</Text>
                    </View>
                </View>
                {/* Line Break */}
                <View style={styles.dashedLineBreak}></View>

                {/* <View style={styles.lineBreak}></View> */}
                <TouchableOpacity activeOpacity={0.8}
                    onPress={() => ViewDetails(item)}
                >
                    <View style={styles.viewDetails}>
                        <Text
                            style={styles.viewDetailsText}>
                            {t('viewDetails')}
                        </Text>
                        <Image style={{ tintColor: config.fontAttribute.themeColor }} source={config.Images.RightArrow} />
                    </View>
                </TouchableOpacity>
            </View>
        )
    }
    return (
        <View>
            <Headercomponent type={'2'} name={t('contactUs')} />
            {
                <FlatList
                    onRefresh={onListRefresh}
                    refreshing={isRefreshing}
                    data={profileDetail?.distributors}
                    onEndReached={onEndReached}
                    ListEmptyComponent={NoData}
                    onEndReachedThreshold={.7}
                    renderItem={({ item }) => renderItem(item)}
                />}
            <ContactDetailModal
                isOpen={isMenuOpen}
                onClose={toggleMenu}
                modalList={modalList}
            />
        </View>
    )
}

export default ContactUs

