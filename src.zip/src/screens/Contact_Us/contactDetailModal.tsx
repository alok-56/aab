

import { View, Text, Modal, TouchableOpacity, StyleSheet, FlatList, Image } from 'react-native'
import React from 'react'
import * as Icons from '../../config/images'
import { pixelValue } from '../../config/GlobalVariable'
import * as config from '../../config/index'
import { checkStringNullOrEmpty } from '../../config/GlobalVariable'
import { useTranslation } from 'react-i18next'
import { ScrollView } from 'react-native'


const ContactDetailModal = (props: any) => {
    const { t, i18n } = useTranslation();
    const { isOpen, onClose, modalList } = props;

    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={config.AppStyle.AppStyle.ModalOuterCss}>
                    <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                        <View style={config.AppStyle.AppStyle.ModalCrossIcon}>
                            <Image source={Icons.cross} />
                        </View>
                    </TouchableOpacity>
                    <View style={[config.AppStyle.AppStyle.ModalInnerCss, { padding: 10 }]}>
                        <ScrollView showsVerticalScrollIndicator={false}>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('distributorName')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(modalList?.distributor?.distributorName) ? modalList?.distributor?.distributorName : '-'}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('distributorCode')}</Text>
                                <Text style={styles.rowData}>{modalList?.distributor?.distributorCode == null ? '-' : modalList?.distributor?.distributorCode}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('address')}</Text>
                                <Text style={styles.rowData}>{
                                    checkStringNullOrEmpty(modalList?.distributor?.address1) ? modalList?.distributor?.address1 : '' + ' '
                                        + checkStringNullOrEmpty(modalList?.distributor?.address2) ? modalList?.distributor?.address2 : '' + ' '
                                            + checkStringNullOrEmpty(modalList?.distributor?.address3) ? modalList?.distributor?.address3 : '' + ' '
                                                + checkStringNullOrEmpty(modalList?.distributor?.address4) ? modalList?.distributor?.address4 : '' + ' '
                                                    + checkStringNullOrEmpty(modalList?.distributor?.address5) ? modalList?.distributor?.address5 : '' + ' '
                                                        + checkStringNullOrEmpty(modalList?.distributor?.address6) ? modalList?.distributor?.address6 : '' + ' '
                                                            + checkStringNullOrEmpty(modalList?.distributor?.city) ? modalList?.distributor?.city : '' + ' '
                                                                + checkStringNullOrEmpty(modalList?.distributor?.state) ? modalList?.distributor?.state : '' + ','
                                                                    + checkStringNullOrEmpty(modalList?.distributor?.pinCode) ? modalList?.distributor?.pinCode : ''}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('telephoneNo')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(modalList?.distributor?.telephone) ? modalList?.distributor?.telephone : '-'}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('mobileNo')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(modalList?.distributor?.mobileNo) ? modalList?.distributor?.mobileNo : '-'}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('whatsappNo')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(modalList?.distributor?.whatsAppNo) ? modalList?.distributor?.whatsAppNo : "-"}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('emailId')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(modalList?.distributor?.emailId) ? modalList?.distributor?.emailId : "-"}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('salesOffice')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(modalList?.distributor?.salesOffice) ? modalList?.distributor?.salesOffice : "-"}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('region')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(modalList?.distributor?.region) ? modalList?.distributor?.region : "-"}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('status')}</Text>
                                <Text style={styles.rowData}>{checkStringNullOrEmpty(modalList?.distributor?.status) ? modalList?.distributor?.status : "-"}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('creditLimit')}</Text>
                                <Text style={styles.rowData}>{modalList?.creditLimit == null ? '-' : modalList?.creditLimit}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('activeFrom')}</Text>
                                <Text style={styles.rowData}>{modalList?.distributor?.activeFrom == null ? '-' : modalList?.distributor?.activeFrom.split('T')[0]}</Text>
                            </View>
                            <View style={styles.contactRow}>
                                <Text style={styles.rowtitle}>{t('deactivatedOn')}</Text>
                                <Text style={styles.rowData}>{modalList?.distributor?.deActivatedOn == null ? '-' : modalList?.distributor?.deActivatedOn}</Text>
                            </View>
                        </ScrollView>
                    </View>
                </View>
            </Modal >
        </View>
    )
}

export default ContactDetailModal

const styles = StyleSheet.create({

    companyName: {
        backgroundColor: '#fff',
        height: 65,
        padding: 15,
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    companyNameText: {
        color: '#3D5E87',
        fontWeight: '400',
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue
    },

    contactRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 10,
    },
    rowtitle: {
        color: config.fontAttribute.themeColor,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600'
    },
    rowData: {
        maxWidth: '75%',
        color: config.fontAttribute.TextColor1,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '400',
        textAlign: 'left',
    },
})