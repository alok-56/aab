import { View, Text, StyleSheet, ImageBackground, Image, BackHandler } from 'react-native'
import React from 'react'
import * as config from '../../../config/index'
import { SvgXml } from 'react-native-svg'
import { pixelValue } from '../../../config/GlobalVariable'
import { useFocusEffect, useRoute } from '@react-navigation/native'
import { TouchableOpacity } from 'react-native-gesture-handler'
import { useTranslation } from 'react-i18next'


const OrderSuccessScreen = (props: any) => {
    const { t, i18n } = useTranslation();

    const route = useRoute();
    // const navigation = useNavigation();
    const onContinueShopping = () => {
        console.log(route.name)
        props.navigation.pop(6);
        return true;
    }
    useFocusEffect(
        React.useCallback(() => {
            BackHandler.addEventListener('hardwareBackPress', onContinueShopping);

            return () =>
                BackHandler.removeEventListener('hardwareBackPress', onContinueShopping);
        }, [])
    );
    return (
        <>
            <View style={{ flex: 1 }}>
                <View style={{
                    flexDirection: 'row',
                    backgroundColor: config.fontAttribute.themeColor,
                    justifyContent: 'flex-end',
                    paddingHorizontal: 30,
                    paddingTop: 20,
                }}>
                    <TouchableOpacity style={{ padding: 10 }} activeOpacity={0.8} onPress={onContinueShopping} >
                        <Image source={config.Images.cross} />
                    </TouchableOpacity>
                </View>
                <View style={[config.AppStyle.AppStyle.container, styles.container]}>
                    <SvgXml xml={config.svgs.orderSuccessScreen} />
                    <View style={{
                        position: 'absolute',
                        bottom: '35%',
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Text
                            style={{
                                fontSize: 30 * pixelValue,
                                color: '#fff',
                                fontWeight: '600'
                            }}>{t('thanks')}</Text>
                        <Text style={{
                            fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
                            color: '#fff',
                            fontWeight: '600'
                        }}>{t('yourOrderPlacedSuccessfully')}</Text>
                    </View>
                </View>

            </View>
        </>
    )
}

export default OrderSuccessScreen

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    }
})