import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Headercomponent } from '../../../Components'
import * as config from '../../../config/index'
import { SvgXml } from 'react-native-svg'
import { GetPaymentMethodList } from '../../../ApiServices/httpServices'
import { FlatList } from 'react-native'
import styles from './style'
import HorizontalTimeLine from '../../../Components/HorizontalTimeLine/HorizontalTimeLine'
import { useTranslation } from 'react-i18next'
import { NavMenu } from '../../../config/GlobalVariable'

const OrderSelectPaymentMethod = (props: any) => {
    const { t, i18n } = useTranslation();

    const onNextButtonClicked = () => {
        props.navigation.navigate(NavMenu.order.placeOrder, { cartId: props?.route?.params?.cartId })
    }
    const [paymentMethods, setPaymentMethods] = useState<any>();
    const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<any>();
    const getPaymentMethods = () => {
        GetPaymentMethodList().then((result) => {
            console.log(result)
            setPaymentMethods(result);
        }).catch((err) => {
            console.log("error", err)
        })
    }
    useEffect(() => {
        getPaymentMethods();
    }, [])

    const renderedItem = (item: any) => {
        return (
            <TouchableOpacity activeOpacity={0.8} onPress={() => setSelectedPaymentMethod(item)}>
                <View style={selectedPaymentMethod?.name == item?.name ? styles.selectedPaymentMethodArea : styles.paymentMethodArea}>
                    <Text style={styles.paymentMethodText}>{item?.name}</Text>
                    {
                        selectedPaymentMethod?.name == item?.name
                            ? <SvgXml xml={config.svgs.checkedCheckbox} height={20} width={20} />
                            : <SvgXml xml={config.svgs.uncheckedCheckbox} height={20} width={20} />
                    }
                </View>
            </TouchableOpacity>

        )
    }
    return (
        <>
            <Headercomponent type={'2'} name={t('selectAPaymentMethod')} />
            <HorizontalTimeLine currentStep={1} />
            <View style={styles.container}>
                <FlatList
                    style={{ flexGrow: 0 }}
                    showsVerticalScrollIndicator={false}
                    data={paymentMethods}
                    onEndReachedThreshold={.7}
                    renderItem={({ item }) => renderedItem(item)}
                    keyExtractor={item => item?.id}
                />
                <TouchableOpacity activeOpacity={0.8} onPress={() => selectedPaymentMethod ? onNextButtonClicked() : {}}
                // <TouchableOpacity activeOpacity={0.8} onPress={() => onNextButtonClicked()}
                    style={[config.AppStyle.AppStyle.button, { opacity: selectedPaymentMethod ? 1 : 0.5 }]}>
                    <Text style={config.AppStyle.AppStyle.buttonText}>{t('next')}</Text>
                </TouchableOpacity>
            </View>
        </>
    )
}

export default OrderSelectPaymentMethod

