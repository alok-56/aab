import { StyleSheet } from "react-native";
import * as config from '../../../config/index'

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        flex: 1,
        marginTop: 5,
        // borderRadius:10,
        padding: 20
    },
    paymentMethodArea: {
        height: 'auto',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: 'rgba(102,112,133,0.2)',
        padding: 15,
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    selectedPaymentMethodArea: {
        height: 'auto',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#8FB5D0',
        flexDirection: 'row',
        padding: 15,
        justifyContent: 'space-between',
        backgroundColor: '#F2F6F9',
    },
    paymentMethodText: {
        fontSize: config.fontAttribute.labelFontSize,
        fontWeight: '600',
        color: config.fontAttribute.TextColor2
    }
})

export default styles;