import { StyleSheet } from "react-native"
import { pixelValue } from "../../../config/GlobalVariable"
import * as config from '../../../config/index'

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        flex: 1,
        marginTop: 5,
        // borderRadius:10,
        padding: 20
    },
    addressCard: {
        height: 'auto',
        padding: 10,
        borderWidth: 0.5,
        borderRadius: 10,
        borderColor: 'rgba(102,112,133,0.4)',
        marginVertical: 5
    },
    editButton: {
        backgroundColor: 'transparent',
        height: 45,
        width: 'auto',
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: 'rgba(102,112,133,0.2)',
        borderWidth: 1
    },
    distributorName: {
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
        fontWeight: '600',
        color: config.fontAttribute.TextColor1,
        marginVertical: 2
    },
    otherAddressText: {
        fontSize: 13 * pixelValue,
        fontWeight: '400',
        color: config.fontAttribute.TextColor1,
        marginVertical: 2,
    },
    gstinTitle: {
        fontSize: 13 * pixelValue,
        fontWeight: '600',
        color: config.fontAttribute.TextColor1,
        marginVertical: 2
    },
})

export default styles
