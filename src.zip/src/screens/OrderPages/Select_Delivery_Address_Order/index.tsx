import { View, Text, StyleSheet, TouchableOpacity, Image, FlatList } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Headercomponent } from '../../../Components'
import * as config from '../../../config/index'
import { NavMenu, capitalize, checkStringNullOrEmpty, pixelValue } from '../../../config/GlobalVariable'
import { SvgXml } from 'react-native-svg'
import { IuserPorfileDto } from '../../../AppModel/UserProfileModel'
import { shallowEqual, useSelector } from 'react-redux'
import styles from './style'
import HorizontalTimeLine from '../../../Components/HorizontalTimeLine/HorizontalTimeLine'
import { useTranslation } from 'react-i18next'


const OrderSelectDeliveryAddress = (props: any) => {

    const { t, i18n } = useTranslation();
    const [profileInfo, setProfileInfo] = useState<any>(null);
    const profileDetails = useSelector(
        (state: any) => state.auth.profileData,
        shallowEqual)
    // const [distributor, setDistributor] = useState<any>();
    // const [address, setAddress] = useState<any>({ addressLine1: '', city: '', state: '', pinCode: null })
    useEffect(() => {
        profileDetails?.profile?.profileRole?.id == 3 && setProfileInfo(profileDetails)
        profileDetails?.profile?.profileRole?.id == 4 && setProfileInfo(props?.route?.params?.retailerDetails)

        // setDistributor(props?.route?.params?.distributorDetails);
        // setAddress({
        //     addressLine1: distributor?.address1 + distributor?.address2 + distributor?.address3 + distributor?.address4 + distributor?.address5 + distributor?.address6,
        //     city: distributor?.city ? distributor?.city : '',
        //     state: distributor?.state ? distributor?.state : '',
        //     pinCode: distributor?.pinCode
        // })
        // console.warn(distributor);
        // gettotalItems();
        // console.log(profileInfo)
    }, [])

    // const profileDetail: IuserPorfileDto = useSelector(
    //     (state: any) => state.auth.profileData,
    //     shallowEqual,
    // );
    const data = [
        { isSelected: true }, { isSelected: false }
    ]
    const deliverToThisAddressClicked = () => {
        props.navigation.navigate(NavMenu.order.selectPaymentMethod, { cartId: props?.route?.params?.cartId });
    }
    const editButtonClicked = () => {

    }
    const RenderedItem = (item: any) => {
        return (
            // <TouchableOpacity activeOpacity={0.9} onPress={onAddressItemClicked}>
            <View style={styles.addressCard}>
                <View style={{ flexDirection: 'row' }}>
                    <View>
                        {/* {
                            item.isSelected ? */}
                        <SvgXml xml={config.svgs.checkedCheckbox} height={20} width={20} />
                        {/* :
                                <SvgXml xml={config.svgs.uncheckedCheckbox} height={20} width={20} />
                        } */}
                    </View>
                    <View style={{ marginLeft: 15 }}>
                        <Text style={styles.distributorName}>{capitalize(profileInfo?.retailerName)}</Text>
                        <Text numberOfLines={3} style={styles.otherAddressText}>
                            {/* {address?.addressLine1} */}
                            {checkStringNullOrEmpty(profileInfo?.street1) ? capitalize(profileInfo?.street1) + ' , ' : ''}
                            {checkStringNullOrEmpty(profileInfo?.street2) ? capitalize(profileInfo?.street2) + ' , ' : ''}
                            {checkStringNullOrEmpty(profileInfo?.street3) ? capitalize(profileInfo?.street3) : ''}
                            {/* {checkStringNullOrEmpty(distributor?.address4) ? distributor?.address4 + ',' : ''}
                            {checkStringNullOrEmpty(distributor?.address5) ? distributor?.address5 + ',' : ''}
                            {checkStringNullOrEmpty(distributor?.address6) ? distributor?.address6 : ''} */}
                        </Text>
                        <Text style={styles.otherAddressText}>
                            {checkStringNullOrEmpty(profileInfo?.street4) ? capitalize(profileInfo?.street4) + ' , ' : ''}
                            {checkStringNullOrEmpty(profileInfo?.state) ? capitalize(profileInfo?.state) : ''}</Text>
                        <Text style={styles.otherAddressText}>{profileInfo?.pinCode}</Text>
                        <Text style={styles.gstinTitle}>{t('gstin')} : <Text style={styles.otherAddressText}>{profileInfo?.retailerBankTaxDetails?.gstin}</Text></Text>
                    </View>
                </View>
                {
                    // item.isSelected ?
                    <View>
                        <TouchableOpacity onPress={deliverToThisAddressClicked} activeOpacity={0.8} style={[config.AppStyle.AppStyle.button, { marginVertical: 15, marginTop: 15 }]}>
                            <Text style={config.AppStyle.AppStyle.buttonText}>{t('deliverToThisAddress')}</Text>
                        </TouchableOpacity>
                        {/* <TouchableOpacity onPress={editButtonClicked} activeOpacity={0.8} style={styles.editButton}>
                            <Text style={[config.AppStyle.AppStyle.buttonText, { color: config.fontAttribute.TextColor2 }]}>Edit</Text>
                        </TouchableOpacity> */}
                    </View>
                    // : <></>
                }
            </View>
            // </TouchableOpacity>
        )
    }
    return (
        <>
            <Headercomponent type={'2'} name={t('selectDeliveryAddress')} />
            <HorizontalTimeLine currentStep={0} />

            <View style={styles.container}>
                <RenderedItem />
                {/* <FlatList
                    // onRefresh={onListRefresh}
                    // refreshing={isRefreshing}
                    // onEndReached={onEndReached}
                    showsVerticalScrollIndicator={false}
                    data={data}
                    onEndReachedThreshold={.7}
                    renderItem={({ item }) => renderedItem(item)}
                // keyExtractor={item => item.materialCode}
                /> */}
            </View>
        </>
    )
}

export default OrderSelectDeliveryAddress

