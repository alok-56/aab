

import { View, Text, Modal, TouchableOpacity, StyleSheet, FlatList, Image, TextInput, KeyboardAvoidingView, Platform, Keyboard } from 'react-native'
import React, { useState } from 'react'
import * as Icons from '../../../config/images'
import { pixelValue } from '../../../config/GlobalVariable'
import * as config from '../../../config/index'
import { checkStringNullOrEmpty } from '../../../config/GlobalVariable'
import { useTranslation } from 'react-i18next'
import ReasonListModal from './ReasonListModal'
import { TouchableWithoutFeedback } from 'react-native'
import { ScrollView } from 'react-native'


const CancelOrderModal = (props: any) => {

    const { t, i18n } = useTranslation();
    const { isOpen, onClose, modalList, onOkButtonPressed, reasonList } = props;
    const [openModal, setOpenModal] = useState(false);
    const [reason, setReason] = useState<any>('');
    const [remark, setRemark] = useState<any>('');

    const dropDownClicked = () => {
        onClose();
        toggleFilter()
    }
    const toggleFilter = () => {
        setOpenModal(!openModal);
        onClose();
    }
    const listItemClicked = (reason: any) => {
        setReason(reason?.name)
        console.log(reason)
        // onClose();
        toggleFilter()
    }
    const onRemarkChange = (remark: any) => {
        setRemark(remark);
    }

    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <KeyboardAvoidingView
                    style={{ flex: 1 }}
                    behavior={Platform.OS == "ios" ? "padding" : undefined}
                    keyboardVerticalOffset={65}>
                    <TouchableWithoutFeedback onPress={() => { Keyboard.dismiss() }}>

                        <View style={config.AppStyle.AppStyle.ModalOuterCss}>
                            <TouchableOpacity activeOpacity={0.9} onPress={() => {
                                setReason('');
                                onClose();
                            }}>
                                <View style={config.AppStyle.AppStyle.ModalCrossIcon}>
                                    <Image source={Icons.cross} />
                                </View>
                            </TouchableOpacity>
                            <View style={[config.AppStyle.AppStyle.ModalInnerCss, { padding: 20 }]}>
                                {/* <KeyboardAvoidingView
               style={{ flex: 1 }}
               behavior={ "padding" }
               keyboardVerticalOffset={200}> */}

                                <View>

                                    {/* Reason Dropdown */}
                                    <Text style={config.AppStyle.AppStyle.inputLabel}>{t('reason')}</Text>
                                    <TouchableOpacity onPress={() => { dropDownClicked() }} activeOpacity={1}>
                                        <View style={config.AppStyle.AppStyle.inputField}>
                                            <TextInput
                                                style={{ color: config.fontAttribute.TextColor1 }}
                                                editable={false}
                                                value={reason ? reason : ''}
                                                placeholderTextColor={config.fontAttribute.placeholderColor}
                                                placeholder={t('mentionReason')} />
                                            {/* {isClicked ? <Image style={styles.downArrow} source={config.Images.upArrowBlack} /> : */}
                                            <Image style={styles.downArrow} source={config.Images.DownArrow} />
                                        </View>
                                    </TouchableOpacity>

                                    {/* Remark */}

                                    <Text style={config.AppStyle.AppStyle.inputLabel}>{t('remark')}</Text>
                                    <ScrollView style={[config.AppStyle.AppStyle.textArea, { maxHeight: 100 }]} showsVerticalScrollIndicator={false}>
                                        <TextInput
                                            selectionColor={config.fontAttribute.cursorColor}
                                            onChangeText={e => onRemarkChange(e)}
                                            style={[{ minHeight: 70 ,color: config.fontAttribute.textInputValueColor}]}
                                            multiline={true}
                                            numberOfLines={4} />
                                    </ScrollView>


                                    <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' }}>
                                        <TouchableOpacity
                                            activeOpacity={0.8}
                                            onPress={onClose}
                                            style={[styles.cancelButton, { width: '30%', marginHorizontal: 10 }]}>
                                            <Text style={[config.AppStyle.AppStyle.buttonText, { color: config.fontAttribute.themeColor }]}>{t('cancel')}</Text>
                                        </TouchableOpacity>

                                        <TouchableOpacity
                                            activeOpacity={0.8}
                                            onPress={() => {
                                                onOkButtonPressed(reason, remark);
                                                setReason('');
                                            }}
                                            style={[config.AppStyle.AppStyle.button, { width: '30%', marginTop: 10 }]}>
                                            <Text style={config.AppStyle.AppStyle.buttonText}>{t('ok')}</Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>

                                {/* </KeyboardAvoidingView> */}

                            </View>

                        </View>
                    </TouchableWithoutFeedback>
                </KeyboardAvoidingView>
            </Modal >
            <ReasonListModal
                isOpen={openModal}
                onClose={toggleFilter}
                reasonList={reasonList}
                listItemClicked={(e: any) => listItemClicked(e)} />
        </View>
    )
}

export default CancelOrderModal

const styles = StyleSheet.create({

    companyName: {
        backgroundColor: '#fff',
        height: 65,
        padding: 15,
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    companyNameText: {
        color: '#3D5E87',
        fontWeight: '400',
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
    },

    contactRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        margin: 10,
    },
    rowtitle: {
        color: config.fontAttribute.themeColor,
        fontSize: config.fontAttribute.labelFontSize * pixelValue,
        fontWeight: '500',
    },
    rowData: {
        maxWidth: '75%',
        fontSize: config.fontAttribute.labelFontSize * pixelValue,
        fontWeight: '500',
        textAlign: 'left',
    },
    downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 20
    },
    cancelButton: {
        backgroundColor: 'transparent',
        height: 45,
        width: 'auto',
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: 'rgba(102,112,133,0.2)',
        borderWidth: 1,
        marginTop: 10
    }
})