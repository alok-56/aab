import React, {useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {
  Dimensions,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {shallowEqual, useSelector} from 'react-redux';
import {
  CancelOrder,
  GetCancelOrderReasonList,
  GetOrderDescription,
} from '../../../ApiServices/httpServices';
import {IDsrProfileDto} from '../../../AppModel/DsrProfileModal';
import {IuserPorfileDto} from '../../../AppModel/UserProfileModel';
import {Headercomponent} from '../../../Components';
import ConfirmationPopup from '../../../Components/ConfirmationPopup/ConfirmationPopup';
import Skeleton from '../../../Components/skeleton/skeleton';
import {
  ConvertDateFormat,
  OrderStatusColorCodes,
  StatusKey,
  capitalize,
  fixToTwoDecimal,
  pixelValue,
} from '../../../config/GlobalVariable';
import * as config from '../../../config/index';
import CancelOrderModal from './CancelOrderModal';

const OrderDetail = (props: any) => {
  const {t, i18n} = useTranslation();

  const [isRefreshing, setIsRefreshing] = useState(false);
  const [productList, setProductList] = useState<any>();
  const [isProductLoader, setIsProductLoader] = useState(false);
  const [isModal, setIsModal] = useState(false);
  const [isConfirmationModal, setIsConfirmationModal] = useState(false);
  const [isSuccessModal, setIsSuccessModal] = useState(false);
  const [reasonList, setReasonList] = useState<any>();
  const [cancelOrderParams, setCancelOrderParams] = useState({
    reason: '',
    remark: '',
  });

  // let order: any;
  useEffect(() => {
    setIsProductLoader(true);
    console.log('selected Order', props?.route?.params?.item);
    // order = props?.route?.params?.item;
    getOrderDetails(props?.route?.params?.item?.id);
    getReasonList();
  }, []);

  const profileDetail: IDsrProfileDto | IuserPorfileDto | any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  const getOrderDetails = (orderId: any) => {
    GetOrderDescription(orderId)
      .then(result => {
        console.log('order Detail', result);
        setProductList(result);
        setIsProductLoader(false);
      })
      .catch((err: any) => {
        console.log('error', err);
      });
  };
  const getReasonList = () => {
    GetCancelOrderReasonList()
      .then(result => {
        console.log('reason List', result);
        setReasonList(result);
      })
      .catch((err: any) => {
        console.log('error', err);
      });
  };

  const cancelOrder = (reason: string, remark: string) => {
    const params = {
      OrderID: props?.route?.params?.item?.id,
      Reason: reason,
      Remarks: remark,
    };
    console.log('req parameter', params);
    CancelOrder(params)
      .then(result => {
        console.log('order cancelled', result);
        toggleSuccessModal();
      })
      .catch((err: any) => {
        console.log('error', err);
      });
  };
  const onCancelOrderPressed = () => {
    toggleModal();
  };
  const onListRefresh = async () => {
    setIsProductLoader(true);
    getOrderDetails(props?.route?.params?.item?.id);
  };
  const onEndReached = async () => {};

  const toggleModal = () => {
    setIsModal(!isModal);
  };
  const onOkButtonPressed = (reason: string, remark: string) => {
    toggleModal();
    toggleConfirmationModal();
    setCancelOrderParams({reason, remark});
  };
  const onCancelOrderClicked = () => {
    cancelOrder(cancelOrderParams.reason, cancelOrderParams.remark);
    toggleConfirmationModal();
  };

  const toggleConfirmationModal = () => {
    setIsConfirmationModal(!isConfirmationModal);
  };
  const toggleSuccessModal = () => {
    setIsSuccessModal(!isSuccessModal);
  };
  const onDoneButtonClicked = () => {
    props.navigation.goBack();
  };
  const renderedItem = (item: any) => {
    return (
      <View style={{marginHorizontal: 5}}>
        <View style={styles.productCard}>
          <View style={styles.row}>
            <Text style={styles.productId}>{item?.materialCode}</Text>
            <Text style={styles.title}>
              {t('amount')}:{' '}
              <Text style={styles.titleValue}>&#8377;{item?.totalPrice}</Text>
            </Text>
          </View>
          <View style={styles.row}>
            <Text style={[styles.titleValue, {maxWidth: '60%'}]}>
              {item?.distributorInventoryItem?.materialItem?.description}
            </Text>
            <View style={{alignItems: 'flex-end'}}>
              <Text style={styles.title}>
                {t('orderedQuantity')}:{' '}
                <Text style={styles.titleValue}>{item?.orderQuantity}</Text>
              </Text>
              <Text style={styles.title}>
                {t('invoicedQuantity')}:{' '}
                <Text style={styles.titleValue}>{item?.invoicedQuantity}</Text>
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  };
  const skaletonData = [{}, {}, {}, {}, {}, {}];
  const skeletonRenderItem = () => {
    return (
      <Skeleton>
        <View style={{marginHorizontal: 5 , backgroundColor: '#fff',
            borderRadius: 4}}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
              marginVertical: 10
            }}>
            <View
              style={{
                borderWidth: 1,
                padding: 5,
                borderColor: '#EAECF0',
                borderRadius: 10,
              }}>
              <View
                style={{
                  height: 10,
                  marginVertical: 5,
                  width: Dimensions.get('window').width * 0.85,
                }}></View>
              <View
                style={{
                  height: 10,
                  marginVertical: 5,
                  width: Dimensions.get('window').width * 0.85,
                }}></View>
              <View
                style={{
                  height: 10,
                  marginVertical: 5,
                  width: Dimensions.get('window').width * 0.85,
                }}></View>
            </View>
          </View>
        </View>
      </Skeleton>
    );
  };
  return (
    <>
      <Headercomponent type={'2'} name={t('orderDetails')} />
      <View style={styles.container}>
        <Text style={styles.orderDetailTitle}>{t('orderDetails')}</Text>

        {
          // item?.id, item?.retailerOrderStatus?.name
          props?.route?.params?.item?.retailerOrderStatus?.name ==
            'Terminated' ||
          props?.route?.params?.item?.retailerOrderStatus?.name == 'Invoiced' ||
          props?.route?.params?.item?.retailerOrderStatus?.name ==
            'PartiallyInvoiced' ||
          profileDetail?.profile?.profileRole?.id == 4 ? ( //Condition if Dsr is loggedIn
            <></>
          ) : (
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={onCancelOrderPressed}
              style={[config.AppStyle.AppStyle.button, {marginTop: 20}]}>
              <Text style={config.AppStyle.AppStyle.buttonText}>
                {t('cancelOrder')}
              </Text>
            </TouchableOpacity>
          )
        }

        {/* Order Details */}
        <View style={styles.orderCard}>
          <View style={[styles.orderRow]}>
            <Text style={styles.title}>
              {t('orderId')}:{' '}
              <Text style={styles.titleValue}>
                {props?.route?.params?.item?.orderNo}
              </Text>
            </Text>
            <Text style={styles.title}>
              {t('date')}:{' '}
              <Text style={styles.titleValue}>
                {ConvertDateFormat(props?.route?.params?.item?.orderDate)}
              </Text>
            </Text>
          </View>
          <View style={[styles.orderRow, {marginVertical: 10}]}>
            <Text style={styles.distributorName}>
              {capitalize(
                props?.route?.params?.item?.distributor?.distributorName,
              )}
            </Text>
            {/* <Text style={styles.title}>Price: */}
            <Text style={styles.totalAmount}>
              &#8377;{fixToTwoDecimal(props?.route?.params?.item?.invoiceValue)}
            </Text>
            {/* </Text> */}
          </View>

          <View style={styles.orderRow}>
            <Text style={styles.title}>
              {t('quantity')}:{' '}
              <Text style={styles.titleValue}>
                {props?.route?.params?.item?.lineItemCount} item(s)
              </Text>
            </Text>
            {/* <TouchableOpacity style={{ padding: 3 }} activeOpacity={0.8}> */}
            <Text style={styles.title}>
              {t('status')}:{' '}
              <Text
                style={[
                  styles.titleValue,
                  {
                    color:
                      OrderStatusColorCodes[
                        props?.route?.params?.item?.retailerOrderStatus
                          ?.id as StatusKey
                      ] || '#000000',
                  },
                ]}>
                {props?.route?.params?.item?.retailerOrderStatus?.name}
              </Text>
            </Text>
            {/* </TouchableOpacity> */}
          </View>
        </View>

        {/* Line Break */}
        <View style={styles.productListLineBreak}>
          <View style={styles.lineForProductListLineBreak}></View>
          <Text style={styles.titleValue}>{t('productList')}</Text>
          <View style={styles.lineForProductListLineBreak}></View>
        </View>

        {/* ProductList */}
        {isProductLoader ? (
          // <ActivityIndicator style={{ flex: 1 }} size="small" color={config.fontAttribute.themeColor} />

          <FlatList
            style={{marginTop: 20}}
            showsVerticalScrollIndicator={false}
            data={skaletonData}
            onEndReachedThreshold={0.7}
            renderItem={({item}) => skeletonRenderItem()}
          />
        ) : (
          <FlatList
            style={{marginTop: 10}}
            onRefresh={onListRefresh}
            refreshing={isRefreshing}
            onEndReached={onEndReached}
            showsVerticalScrollIndicator={false}
            data={productList}
            // ListEmptyComponent={NoData}
            onEndReachedThreshold={0.7}
            renderItem={({item}) => renderedItem(item)}
            // keyExtractor={item => item.materialCode}
          />
        )}
      </View>

      {/* Cancel Order Modal */}
      <CancelOrderModal
        // data={productCategory}
        isOpen={isModal}
        onClose={toggleModal}
        onOkButtonPressed={(reason: any, remark: any) =>
          onOkButtonPressed(reason, remark)
        }
        reasonList={reasonList}
        // onApplyButtonClicked={(e: any) => { onApplyButtonClicked(e) }}
      />

      {/* Confirmation Modal */}

      <ConfirmationPopup
        onConfirmButtonClicked={onCancelOrderClicked}
        isOpen={isConfirmationModal}
        onClose={toggleConfirmationModal}
        message={t('cancelOrderConfirmationMessage')}
        button1Title={t('yesCancelIt')}
        button2Title={t('noGoBack')}
        isconfirmation={true}
      />

      {/* Success Modal */}

      <ConfirmationPopup
        isOpen={isSuccessModal}
        onClose={toggleSuccessModal}
        onDoneButtonClicked={onDoneButtonClicked}
        message={t('cancelOrderSuccessMessage')}
        successMessage={t('cancelOrderSuccessTitle')}
        isSuccess={true}
      />
    </>
  );
};

export default OrderDetail;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginVertical: 5,
    padding: 20,
    backgroundColor: '#fff',
  },
  productCard: {
    borderWidth: 1,
    borderColor: '#EAECF0',
    borderRadius: 10,
    height: 'auto',
    padding: 10,
    marginVertical: 5,
    backgroundColor: '#fff',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 5,
  },
  titleValue: {
    color: config.fontAttribute.TextColor1,
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '500',
  },
  title: {
    color: config.fontAttribute.TextColor2,
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '600',
  },
  title2: {
    color: config.fontAttribute.TextColor2,
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '600',
    marginVertical: 10,
  },
  productId: {
    color: config.fontAttribute.TextColor2,
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '600',
  },
  orderDetailTitle: {
    color: config.fontAttribute.TextColor2,
    fontSize: config.fontAttribute.labelFontSizeLarge,
    fontWeight: '600',
  },
  orderCard: {
    borderWidth: 1.5,
    borderColor: config.fontAttribute.themeColor,
    borderRadius: 10,
    height: 'auto',
    padding: 10,
    marginVertical: 5,
    backgroundColor: '#fff',
    marginTop: 20,
  },
  orderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  distributorName: {
    color: config.fontAttribute.themeColor,
    fontSize: config.fontAttribute.labelFontSize * pixelValue,
    fontWeight: '600',
    maxWidth: '80%',
  },
  totalAmount: {
    color: config.fontAttribute.TextColor2,
    fontSize: config.fontAttribute.labelFontSize * pixelValue,
    fontWeight: '700',
  },
  productListLineBreak: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
  },
  lineForProductListLineBreak: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(102,112,133,0.4)',
    width: '35%',
    marginHorizontal: 10,
  },
});
