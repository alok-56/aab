import {useFocusEffect, useIsFocused} from '@react-navigation/native';
import React, {useState} from 'react';
import {useTranslation} from 'react-i18next';
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {SvgXml} from 'react-native-svg';
import {shallowEqual, useSelector} from 'react-redux';
import {GetAllOrders} from '../../../ApiServices/httpServices';
import {IDsrProfileDto} from '../../../AppModel/DsrProfileModal';
import {IOrderList} from '../../../AppModel/OrderListModal';
import {IuserPorfileDto} from '../../../AppModel/UserProfileModel';
import {Headercomponent} from '../../../Components';
import NoData from '../../../Components/No_Data_Component';
import Skeleton from '../../../Components/skeleton/skeleton';
import {
  ConvertDateFormat,
  NavMenu,
  OrderStatusColorCodes,
  StatusKey,
  capitalize,
  fixToTwoDecimal,
} from '../../../config/GlobalVariable';
import * as config from '../../../config/index';
import {ModalPage} from '../Create_Order/RetailerList';
import styles from './style';
import { SafeAreaView } from 'react-native-safe-area-context';

let pageindex = 0;
let pagesize = 10;
let selectedRetailer: any = null;
const Order = (props: any) => {
  const {t, i18n} = useTranslation();
  const {navigation} = props;
  const onPlusIconClicked = () => {
    navigation.navigate(NavMenu.order.createOrder, {isCreateOrder: true});
  };
  const onCartButtonClicked = () => {
    // navigation.navigate('selectDistributorLedger', { fromPageName: "Order" })
    navigation.navigate(NavMenu.order.createOrder, {isCreateOrder: false});
  };

  const [isRefreshing, setIsRefreshing] = useState(false);
  const [OrderList, SetOrderList] = useState<Array<IOrderList>>([]);
  // const [pageIndex, setPageIndex] = useState(0);
  const [isProductLoader, setIsProductLoader] = useState(false);
  const [lazyLoader, setLazyLoader] = useState(false);

  const isFocused = useIsFocused();

  const profileDetail: IDsrProfileDto | IuserPorfileDto | any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  useFocusEffect(
    React.useCallback(() => {
      if (isFocused) {
        setLazyLoader(false);
        selectedRetailer = null;
        pageindex = 0;
        OrderList.length = 0;
        SetOrderList(OrderList);
        // setPageIndex(0);

        //Setting Retailer Code for Retailer
        if (profileDetail?.profile?.profileRole?.id == 3) {
          setIsProductLoader(true);
          setLazyLoader(false);
          selectedRetailer = profileDetail;
          pageindex = 0;
          OrderList.length = 0;
          SetOrderList(OrderList);
          getOrderList(pagesize, 0);
        }
        // profileDetail?.profile?.profileRole?.id == 4 ? selectedRetailer = profileDetail : null;
      }
    }, [isFocused]),
  );

  // useEffect(() => {
  //   setIsProductLoader(true);
  //   setPageIndex(0);
  //   OrderList.length = 0;
  //   SetOrderList(OrderList)
  //   getOrderList(10, 0);
  // }, [])

  const getOrderList = (PageSize: number, PageIndex: number) => {
    const Params = {
      // RetailerId: profileDetail.retailerCode,
      RetailerId: selectedRetailer?.retailerCode,
      PageSize: PageSize,
      PageIndex: PageIndex,
    };
    console.log('Order List Params', Params);
    GetAllOrders(Params)
      .then((result: Array<IOrderList>) => {
        console.log('All Orders', result);
        let items = OrderList.concat(result);
        setIsProductLoader(false);
        setLazyLoader(false);
        SetOrderList(items);
      })
      .catch((err: any) => {
        console.log('error', err);
      });
  };
  const onListRefresh = async () => {
    setIsProductLoader(true);
    OrderList.length = 0;
    SetOrderList(OrderList);
    // setPageIndex(0);
    pageindex = 0;
    getOrderList(pagesize, 0);
  };
  const onEndReached = async () => {
    setLazyLoader(true);
    console.warn('end');
    getOrderList(pagesize, ++pageindex);
    // setPageIndex(pageIndex + 1);
    // await getProduct(selectedDistributor.distributorCode,10,0)
  };
  // const onCancelOrderPressed = () => {
  // }
  const onOrderItemclicked = (item: any) => {
    navigation.navigate(NavMenu.order.orderDetail, {item});
  };
  const dropDownClicked = () => {
    toggleRetailerList();
  };
  const [isRetailerListModal, setIsRetailerListModal] = useState(false);
  const toggleRetailerList = () => {
    setIsRetailerListModal(!isRetailerListModal);
  };
  const onRetailerSelection = (value: any, valueType: string = '') => {
    pageindex = 0;
    OrderList.length = 0;
    SetOrderList(OrderList);
    console.log('selected retailer', value);
    selectedRetailer = value;
    setIsProductLoader(true);
    getOrderList(pagesize, 0);
  };
  const productListRenderItem = (item: any) => {
    return (
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={() => onOrderItemclicked(item)}>
        <View style={styles.orderCard}>
          <View style={[styles.orderRow]}>
            <Text style={styles.title}>
              {t('orderId')}:{' '}
              <Text style={styles.titleValue}>{item?.orderNo}</Text>
            </Text>
            <Text style={styles.title}>
              {t('date')}:{' '}
              <Text style={styles.titleValue}>
                {ConvertDateFormat(item?.orderDate)}
              </Text>
            </Text>
          </View>
          <View style={[styles.orderRow, {marginVertical: 10}]}>
            <Text style={styles.distributorName}>
              {capitalize(item?.distributor?.distributorName)}
            </Text>
            {/* <Text style={styles.title}>Price: */}
            <Text style={styles.totalAmount}>
              &#8377;{fixToTwoDecimal(item?.invoiceValue)}
            </Text>
            {/* </Text> */}
          </View>

          <View style={styles.orderRow}>
            <Text style={styles.title}>
              {t('quantity')}:
              <Text style={styles.titleValue}>
                {' '}
                {item?.lineItemCount} item(s)
              </Text>
            </Text>
            {/* <TouchableOpacity style={{ padding: 3 }} activeOpacity={0.8}> */}
            <Text style={styles.title}>
              {t('status')}:
              <Text
                style={[
                  styles.titleValue,
                  {
                    color:
                      OrderStatusColorCodes[
                        item?.retailerOrderStatus?.id as StatusKey
                      ] || '#000000',
                  },
                ]}>
                {' '}
                {item?.retailerOrderStatus?.name}
              </Text>
            </Text>
            {/* </TouchableOpacity> */}
          </View>
        </View>
      </TouchableOpacity>
    );
  };
  // const orderList = [{}, {}]
  const skaletonData = [{}, {}, {}, {}, {}, {}, {}];
  const skeletonRenderItem = () => {
    return (
      <Skeleton>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            marginVertical: 10,
            backgroundColor: '#fff',
            borderRadius: 4,
          }}>
          <View
            style={{
              borderWidth: 1,
              padding: 5,
              borderColor: '#EAECF0',
              borderRadius: 10,
            }}>
            <View
              style={{
                height: 10,
                marginVertical: 5,
                width: Dimensions.get('window').width * 0.85,
              }}></View>
            <View
              style={{
                height: 10,
                marginVertical: 5,
                width: Dimensions.get('window').width * 0.85,
              }}></View>
            <View
              style={{
                height: 10,
                marginVertical: 5,
                width: Dimensions.get('window').width * 0.85,
              }}></View>
          </View>
        </View>
      </Skeleton>
    );
  };
  return (
    <SafeAreaView style={config.AppStyle.AppStyle.flex1}>
      <Headercomponent
        type={'3'}
        name={t('order')}
        isCart={true}
        isAdd={true}
        onPlusIconClicked={onPlusIconClicked}
        onCartButtonClicked={onCartButtonClicked}
      />
      <View style={styles.container}>
        {/* Retailer dropdown in case of DSR Login */}
        {profileDetail?.profile?.profileRole?.id == 4 && (
          <>
            {/* <Text style={styles.distributor}>{t('retailer')}</Text> */}

            <TouchableOpacity
              onPress={() => {
                dropDownClicked();
              }}
              activeOpacity={1}>
              <View
                style={[
                  config.AppStyle.AppStyle.inputField,
                  {justifyContent: 'space-between'},
                ]}>
                <TextInput
                  style={{color: config.fontAttribute.TextColor1}}
                  placeholderTextColor={config.fontAttribute.placeholderColor}
                  placeholder={t('selectRetailerPlaceholder')}
                  value={selectedRetailer?.retailerName}
                  editable={false}
                />
                {/* {isClicked ? <Image style={styles.downArrow} source={config.Images.upArrowBlack} /> : */}
                {/* <Image source={config.Images.DownArrow} /> */}
                <SvgXml
                  xml={config.svgs.downArrowBlack}
                  height={10}
                  width={10}
                  style={{marginRight: 10}}
                />
              </View>
            </TouchableOpacity>
            {/* Line Break */}
            <View style={styles.productListLineBreak}>
              <View style={styles.lineForProductListLineBreak}></View>
              <Text style={styles.titleValue}>{t('Orders')}</Text>
              <View style={styles.lineForProductListLineBreak}></View>
            </View>
          </>
        )}
        {/* Orders List */}

        {isProductLoader ? (
          // <ActivityIndicator style={{ flex: 1 }} size="small" color={config.fontAttribute.themeColor} />

          <FlatList
            showsVerticalScrollIndicator={false}
            data={skaletonData}
            // onEndReachedThreshold={.7}
            renderItem={({item}) => skeletonRenderItem()}
          />
        ) : (
          <>
            <FlatList
              style={{marginBottom: 10}}
              onRefresh={onListRefresh}
              refreshing={isRefreshing}
              onEndReached={onEndReached}
              showsVerticalScrollIndicator={false}
              data={OrderList}
              onEndReachedThreshold={0.7}
              ListEmptyComponent={NoData}
              renderItem={({item}) => productListRenderItem(item)}
              // keyExtractor={item => item.materialCode}
            />
            {lazyLoader ? (
              <ActivityIndicator
                size="small"
                color={config.fontAttribute.themeColor}
              />
            ) : (
              <></>
            )}
          </>
        )}
      </View>
      <ModalPage
        isOpen={isRetailerListModal}
        onClose={toggleRetailerList}
        modalList={profileDetail?.retailers}
        TypeValueChanged={onRetailerSelection}
      />
    </SafeAreaView>
  );
};

export default Order;
