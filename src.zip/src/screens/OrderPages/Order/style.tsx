import { StyleSheet } from "react-native";
import * as config from '../../../config/index'
import { pixelValue } from "../../../config/GlobalVariable";

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff', flex: 1, marginVertical: 5, borderRadius: 10, paddingHorizontal: 20
  },
  searchFilterView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  filterByCategoryText: {
    color: config.fontAttribute.TextColor1,
    fontSize: config.fontAttribute.labelFontSizeSmall,
    marginLeft: 5
  },
  filterByCategory: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    flex: 1,
  },
  filterIcon: {
    tintColor: config.fontAttribute.TextColor1,
  },
  orderCard: {
    borderWidth: 1,
    borderColor: 'rgba(102,112,133,0.4)',
    borderRadius: 10,
    height: 'auto',
    padding: 10,
    marginVertical: 5,
    backgroundColor: '#fff'
  },
  orderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  title: {
    color: config.fontAttribute.TextColor2,
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '600'
  },
  titleValue: {
    color: config.fontAttribute.TextColor1,
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '500'
  },
  distributorName: {
    color: config.fontAttribute.themeColor,
    fontSize: config.fontAttribute.labelFontSize * pixelValue,
    fontWeight: '600',
    maxWidth: '80%'
  },
  totalAmount: {
    color: config.fontAttribute.TextColor2,
    fontSize: config.fontAttribute.labelFontSize * pixelValue,
    fontWeight: '700'
  },
  cancelOrder: {
    color: 'red',
    fontSize:config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '400'
  },
  downArrow: {
    position: 'absolute',
    right: 15,
    bottom: 20
  },
  productListLineBreak: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 15,
  },
  lineForProductListLineBreak: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(102,112,133,0.4)',
    width: '35%',
    marginHorizontal: 10,
  }
})

export default styles;