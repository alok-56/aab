import { View, Text, Modal, TouchableOpacity, StyleSheet, FlatList, Image } from 'react-native'
import React, { useEffect, useState } from 'react'
import * as Icons from '../../../config/images'
import { pixelValue } from '../../../config/GlobalVariable'
import * as config from '../../../config/index'
import { useTranslation } from 'react-i18next'

export const ModalPage = (props: any) => {
    const { t, i18n } = useTranslation();
    const { isOpen, onClose, modalList, dropdownType, TypeValueChanged } = props;
    const [dropdownTitle, setDropdownTitle] = useState('Retailer');
    const [SelectedRetailer, SetSelectedRetailer] = useState<any>();
    useEffect(() => {
        // SetSelectedRetailer(null);
    }, [dropdownType])


    const ListItemClicked = (item: any) => {
        console.log(item, dropdownType)
        SetSelectedRetailer(item);
        TypeValueChanged(item, dropdownType);
        onClose();
    }
    const crossIconClicked = () => {
        onClose();
    }

    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={config.AppStyle.AppStyle.ModalOuterCss}>
                    <TouchableOpacity activeOpacity={0.9} onPress={crossIconClicked}>
                        <View style={config.AppStyle.AppStyle.ModalCrossIcon}>
                            <Image source={Icons.cross} />
                        </View>
                    </TouchableOpacity>
                    <View style={config.AppStyle.AppStyle.ModalInnerCss}>
                        <Text style={styles.modalTitle}> {t('selectRetailer')}</Text>
                        {modalList == null ? null :
                            <FlatList style={{ marginTop: 20 }} data={modalList}
                                renderItem={({ item }) =>
                                    <TouchableOpacity
                                        onPress={() => ListItemClicked(item)}
                                        style={[styles.companyName]}
                                        activeOpacity={0.7} >
                                        <Text
                                            style={[styles.companyNameText,
                                            { color: SelectedRetailer?.retailerName == item?.retailerName ? '#0051AC' : config.fontAttribute.TextColor1 }]}>{item?.retailerName}</Text>
                                        {
                                            SelectedRetailer?.retailerName == item?.retailerName ?
                                                <Image source={Icons.tick} /> : null
                                        }
                                    </TouchableOpacity>}
                            />}
                    </View>
                </View>
            </Modal >
        </View>
    )
}



export const DistributorModal = (props: any) => {
    const { t, i18n } = useTranslation();
    const { isOpen, onClose, modalList, ListValueChanged } = props;
    const [selectedDistributor, setSelectedDistributor] = useState<any>(null);

    const ListItemClicked = (item: any) => {
        ListValueChanged(item, 'distributor');
        setSelectedDistributor(item);
        onClose();
    }
    const crossIconClicked = () => {
        onClose();
    }
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={config.AppStyle.AppStyle.ModalOuterCss}>
                    <TouchableOpacity activeOpacity={0.9} onPress={crossIconClicked}>
                        <View style={config.AppStyle.AppStyle.ModalCrossIcon}>
                            <Image source={Icons.cross} />
                        </View>
                    </TouchableOpacity>
                    <View style={config.AppStyle.AppStyle.ModalInnerCss}>
                        <Text style={styles.modalTitle}> {t('selectDistributor')}</Text>
                        {modalList == null ? null :
                            <FlatList style={{ marginTop: 20 }} data={modalList}
                                renderItem={({ item }) =>
                                    <TouchableOpacity
                                        onPress={() => ListItemClicked(item)}
                                        style={[styles.companyName]}
                                        activeOpacity={0.7} >
                                        <Text style={[styles.companyNameText, { color: selectedDistributor?.distributor?.distributorCode == item?.distributor?.distributorCode ? '#0051AC' : '' }]}>{item?.distributor?.distributorName}</Text>
                                        {
                                            selectedDistributor?.distributor?.distributorCode == item?.distributor?.distributorCode ?
                                                <Image source={Icons.tick} /> : null
                                        }
                                    </TouchableOpacity>}
                            />}
                    </View>
                </View>
            </Modal >
        </View>
    )
}





const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.8)'
    },
    innerModalView: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '100%',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        padding: 5
    },
    companyName: {
        backgroundColor: '#fff',
        height: 65,
        padding: 15,
        // borderColor :'#667085',
        // borderBottomWidth:0.7
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    companyNameText: {
        color: '#3D5E87',
        fontWeight: '400',
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
    },
    crossIcon: {
        alignItems: 'flex-end',
        marginBottom: 30,
        marginRight: 20
    },
    modalTitle: {
        color: config.fontAttribute.themeColor,
        fontWeight: '500',
        fontSize: config.fontAttribute.labelFontSizeLarge,
        margin: 10,
        textAlign: 'center'
    }
})