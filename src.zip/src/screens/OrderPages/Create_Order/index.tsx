import {useFocusEffect, useIsFocused} from '@react-navigation/native';
import {debounce} from 'lodash';
import React, {useCallback, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {
  ActivityIndicator,
  FlatList,
  Image,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import {PageIndicator} from 'react-native-page-indicator';
import {SvgXml} from 'react-native-svg';
import {shallowEqual, useSelector} from 'react-redux';
import {
  AddToCart,
  CreateCart,
  DeleteFromCart,
  GetCartDetails,
  GetProductCategoryList,
  GetProductList,
} from '../../../ApiServices/httpServices';
import {ICategoryModel} from '../../../AppModel/CommonListModel';
import {IDsrProfileDto} from '../../../AppModel/DsrProfileModal';
import {IProductList} from '../../../AppModel/ProductListModal';
import {
  Distributor2,
  IuserPorfileDto,
} from '../../../AppModel/UserProfileModel';
import {Headercomponent} from '../../../Components';
import NoData from '../../../Components/No_Data_Component';
import Skeleton from '../../../Components/skeleton/skeleton';
import {NavMenu} from '../../../config/GlobalVariable';
import * as config from '../../../config/index';
import Index from './Carousal';
import FilterModal from './FilterModal';
import {ModalPage} from './RetailerList';
import styles from './style';

let tempList: Array<IProductList> = [];
let cartDetailsVar: any = null;
let selectedRetailer: any = null;

const CreateOrder = (props: any) => {
  const {t, i18n} = useTranslation();
  const [isfilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [productQuantity, setProductquantity] = useState(0);
  const [productCategory, setProductCategory] =
    useState<Array<ICategoryModel>>();
  const [productList, setProductList] = useState<Array<IProductList>>([]);
  const [selectedDistributor, setSelectedDistributor] = useState<any>(null);
  const [pageIndex, setPageIndex] = useState(0);
  const [isProductLoader, setIsProductLoader] = useState(false);
  const [isLazyLoader, setIsLazyLoader] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<any>('');
  const [selectedSearchText, setSelectedSearchText] = useState('');
  const [selectedProducts, setSelectedProducts] = useState<Array<IProductList>>(
    [],
  );
  // const [totalItems, setTotalItems] = useState(0);
  const [CartDetails, setCartDetails] = useState<any>();
  const [isCartButtonVisible, setIsCartButtonVisible] = useState(false);
  let CategoryList: Array<ICategoryModel> = [];
  // const [ProfileDetails, setProfileDetail] = useState<IuserPorfileDto | IDsrProfileDto | null>(null);

  const [isRetailerListMModal, setIsRetailerListMModal] = useState(false);
  const [selectedId, setSelectedId] = useState(1);

  const isFocused = useIsFocused();
  // const [selectedRetailer, setSelectedRetailer] = useState<any>(null);
  useFocusEffect(
    React.useCallback(() => {
      if (isFocused) {
        // Alert.alert("called")
        // getCartItems(props?.route?.params?.cartId);
        // console.log(profileDetail)
        // productList.length = 0;
        // tempList = [];
        // setProductList(productList)
        // setSelectedCategory('');
        // setSelectedSearchText('')
        // setSelectedDistributor(null);
        // setIsCartButtonVisible(false);
        // setCartDetails(null);
        selectedDistributor && onListRefresh();

        // selectedRetailer = null;

        //Auto calling Api for Products In Case of DSR
        // profileDetail?.profile?.profileRole?.id == 4 &&
        //     // onDistributorSelected(profileDetail?.distributor);
        //     setSelectedDistributor(profileDetail?.distributor)
        // getProduct(profileDetail?.distributor?.distributorCode, 10, 0, "", "");
        // getCategory(profileDetail?.distributor?.distributorCode);

        //In Case of Retailer
        profileDetail?.profile?.profileRole?.id == 3
          ? // setSelectedRetailer(profileDetail?.retailerCode);
            (selectedRetailer = profileDetail)
          : null;
      }
    }, [isFocused]),
  );
  const [modalList, setModalList] = useState<any>([]);
  const [dropdownType, setDropdownType] = useState('');

  const profileDetail: IDsrProfileDto | IuserPorfileDto | any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );

  const togglefilterModal = () => {
    setIsFilterModalOpen(!isfilterModalOpen);
  };
  const debouncedSearch = useCallback(
    debounce(async (search: any, distributorCode: any, category: any) => {
      console.warn(search);
      console.log(distributorCode);
      setIsProductLoader(true);
      productList.length = 0;
      setProductList(productList);
      await getProduct(distributorCode, 10, 0, category, search);
    }, 500),
    [],
  );
  const onSearchTextChanged = async (val: any) => {
    setSelectedSearchText(val);

    UniqueSelectedProductListSetter();
    let distributorCode = selectedDistributor.distributorCode;
    let category = selectedCategory;
    debouncedSearch(val, distributorCode, category);
  };

  const onDistributorSelected = async (distributor: any) => {
    productList.length = 0;
    tempList = [];
    console.log('Distributor', distributor);
    setProductList(productList);
    setSelectedCategory('');
    setSelectedSearchText('');
    setSelectedDistributor(distributor);
    setIsProductLoader(true);
    setIsCartButtonVisible(false);
    setCartDetails(null);

    getProduct(distributor.distributorCode, 10, 0, '', '');
    getCategory(distributor.distributorCode);
    // createCart(distributor.distributorCode);
    getCart(distributor.distributorCode);
  };
  const onRetailerSelection = (value: any, valueType: string = '') => {
    // onDistributorSelected(profileDetail?.distributor);
    // setSelectedRetailer(value);
    console.log('selected Retailer', value);
    selectedRetailer = value;
    // getCart(profileDetail?.distributor?.distributorCode);
    onDistributorSelected(profileDetail?.distributor);
  };
  // Create Cart API Call
  const createCart = (distributorCode: number) => {
    // CreateCart(distributorCode, profileDetail?.profile.profileId).then((result: any) => {
    CreateCart(distributorCode, selectedRetailer?.retailerCode)
      .then((result: any) => {
        console.log('cartCreated', result);
        getCart(distributorCode);
      })
      .catch((err: any) => {
        showMessage({
          message: err.message,
          color: 'white',
          duration: 5000,
          animated: true,
          backgroundColor: 'red',
        });
        console.log('error', err);
      });
  };

  // Get Cart Details Api Call
  const getCart = (distributorCode: number) => {
    // GetCartDetails(distributorCode, profileDetail?.profile?.profileId).then((result: any) => {
    GetCartDetails(distributorCode, selectedRetailer?.retailerCode)
      .then((result: any) => {
        if (result == '') {
          createCart(distributorCode);
        } else {
          if (result.items != null) setIsCartButtonVisible(true);
          cartDetailsVar = result;
          setCartDetails(result);
          console.log('cartDetails', result);
        }
      })
      .catch((err: any) => {
        showMessage({
          message: err.message,
          color: 'white',
          duration: 5000,
          animated: true,
          backgroundColor: 'red',
        });
        console.log('error', err);
      });
  };

  const addToCart = (
    cartId: Number,
    materialCode: Number,
    itemQuantity: Number,
  ) => {
    let params = {
      CartId: cartId,
      MaterialCode: materialCode,
      ItemQuantity: itemQuantity,
      DistributorCode: selectedDistributor.distributorCode,
    };
    // console.log(cartDetailsVar);
    console.log('cart Params', params);
    AddToCart(params)
      .then(result => {
        console.log('addToCart Result', result);
      })
      .catch(err => {
        showMessage({
          message: err.message,
          color: 'white',
          duration: 5000,
          animated: true,
          backgroundColor: 'red',
        });
        console.log('error', err);
      });
  };

  // Get Category list API Call
  const getCategory = async (distributorCode: any) => {
    GetProductCategoryList(distributorCode)
      .then((result: any) => {
        console.log('categoryList', result);
        result.map((item: any) => {
          let obj: ICategoryModel = {CategoryName: '', IsSelected: false};
          obj.CategoryName = item;
          CategoryList.push(obj);
        });
        console.log(CategoryList);
        setProductCategory(CategoryList);
      })
      .catch((err: any) => {
        showMessage({
          message: err.message,
          color: 'white',
          duration: 5000,
          animated: true,
          backgroundColor: 'red',
        });
        console.error('error:', err);
      });
  };

  // Get Product List API Call
  const getProduct = async (
    distributorCode: any,
    PageSize: any,
    PageIndexNumber: any,
    Category: string = '',
    SearchText: string = '',
  ) => {
    let param = {
      DistributorCode: distributorCode,
      Category: Category,
      SearchText: SearchText,
      PageSize: PageSize,
      PageIndex: PageIndexNumber,
    };
    console.log('Products Param', param);

    GetProductList(param)
      .then((result: Array<IProductList>) => {
        console.log(result);

        console.log('selectedProducts', tempList);
        if (PageIndexNumber == 0) {
          if (tempList.length > 0) {
            // if (PageIndexNumber > 0) {

            console.warn('temp>0,pro>0', tempList);
            const filteredArray2 = result.filter(
              obj2 =>
                !tempList.some(obj1 => obj1.materialCode === obj2.materialCode),
            );
            console.log('filtered Array', filteredArray2);
            const finalResult = tempList.concat(filteredArray2);

            let itemList = productList?.concat(finalResult);
            setProductList(itemList);
          } else {
            console.warn('temp not>0,pro>0', tempList);

            let itemList = productList?.concat(result);
            setProductList(itemList);
          }
        } else {
          console.warn('temp not>0,pro not>0', tempList);

          let itemList = productList?.concat(result);
          setProductList(itemList);
        }
        setIsProductLoader(false);
        setIsLazyLoader(false);
      })
      .catch((err: any) => {
        setIsProductLoader(false);
        setIsLazyLoader(false);
        showMessage({
          message: err.message,
          color: 'white',
          duration: 5000,
          animated: true,
          backgroundColor: 'red',
        });
        console.error('error:', err);
      });
  };

  const UniqueSelectedProductListSetter = () => {
    let array: Array<IProductList> = productList.filter(
      item => item?.quantity > 0,
    );

    if (tempList.length > 0) {
      // Create a Set to automatically remove duplicates based on a unique identifier or properties
      const uniqueSet = new Set(array.map(item => item.materialCode));

      // Add items from the 'array' that are not already in 'uniqueSet'
      tempList.forEach(item => {
        if (!uniqueSet.has(item.materialCode)) {
          array.push(item);
          uniqueSet.add(item.materialCode);
        }
      });
      tempList = array;
      // setSelectedProducts(array);

      console.log('Unique', Array.from(uniqueSet));
    } else {
      tempList = tempList.concat(array);
      // setSelectedProducts(selectedProducts.concat(array));
    }
  };
  const onApplyButtonClicked = async (e: any) => {
    if (e) {
      UniqueSelectedProductListSetter();

      setSelectedSearchText('');
      console.log(selectedDistributor);
      setIsProductLoader(true);
      togglefilterModal();
      setSelectedCategory(e.CategoryName);
      productList.length = 0;
      setProductList(productList);
      await getProduct(
        selectedDistributor.distributorCode,
        10,
        0,
        e.CategoryName,
        '',
      );
    } else {
      console.log('no filter');
      togglefilterModal();
    }
  };

  const [isRefreshing, setIsRefreshing] = useState(false);

  const onListRefresh = async () => {
    setIsProductLoader(true);
    setSelectedCategory('');
    setPageIndex(0);

    productList.length = 0;
    setProductList(productList);

    tempList.length = 0;
    // setSelectedProducts(selectedProducts);

    console.log(productList);
    await getProduct(selectedDistributor.distributorCode, 10, 0, '', '');
  };
  const onEndReached = async () => {
    if (productList.length == 0) {
      // setIsLazyLoader(false);
      return;
    }
    setIsLazyLoader(true);
    // if (selectedCategory) {
    //     console.log('cate')
    await getProduct(
      selectedDistributor.distributorCode,
      10,
      pageIndex + 1,
      selectedCategory,
      selectedSearchText,
    );
    // } else {
    //     console.log('norm')
    //     await getProduct(selectedDistributor.distributorCode, 10, pageIndex + 1, '', '')
    // }
    setPageIndex(pageIndex + 1);
  };

  const onFilterLabelCrossClicked = () => {
    UniqueSelectedProductListSetter();

    setSelectedSearchText('');
    setSelectedCategory('');
    productList.length = 0;
    setProductList(productList);
    setIsProductLoader(true);
    getProduct(selectedDistributor.distributorCode, 10, 0, '', '');
    // onDistributorSelected(selectedDistributor);
    setPageIndex(0);
  };

  const onProductPlusClicked = (item: any) => {
    setProductquantity(productQuantity + 1);
    if (item?.quantity == undefined) item.quantity = 0;
    item.quantity++;
    // setTotalItems(totalItems + 1)

    addToCart(CartDetails?.id, item?.materialCode, 1);
  };

  const onProductMinusClicked = (item: any) => {
    if (item?.quantity == null) {
      setProductquantity(0);
      item.quantity = 1;
      // setTotalItems(0)
    } else {
      setProductquantity(productQuantity - 1);
      if (item?.quantity == 0) item.quantity = 0;
      item.quantity--;
      // setTotalItems(totalItems - 1)
      addToCart(CartDetails?.id, item?.materialCode, -1);
    }
  };

  const addToCartClicked = () => {
    props.navigation.navigate(NavMenu.order.Cart, {cartId: CartDetails?.id});
    UniqueSelectedProductListSetter();

    // console.log(selectedProducts)
  };
  const onAddtoCartButtonClicked = (item: any) => {
    setIsCartButtonVisible(true);
    let qty = productQuantity + 1;
    setProductquantity(qty);

    if (item?.quantity == undefined || item?.quantity == null)
      item.quantity = 1;

    addToCart(CartDetails?.id, item?.materialCode, 1);
  };
  const [expandableIndex, setExpandableIndex] = useState<any>(null);
  const setExpandableState = (index: any) => {
    if (index == expandableIndex) {
      setExpandableIndex(null);
    } else {
      setExpandableIndex(index);
    }
  };
  const onDeleteItemClicked = (item: any) => {
    setProductquantity(productQuantity + 1);
    item.quantity = null;
    console.log('here');
    DeleteCartItem(item);
  };
  const DeleteCartItem = (item: any) => {
    DeleteFromCart(
      CartDetails?.id,
      selectedDistributor?.distributorCode,
      item?.materialCode,
    )
      .then(result => {
        console.log('item deleted', result);

        // getCartItems(cartItems.id);
      })
      .catch(err => {
        showMessage({
          message: err?.message,
          color: 'white',
          duration: 5000,
          animated: true,
          backgroundColor: 'red',
        });
        console.log('error', err);
      });
  };
  const productListRenderItem = (item: any, index: any) => {
    return (
      // item?.distributorInventoryItem == null ? <></> :
      <>
        <View style={styles.productCard}>
          {/* Product Details */}
          <View style={{flexDirection: 'row', flex: 1.1}}>
            {item?.quantity >= 1 ? (
              <View
                style={{
                  width: 20,
                  backgroundColor: 'green',
                  paddingVertical: 0,
                  marginRight: 10,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <SvgXml xml={config.svgs.tickIcon} height={10} width={10} />
              </View>
            ) : null}

            <View style={{paddingVertical: 10}}>
              <Text style={styles.productId}>{item?.materialCode}</Text>
              <Text
                onPress={() => setExpandableState(index)}
                style={styles.productDescription}
                numberOfLines={index == expandableIndex ? undefined : 1}>
                {item?.description}
              </Text>
              <Text style={styles.productRate}>
                {t('rate')} :
                <Text style={styles.productRateValue}>
                  {' '}
                  {item?.materialRDP ? (
                    <Text>&#8377;{item?.materialRDP?.rdp}</Text>
                  ) : (
                    ' -'
                  )}
                </Text>
              </Text>
              {
                item?.distributorInventoryItem?.[0]?.goodItemQuantity === 0 ? (
                  <Text style={styles.outOfStockText}>{t('outOfStock')}</Text>
                ) : null
                //     <Text style={styles.productRate}>{t('Available Quantity')} :
                //     <Text style={styles.productRateValue}>{item?.distributorInventoryItem?.[0]?.goodItemQuantity}</Text>
                // </Text>
              }
              {item?.distributorInventoryItem == null ? (
                <Text style={styles.notAvailableText}>{t('notAvailable')}</Text>
              ) : (
                <></>
              )}
            </View>
          </View>
          {item?.distributorInventoryItem ? (
            <View
              style={{flex: 0.4, paddingVertical: 10, alignItems: 'center'}}>
              <Text style={[styles.productId, {fontSize: 11}]}>
                {t('availableQuantity')}
              </Text>
              <Text style={styles.productDescription}>
                {item?.distributorInventoryItem?.[0]?.goodItemQuantity
                  ? item?.distributorInventoryItem?.[0]?.goodItemQuantity
                  : '0'}
              </Text>
            </View>
          ) : (
            <></>
          )}
          {/* <View style={{ flex: 0.4, paddingVertical: 10, alignItems: 'center' }}>
                        <Text style={[styles.productId, { fontSize: 11 }]}>{t('availableQuantity')}</Text>
                        <Text style={styles.productDescription}>
                            {item?.distributorInventoryItem?.[0]?.goodItemQuantity ? item?.distributorInventoryItem?.[0]?.goodItemQuantity : '0'}
                        </Text>
                    </View> */}

          {item?.quantity == null ? (
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'flex-end',
                alignItems: 'center',
                flex: 0.5,
              }}>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() =>
                  item?.distributorInventoryItem == null ||
                  item?.materialRDP == null
                    ? // || item?.distributorInventoryItem?.[0]?.goodItemQuantity === 0
                      {}
                    : onAddtoCartButtonClicked(item)
                }>
                <View style={styles.addtoCartButton}>
                  <Text style={styles.addToCartText}>{t('addToCart')}</Text>
                </View>
              </TouchableOpacity>
            </View>
          ) : (
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'flex-end',
                alignItems: 'center',
                flex: 0.7,
              }}>
              {item?.quantity > 1 ? (
                <TouchableOpacity
                  activeOpacity={0.8}
                  onPress={() =>
                    item?.distributorInventoryItem == null ||
                    item?.materialRDP == null
                      ? {}
                      : onProductMinusClicked(item)
                  }>
                  <View style={[styles.plusMinusIconArea]}>
                    <Image source={config.Images.minus} />
                  </View>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  activeOpacity={0.8}
                  onPress={() => onDeleteItemClicked(item)}>
                  <View style={styles.plusMinusIconArea}>
                    {/* {
                                        minusButtonLoader ?
                                            <ActivityIndicator size='small' color={config.fontAttribute.themeColor} />
                                            : */}
                    <SvgXml
                      xml={config.svgs.deleteBlue}
                      height={15}
                      width={15}
                    />
                    {/* } */}
                  </View>
                </TouchableOpacity>
              )}
              <View style={styles.productQuantityArea}>
                <Text
                  style={{
                    color: config.fontAttribute.TextColor2,
                    fontWeight: '500',
                    fontSize: config.fontAttribute.labelFontSizeLarge,
                  }}>
                  {item?.quantity ?? 0}
                </Text>
              </View>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => {
                  item?.distributorInventoryItem == null ||
                  item?.materialRDP == null
                    ? {}
                    : onProductPlusClicked(item);
                }}>
                <View style={[styles.plusMinusIconArea]}>
                  <Image source={config.Images.plus} />
                </View>
              </TouchableOpacity>
            </View>
          )}

          {/* Quantity Changing Buttons */}
        </View>
        <View style={styles.lineBreak}></View>
      </>
    );
  };
  const skaletonData = [{}, {}, {}, {}, {}, {}];
  const skeletonRenderItem = () => {
    return (
      <Skeleton>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginVertical: 10,
            backgroundColor: '#fff',
            borderRadius: 4,
          }}>
          <View>
            <View style={{width: 150, height: 10, marginVertical: 3}}></View>
            <View style={{width: 180, height: 10, marginVertical: 3}}></View>
            <View style={{width: 60, height: 10, marginVertical: 3}}></View>
          </View>
          <View style={{flexDirection: 'row'}}>
            <View style={styles.plusMinusIconArea}></View>
            <View style={styles.plusMinusIconArea}></View>
            <View style={styles.plusMinusIconArea}></View>
          </View>
        </View>
      </Skeleton>
    );
  };

  const dropDownClicked = (dropdownType: any) => {
    setModalList(profileDetail?.retailers);
    setDropdownType('retailer');
    toggleRetailerListMenu();
  };
  const toggleRetailerListMenu = () => {
    // setIsClicked(false);
    setIsRetailerListMModal(!isRetailerListMModal);
  };
  // const NoDataComponent = ()=>{
  //     return(
  //         <View></View>
  //     )
  // }

  const Distributors: Array<Distributor2> = useSelector(
    (state: any) => state.auth.Distributors,
    shallowEqual,
  );
  const [current, setCurrent] = React.useState(0);
  return (
    <>
      <Headercomponent
        name={
          props?.route.params?.isCreateOrder
            ? t('createOrder')
            : profileDetail?.profile?.profileRole?.id == 3
            ? t('selectDistributor')
            : t('selectRetailer')
        }
        type={'2'}
      />
      <View style={styles.container}>
        <View style={{flex: 1}}>
          {profileDetail?.profile?.profileRole?.id == 4 && (
            <>
              <Text style={styles.distributor}>{t('retailer')}</Text>

              <TouchableOpacity
                onPress={() => {
                  dropDownClicked('retailer');
                }}
                activeOpacity={1}>
                <View style={config.AppStyle.AppStyle.inputField}>
                  <TextInput
                    placeholder={t('selectRetailerPlaceholder')}
                    value={selectedRetailer?.retailerName}
                    editable={false}
                    style={{color: config.fontAttribute.TextColor1}}
                    placeholderTextColor={config.fontAttribute.placeholderColor}
                  />
                  {/* {isClicked ? <Image style={styles.downArrow} source={config.Images.upArrowBlack} /> : */}
                  <Image
                    style={styles.downArrow}
                    source={config.Images.DownArrow}
                  />
                </View>
              </TouchableOpacity>
            </>
          )}

          {/* Distributor Area */}
          {profileDetail?.profile?.profileRole?.id == 3 && (
            <>
              <Text style={styles.distributor}>{t('distributor')}</Text>

              <View
                style={{
                  marginBottom: 80,
                }}>
                <Index
                  onItemclicked={(e: any) => onDistributorSelected(e)}
                  setCurrent={setCurrent}
                />
              </View>
              <View
                style={{
                  marginVertical: 20,
                }}>
                <PageIndicator
                  count={Distributors?.length}
                  current={current}
                  variant="beads"
                  activeColor={config.fontAttribute.themeColor}
                  color="#8FB5D0"
                />
              </View>
            </>
          )}

          {/* Search field */}
          {props?.route?.params?.isCreateOrder ? (
            <View style={{flex: 1}}>
              <View style={styles.searchFilterView}>
                <View
                  style={[
                    config.AppStyle.AppStyle.inputField,
                    {flex: 1.5, height: 40, marginRight: 10},
                  ]}>
                  <Image
                    style={{marginEnd: 5, width: 20, height: 20}}
                    source={config.Images.search}
                  />
                  <TextInput
                    selectionColor={config.fontAttribute.cursorColor}
                    placeholderTextColor={config.fontAttribute.placeholderColor}
                    editable={selectedDistributor ? true : false}
                    placeholder={t('searchProduct')}
                    value={selectedSearchText}
                    onChangeText={e => onSearchTextChanged(e)}
                    style={{flex: 1, color: config.fontAttribute.TextColor1}}
                  />
                </View>
                <TouchableOpacity
                  activeOpacity={0.8}
                  onPress={() =>
                    selectedDistributor ? togglefilterModal() : {}
                  }>
                  <View style={styles.filterByCategory}>
                    <Image source={config.Images.filter} />
                    <Text style={styles.filterByCategoryText}>
                      {t('filterByCategory')}
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>

              {/* Filter Label */}
              {selectedCategory ? (
                <View style={styles.filterLabel}>
                  <Text style={styles.filterLabelText}>{selectedCategory}</Text>
                  <TouchableOpacity
                    activeOpacity={0.8}
                    style={{padding: 5}}
                    onPress={() => {
                      onFilterLabelCrossClicked();
                    }}>
                    <SvgXml
                      style={styles.filterLabelCrossIcon}
                      xml={config.svgs.crossBlue}
                      height={8}
                      width={8}
                    />
                  </TouchableOpacity>
                </View>
              ) : null}

              {/* Product List */}
              {isProductLoader ? (
                // <ActivityIndicator style={{ flex: 1 }} size="small" color={config.fontAttribute.themeColor} />

                <FlatList
                  showsVerticalScrollIndicator={false}
                  data={skaletonData}
                  onEndReachedThreshold={0.7}
                  renderItem={({item}) => skeletonRenderItem()}
                />
              ) : (
                <>
                  <FlatList
                    style={{marginTop: 5, marginBottom: 15}}
                    onRefresh={onListRefresh}
                    refreshing={isRefreshing}
                    onEndReached={onEndReached}
                    showsVerticalScrollIndicator={false}
                    data={productList}
                    onEndReachedThreshold={0.7}
                    ListEmptyComponent={NoData}
                    renderItem={({item, index}) =>
                      productListRenderItem(item, index)
                    }
                    keyExtractor={item => item.materialCode}
                  />
                  {isLazyLoader ? (
                    <ActivityIndicator
                      style={{flex: 1}}
                      size="small"
                      color={config.fontAttribute.themeColor}
                    />
                  ) : null}
                </>
              )}
            </View>
          ) : (
            <>
              {selectedDistributor && !isCartButtonVisible && (
                <View style={styles.noCartMessage}>
                  <Image
                    source={config.Images.emptyCart}
                    resizeMode="contain"
                    style={{width: 100, height: 100}}
                  />
                  <Text style={styles.noCartMessageText}>
                    {t('yourCartisempty')}
                  </Text>
                </View>
              )}
            </>
          )}
          {/* Product List Title */}
        </View>

        <TouchableOpacity
          activeOpacity={isCartButtonVisible ? 0.8 : 1}
          style={[
            config.AppStyle.AppStyle.button,
            {marginTop: 20, opacity: isCartButtonVisible ? 1 : 0.5},
          ]}
          onPress={() => {
            !isCartButtonVisible ? {} : addToCartClicked();
          }}>
          <Text style={config.AppStyle.AppStyle.buttonText}>{t('cart')}</Text>
        </TouchableOpacity>
      </View>

      {/* Modal for Retailer List in Case of DSR */}
      <ModalPage
        isOpen={isRetailerListMModal}
        onClose={toggleRetailerListMenu}
        modalList={modalList}
        TypeValueChanged={onRetailerSelection}
        // caseCategoryValueChanged={caseCategoryValueChanged}
        selectedId={selectedId}
        dropdownType={dropdownType}
      />

      {/* Filter Modal */}
      <FilterModal
        data={productCategory}
        isOpen={isfilterModalOpen}
        onClose={togglefilterModal}
        onApplyButtonClicked={(e: any) => {
          onApplyButtonClicked(e);
        }}
      />
    </>
  );
};

export default CreateOrder;
