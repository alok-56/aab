import { StyleSheet } from "react-native"
import { pixelValue } from "../../../config/GlobalVariable"
import * as config from '../../../config/index'

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        flex: 1,
        marginTop: 5,
        // borderRadius:10,
        padding: 20
    },
    lineBreak: {
        borderColor: 'rgba(102,112,133,0.2)',
        borderWidth: 0.3,
        // margin: 10,
        marginVertical: 1
    },
    downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 20
    },
    productCard: {
        // backgroundColor: '#EAF4FF',
        borderRadius: 15,
        height: 'auto',
        paddingHorizontal: 10,
        flexDirection: 'row',
        // justifyContent: 'space-between',
        // borderBottomWidth: 1,
        // borderBottomColor: 'rgba(102,112,133,0.2)'
    },
    filterByCategoryText: {
        color: config.fontAttribute.themeColor,
        fontSize: config.fontAttribute.labelFontSizeSmall,
        marginLeft: 5
    },
    filterByCategory: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        flex: 1,
    },
    searchFilterView: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    distributor: {
        fontSize: config.fontAttribute.headingFontSize,
        fontWeight: '600',
        color: config.fontAttribute.TextColor1
    },
    filterLabel: {
        backgroundColor: '#F2F6F9',
        borderColor: '#C3E3FB',
        borderWidth: 1,
        borderRadius: 10,
        paddingHorizontal: 10,
        paddingVertical: 8,
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'flex-start'
    },
    filterLabelText: {
        color: config.fontAttribute.themeColor,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    },
    filterLabelCrossIcon: {
        marginLeft: 10
    },
    productId: {
        color: config.fontAttribute.TextColor2, fontSize: 12, fontWeight: '600'
    },
    productDescription: {
        color: config.fontAttribute.TextColor1, fontWeight: '300', fontSize: 10, maxWidth: '90%'
    },
    productRate: {
        color: config.fontAttribute.TextColor1, fontWeight: '400', fontSize: 10
    },
    productRateValue: {
        color: config.fontAttribute.TextColor1, fontWeight: '300', fontSize: 10
    },
    plusMinusIconArea: {
        justifyContent: 'center',
        alignItems: 'center',
        width: 30,
        height: 30,
        backgroundColor: '#D7EAFF',
        margin: 2,
        borderRadius: 5,
    },
    productQuantityArea: {
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#0051AC',
        width: 30,
        height: 30,
        backgroundColor: '#fff',
        margin: 2, borderRadius: 5
    },
    outOfStockText: {
        color: 'red',
        fontSize: config.fontAttribute.labelFontSizeSmall * pixelValue,
    },
    notAvailableText: {
        color: 'red',
        fontSize: config.fontAttribute.labelFontSizeSmall * pixelValue,
    },
    addtoCartButton: {
        backgroundColor: 'rgb(234,244,255)',
        height: 'auto',
        padding: 5,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#DEEEFF'
    },
    addToCartText: {
        color: config.fontAttribute.themeColor,
        fontWeight: '500',
        fontSize: 11
    },
    noCartMessage:{ justifyContent: 'center', alignItems: 'center', flex: 1 },
    noCartMessageText: {
        fontSize: config.fontAttribute.labelFontSize,
        color: config.fontAttribute.themeColor,
        fontWeight: '500'
    }
})

export default styles