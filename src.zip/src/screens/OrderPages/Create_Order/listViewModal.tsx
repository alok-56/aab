import { View, Text, Modal, TouchableOpacity, Image, StyleSheet, FlatList } from 'react-native'
import React from 'react'
import * as config from '../../../config/index'
import { pixelValue } from '../../../config/GlobalVariable';

const ListViewModal = (props: any) => {
    const { isOpen, onClose, modalList, listItemClicked } = props;
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={styles.ModalView}>

                    <View style={styles.innerModalView}>
                        <View style={styles.crossIcon}>
                            <Text
                                style={{
                                    color: config.fontAttribute.themeColor,
                                    fontWeight: '500',
                                    fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
                                    textAlign: 'center',
                                    margin: 10
                                }}>Select distributor</Text>
                                    <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                                        <Image source={config.Images.crossBlack} />
                                    </TouchableOpacity>
                        </View>
                        <FlatList style={{ marginTop: 20 }}
                            data={modalList}
                            renderItem={({ item }) =>
                                <TouchableOpacity
                                    onPress={() => listItemClicked(item)}
                                    style={[styles.listItem]}
                                    activeOpacity={0.7} >
                                    <Text style={[styles.listItemText]}>{item.distributor.distributorName}</Text>
                                </TouchableOpacity>
                            }
                        />
                    </View>
                </View>
            </Modal>
        </View>
    )
}

export default ListViewModal

const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.8)'
    },
    innerModalView: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '100%',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        padding: 5,
        // minHeight:'40%',
    },
    crossIcon: {
        flexDirection:'row',
        justifyContent: 'space-between',
        alignItems:'center',
        marginHorizontal:10
    },
    listItem: {
        backgroundColor: '#fff',
        height: 65,
        padding: 15,
        // borderColor :'#667085',
        // borderBottomWidth:0.7
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    listItemText: {
        color: '#3D5E87',
        fontWeight: '400',
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
    },
})