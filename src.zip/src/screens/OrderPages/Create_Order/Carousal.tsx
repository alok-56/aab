import {useFocusEffect, useIsFocused} from '@react-navigation/native';
import * as React from 'react';
import {Dimensions, Text, TouchableOpacity, View} from 'react-native';
import Carousel from 'react-native-reanimated-carousel';
import {SvgXml} from 'react-native-svg';
import {shallowEqual, useSelector} from 'react-redux';
import {Distributor2} from '../../../AppModel/UserProfileModel';
import {TextColor1} from '../../../config/fontConfig';
import {capitalize} from '../../../config/GlobalVariable';
import * as config from '../../../config/index';

function Index(props: any) {
  const isFocused = useIsFocused();
  const [selectedDistributor, setSelectedDistributor] = React.useState<any>();

  useFocusEffect(
    React.useCallback(() => {
      if (isFocused) {
        // Alert.alert("called")
        // getCartItems(props?.route?.params?.cartId);
        // setSelectedDistributor(null)
      }
    }, [isFocused]),
  );

  const {onItemclicked} = props;
  const Distributors: Array<Distributor2> = useSelector(
    (state: any) => state.auth.Distributors,
    shallowEqual,
  );
  console.log('distributors', Distributors);
  const width = Dimensions.get('window').width;
  const onDistributorCardClicked = (item: any) => {
    setSelectedDistributor(item);
    onItemclicked(item);
  };
  const [current, setCurrent] = React.useState(0);
  // const animatedCurrent = React.useRef(Carousel. (scrollX, width)).current;
  return (
    <View>
      <Carousel
        width={width}
        data={Distributors}
        loop
        height={100}
        onSnapToItem={index => setCurrent(index)}
        renderItem={({index, item}) => (
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() =>
              item?.distributorCode != selectedDistributor?.distributorCode
                ? onDistributorCardClicked(item)
                : {}
            }>
            <View style={{alignItems: 'center', width: '90%'}}>
              <View
                style={{
                  borderWidth: 1,
                  borderColor:
                    item?.distributorCode !=
                    selectedDistributor?.distributorCode
                      ? 'rgba(102,112,133,0.4)'
                      : '#8FB5D0',
                  borderRadius: 10,
                  padding: 10,
                  margin: 20,
                  width: '100%',
                  backgroundColor:
                    item?.distributorCode !=
                    selectedDistributor?.distributorCode
                      ? '#fff'
                      : '#F2F6F9',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <View style={{maxWidth: '95%'}}>
                  <Text
                    numberOfLines={1}
                    style={{
                      fontSize: 16,
                      color: TextColor1,
                      fontWeight: '500',
                    }}>
                    {capitalize(item?.distributorName)}
                  </Text>
                  <Text
                    numberOfLines={1}
                    style={{
                      fontSize: 14,
                      color: TextColor1,
                      fontWeight: '300',
                    }}>
                    {item?.address1}
                  </Text>
                </View>
                <View>
                  {item?.distributorCode ==
                  selectedDistributor?.distributorCode ? (
                    <SvgXml
                      xml={config.svgs.checkedCheckbox}
                      height={20}
                      width={20}
                    />
                  ) : (
                    <SvgXml
                      xml={config.svgs.uncheckedCheckbox}
                      height={20}
                      width={20}
                    />
                  )}
                </View>
              </View>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

export default Index;
