import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Headercomponent } from '../../../Components'
import * as config from '../../../config/index'
import { NavMenu, capitalize, fixToTwoDecimal, pixelValue } from '../../../config/GlobalVariable'
import { shallowEqual, useSelector } from 'react-redux'
import { GetCartItemsDescription, PlaceYourOrder } from '../../../ApiServices/httpServices'
import styles from './style'
import HorizontalTimeLine from '../../../Components/HorizontalTimeLine/HorizontalTimeLine'
import { showMessage } from 'react-native-flash-message'
import { string } from 'prop-types'
import { useTranslation } from 'react-i18next'
import { IuserPorfileDto } from '../../../AppModel/UserProfileModel'
import { IDsrProfileDto } from '../../../AppModel/DsrProfileModal'

const PlaceOrder = (props: any) => {
    const { t, i18n } = useTranslation();
    const [isloader, setIsloader] = useState(false)

    const profileDetail: IuserPorfileDto | IDsrProfileDto | any = useSelector(
        (state: any) => state.auth.profileData,
        shallowEqual,
    );
    // const CartId: any = useSelector(
    //     (state: any) => state.auth.profileData,
    //     shallowEqual,
    // );
    useEffect(() => {
        getCartItems(props?.route?.params?.cartId)
    }, [])
    const [cartItems, setCartItems] = useState<any>();
    const getCartItems = (cartId: number) => {
        GetCartItemsDescription(cartId).then((result: any) => {
            console.log("Items in place order", result)
            setCartItems(result);
        }).catch((err: any) => {
            console.log("error", err)
        })
    }
    const placeOrder = () => {
        const params = {
            CartId: String(cartItems.id),
            CartTotal: cartItems.cartTotal,
            Tax: cartItems.tax,
            InvoiceValue: cartItems.invoiceValue,
            ExpectedDelivery: null,
            PaymentDone: false,
            IsOrderByDSR: profileDetail?.profile?.profileRole?.id == 4 ? true : false
        }
        console.log("req para", JSON.stringify(params))
        PlaceYourOrder(params, cartItems.distributorCode, cartItems.retailerCode).then((result) => {
            console.log("place order", result)
            if (result) {
                setIsloader(false)
                props.navigation.navigate(NavMenu.order.successScreen)

            }
        }).catch((err) => {
            // showMessage({ message: err.message, duration:2000,color: "white", backgroundColor: "red" })
            setIsloader(false)
            if (err.message) {
                console.log("error", err.message)
                // showMessage({ message: err.message, color: "white", backgroundColor: "red" })
                // showMessage({ message: err.message, duration: 5000, animated: true,style:{height:100} })
            }
        })
    }
    const placeOrderButtonClicked = () => {
        setIsloader(true);
        placeOrder();
    }

    return (
        <>
            <Headercomponent type={'2'} name={t('placeOrder')} />
            <HorizontalTimeLine currentStep={2} />
            <View style={styles.container}>
                <Text style={styles.orderNowText}>{t('orderNow')}</Text>
                <View style={styles.lineBreak}></View>
                <View style={styles.orderDetailsArea}>
                    <View style={styles.rows}>
                        <Text style={styles.normalFonts}>{t('shippingTo')} : <Text style={styles.distributorName}>{capitalize(cartItems?.retailer?.retailerName)}</Text></Text>
                    </View>
                    <View style={styles.rows}>
                        <Text style={styles.normalFonts}>{t('subTotal')} :</Text>
                        <Text style={styles.normalFonts}>&#8377;{fixToTwoDecimal(cartItems?.cartTotal)}</Text>
                    </View>
                    <View style={styles.rows}>
                        <Text style={styles.normalFonts}>{t('tax')} : </Text>
                        <Text style={styles.normalFonts}>&#8377;{fixToTwoDecimal(cartItems?.tax)}</Text>
                    </View>
                    <View style={styles.rows}>
                        <Text style={styles.orderTotal}>{t('orderTotal')} : </Text>
                        <Text style={[styles.orderTotal, { color: '#C90C0F' }]}>&#8377;{fixToTwoDecimal(cartItems?.invoiceValue)}</Text>
                    </View>
                </View>
                <TouchableOpacity activeOpacity={0.8} onPress={placeOrderButtonClicked} style={config.AppStyle.AppStyle.button}>
                    {
                        isloader ? <ActivityIndicator size="small" color={config.fontAttribute.whiteColor} />
                            :
                            <Text style={config.AppStyle.AppStyle.buttonText}>{t('placeYourOrder')}</Text>
                    }
                </TouchableOpacity>
            </View>
        </>
    )
}

export default PlaceOrder

