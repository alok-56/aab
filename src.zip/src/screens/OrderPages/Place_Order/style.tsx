import { StyleSheet } from "react-native";
import { pixelValue } from "../../../config/GlobalVariable";
import * as config from '../../../config/index'

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        flex: 1,
        marginTop: 5,
        // borderRadius:10,
        padding: 20
    },
    orderNowText: {
        fontSize: config.fontAttribute.labelFontSizeLarge,
        fontWeight: '600',
        color: config.fontAttribute.TextColor2
    },
    lineBreak: {
        borderColor: '#D0D5DD',
        borderWidth: 1,
        marginVertical: 10,
    },
    orderDetailsArea: {
        height: 'auto',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#D0D5DD',
        padding: 10
    },
    normalFonts: {
        fontSize: config.fontAttribute.labelFontSizeSmall * pixelValue,
        fontWeight: '400',
        color: '#67717A'
    },
    distributorName: {
        fontSize: config.fontAttribute.labelFontSizeSmall * pixelValue,
        fontWeight: '700',
        color: '#000000'
    },
    orderTotal: {
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
        color: '#000000'
    },
    rows: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginVertical: 3
    }
})

export default styles