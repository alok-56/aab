import { StyleSheet } from "react-native";
import * as config from '../../../config/index'
import { pixelValue } from "../../../config/GlobalVariable";

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        flex: 1,
        marginTop: 5,
        // borderRadius:10,
        padding: 20
    },
    greetings: {

    },
    hi: {
        fontSize: config.fontAttribute.headingFontSizeLarge * pixelValue,
        fontWeight: '600',
        color: config.fontAttribute.themeColor
    },
    distributorName: {
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
        fontWeight: '600',
        color: config.fontAttribute.TextColor1
    },
    productMessage: {
        fontSize: config.fontAttribute.labelFontSizeSmall * pixelValue,
        fontWeight: '400',
        color: config.fontAttribute.TextColor1,
    },
    lineBreak: {
        borderColor: 'rgba(102,112,133,0.5)',
        borderWidth: 0.3,
        marginVertical: 10,
    },
    productDetailsHeading: {
        fontSize: config.fontAttribute.labelFontSize * pixelValue,
        fontWeight: '600',
        color: config.fontAttribute.TextColor1,
        marginVertical: 5
    },
    productCard: {
        height: 'auto',
        padding: 10,
        backgroundColor: '#EAF4FF',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#DEEEFF',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginVertical: 5,
        flex: 1
    },
    productId: {
        color: config.fontAttribute.themeColor, fontSize: 12, fontWeight: '600'
    },
    productDescription: {
        color: config.fontAttribute.TextColor1, fontWeight: '300', fontSize: 10, maxWidth: '80%'
    },
    productRate: {
        color: config.fontAttribute.TextColor1, fontWeight: '400', fontSize: 10
    },
    productRateValue: {
        color: config.fontAttribute.TextColor1, fontWeight: '300', fontSize: 10
    },
    plusMinusIconArea: {
        justifyContent: 'center', alignItems: 'center', width: 30, height: 30, backgroundColor: '#D7EAFF', margin: 2, borderRadius: 5
    },
    productQuantityArea: {
        justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#0051AC', width: 30, height: 30, backgroundColor: '#fff', margin: 2, borderRadius: 5
    },
    nextButtonSection: {
        marginTop: 20,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    noOfItems: {
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
        color: config.fontAttribute.themeColor
    },
    noCartMessage: {
        justifyContent: 'center', alignItems: 'center', flex: 1
    },
    noCartMessageText: {
        fontSize: config.fontAttribute.labelFontSize,
        color: config.fontAttribute.themeColor,
        fontWeight: '500'
    }
})

export default styles