import {useFocusEffect, useIsFocused} from '@react-navigation/native';
import React, {useState} from 'react';
import {useTranslation} from 'react-i18next';
import {FlatList, Image, Text, TouchableOpacity, View} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import {SvgXml} from 'react-native-svg';
import {useDispatch} from 'react-redux';
import {
  AddToCart,
  DeleteFromCart,
  GetCartItemsDescription,
} from '../../../ApiServices/httpServices';
import {Headercomponent} from '../../../Components';
import Skeleton from '../../../Components/skeleton/skeleton';
import {
  NavMenu,
  capitalize,
  fixToTwoDecimal,
} from '../../../config/GlobalVariable';
import * as config from '../../../config/index';
import styles from './style';
// import SkeletonPlaceholder from 'react-native-skeleton-placeholder';

const OrderMyCart = (props: any) => {
  const {t, i18n} = useTranslation();

  const dispatch = useDispatch();

  const [plusButtonLoader, setPlusButtonLoader] = useState(false);
  const [minusButtonLoader, setMinusButtonLoader] = useState(false);
  const [updateQuantity, setUpdateQuantity] = useState<any>(0);
  const [cartItems, setCartItems] = useState<any>();
  const [isProductLoader, setIsProductLoader] = useState(false);
  // const [totalItems, setTotalItems] = useState<any>(0);
  const isFocused = useIsFocused();

  useFocusEffect(
    React.useCallback(() => {
      if (isFocused) {
        // Alert.alert("called")
        getCartItems(props?.route?.params?.cartId);
        setIsProductLoader(true);
      }
    }, [isFocused]),
  );
  // useFocusEffect(
  //     () => {
  //         setIsProductLoader(true);
  //     }, [isFocused])

  // useEffect(() => {

  //     // if (cartItems?.length == 0) {
  //     //     setIsProductLoader(true);
  //     // }
  //     // gettotalItems();
  // }, [])

  const getCartItems = (cartId: number) => {
    // setIsProductLoader(true)
    GetCartItemsDescription(cartId)
      .then((result: any) => {
        console.log('Items in cart', result);
        setCartItems(result);
        setPlusButtonLoader(false);
        setMinusButtonLoader(false);
        setIsProductLoader(false);
      })
      .catch((err: any) => {
        setIsProductLoader(false);
        showMessage({
          message: err,
          color: 'white',
          duration: 5000,
          animated: true,
          backgroundColor: 'red',
        });
        console.log('error', err);
      });
  };

  const DeleteCartItem = (materialCode: any) => {
    DeleteFromCart(
      cartItems?.id,
      cartItems?.distributor?.distributorCode,
      materialCode,
    )
      .then(result => {
        console.log('item deleted', result);
        getCartItems(cartItems.id);
      })
      .catch(err => {
        showMessage({
          message: err?.message,
          color: 'white',
          duration: 5000,
          animated: true,
          backgroundColor: 'red',
        });
        console.log('error', err);
      });
  };

  const onNextButtonClicked = () => {
    props.navigation.navigate(NavMenu.order.selectDeliveryAddress, {
      retailerDetails: cartItems?.retailer,
      cartId: cartItems?.id,
    });
  };
  const addToCart = (
    cartId: Number,
    materialCode: Number,
    itemQuantity: Number,
  ) => {
    let params = {
      CartId: cartId,
      MaterialCode: materialCode,
      ItemQuantity: itemQuantity,
      DistributorCode: cartItems?.distributor?.distributorCode,
    };
    // console.log(cartDetailsVar);
    console.log('cart Params', params);
    AddToCart(params)
      .then(result => {
        console.log('addToCart Result', result);
        getCartItems(cartItems.id);
      })
      .catch(err => {
        showMessage({
          message: err,
          color: 'white',
          duration: 5000,
          animated: true,
          backgroundColor: 'red',
        });
        console.log('error', err);
      });
  };
  const onPlusIconclicked = (item: any) => {
    // setPlusButtonLoader(true)
    // setUpdateQuantity(updateQuantity + 1)
    addToCart(cartItems?.id, item?.materialCode, 1);
    // getCartItems(cartItems.id)
  };
  const onMinusIconclicked = (item: any) => {
    // setMinusButtonLoader(true)
    // setUpdateQuantity(updateQuantity + 1)
    if (item?.quantity > 1) {
      addToCart(cartItems?.id, item?.materialCode, -1);
    }
    // getCartItems(cartItems.id)
  };
  const onDeleteProductIconClicked = (item: any) => {
    setMinusButtonLoader(true);
    DeleteCartItem(item.materialCode);
  };
  const renderedItem = (item: any) => {
    return (
      <View style={styles.productCard}>
        <View>
          <Text style={styles.productId}>{item?.materialCode}</Text>
          <Text style={styles.productDescription} numberOfLines={1}>
            {item?.distributorInventoryItem?.materialItem?.description}
          </Text>
          <Text style={styles.productRate}>
            {t('rate')} :
            {/* <Text style={styles.productRateValue}>&#8377;{item?.distributorInventoryItem?.materialItem?.materialRDP?.rdp}</Text> */}
            <Text style={styles.productRateValue}>
              &#8377;{item?.totalPrice}
            </Text>
          </Text>
        </View>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'flex-end',
            alignItems: 'center',
            flex: 1,
          }}>
          {item?.quantity > 1 ? (
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() =>
                item?.quantity <= 1 ? {} : onMinusIconclicked(item)
              }>
              <View style={styles.plusMinusIconArea}>
                {/* {
                                        minusButtonLoader ?
                                            <ActivityIndicator size='small' color={config.fontAttribute.themeColor} />
                                            : */}
                <Image source={config.Images.minus} />
                {/* } */}
              </View>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() =>
                minusButtonLoader ? {} : onDeleteProductIconClicked(item)
              }>
              <View style={styles.plusMinusIconArea}>
                {/* {
                                        minusButtonLoader ?
                                            <ActivityIndicator size='small' color={config.fontAttribute.themeColor} />
                                            : */}
                <SvgXml xml={config.svgs.deleteBlue} height={15} width={15} />
                {/* } */}
              </View>
            </TouchableOpacity>
          )}
          <View style={styles.productQuantityArea}>
            <Text
              style={{
                color: config.fontAttribute.TextColor2,
                fontWeight: '500',
                fontSize: config.fontAttribute.labelFontSizeLarge,
              }}>
              {item?.quantity}
            </Text>
          </View>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => (plusButtonLoader ? {} : onPlusIconclicked(item))}>
            <View style={styles.plusMinusIconArea}>
              {/* {
                                plusButtonLoader ?
                                    <ActivityIndicator size='small' color={config.fontAttribute.themeColor} />
                                    : */}
              <Image source={config.Images.plus} />
              {/* } */}
            </View>
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  const skaletonData = [{}, {}, {}, {}, {}, {}, {}];
  const skeletonRenderItem = () => {
    return (
      <Skeleton>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginVertical: 10,
            backgroundColor: '#fff',
            borderRadius: 4,
          }}>
          <View>
            <View style={{width: 150, height: 10, marginVertical: 3}}></View>
            <View style={{width: 180, height: 10, marginVertical: 3}}></View>
            <View style={{width: 60, height: 10, marginVertical: 3}}></View>
          </View>
          <View style={{flexDirection: 'row'}}>
            <View style={styles.plusMinusIconArea}></View>
            <View style={styles.plusMinusIconArea}></View>
            <View style={styles.plusMinusIconArea}></View>
          </View>
        </View>
      </Skeleton>
    );
  };
  const isLoading = true;

  const NoData = () => {
    return (
      <View style={styles.noCartMessage}>
        <Image
          source={config.Images.emptyCart}
          resizeMode="contain"
          style={{width: 100, height: 100}}
        />
        <Text style={styles.noCartMessageText}>{t('yourCartisempty')}</Text>
      </View>
    );
  };
  return (
    <>
      <Headercomponent type={'2'} name={t('myCart')} />
      <View style={styles.container}>
        <View style={{flex: 1}}>
          <View style={styles.greetings}>
            {isProductLoader ? (
              <View style={{flexDirection: 'row'}}>
                <Text style={styles.hi}>Hi,</Text>
                <Skeleton>
                  <Text
                    style={{
                      width: 150,
                      height: 15,
                      marginTop: 10,
                      marginLeft: 5,
                    }}></Text>
                </Skeleton>
              </View>
            ) : (
              <Text style={styles.hi}>
                Hi,
                <Text style={styles.distributorName}>
                  {capitalize(cartItems?.retailer?.retailerName)}
                </Text>
              </Text>
            )}

            <Text style={styles.productMessage}>
              You have added{' '}
              <Text style={{fontWeight: '700'}}>
                {cartItems?.items?.length ? cartItems?.items?.length : 0}{' '}
                Product(s)
              </Text>
            </Text>
          </View>

          <View style={styles.lineBreak}></View>

          <Text style={styles.productDetailsHeading}>
            {t('productDetails')}
          </Text>

          {isProductLoader ? (
            <FlatList
              showsVerticalScrollIndicator={false}
              data={skaletonData}
              onEndReachedThreshold={0.7}
              renderItem={({item}) => skeletonRenderItem()}
            />
          ) : (
            <FlatList
              // style={{flex:1,backgroundColor:'blue}}
              showsVerticalScrollIndicator={false}
              data={cartItems?.items}
              onEndReachedThreshold={0.7}
              ListEmptyComponent={NoData}
              renderItem={({item}) => renderedItem(item)}
            />
          )}
        </View>
        <View style={styles.nextButtonSection}>
          <View>
            <Text style={styles.productMessage}>
              You have added{' '}
              <Text
                style={{
                  marginLeft: 5,
                  fontWeight: '700',
                  color: config.fontAttribute.themeColor,
                }}>
                {cartItems?.items?.length ? cartItems?.items?.length : 0}{' '}
                Product(s)
              </Text>
            </Text>
            {isProductLoader ? (
              <View style={{flexDirection: 'row'}}>
                <Text style={styles.noOfItems}>Rs. </Text>
                <Skeleton>
                  <Text
                    style={{width: 50, height: 10, marginVertical: 5}}></Text>
                </Skeleton>
              </View>
            ) : (
              <Text style={styles.noOfItems}>
                Rs. {fixToTwoDecimal(cartItems?.cartTotal)}
              </Text>
            )}
          </View>
          <TouchableOpacity
            activeOpacity={0.8}
            style={[
              config.AppStyle.AppStyle.button,
              {
                width: '30%',
                marginTop: 0,
                opacity: cartItems?.items == null ? 0.5 : 1,
              },
            ]}
            onPress={() => {
              cartItems?.items == null ? {} : onNextButtonClicked();
            }}>
            <Text style={config.AppStyle.AppStyle.buttonText}>{t('next')}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

export default OrderMyCart;
