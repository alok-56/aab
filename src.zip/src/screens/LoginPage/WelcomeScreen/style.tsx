import { pixelValue } from "../../../config/GlobalVariable";
import {StyleSheet} from 'react-native'
import * as fontConfig from "../../../config/fontConfig";
import * as config from '../../../config/index'


const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:fontConfig.themeColor
    },
    welcomeArea:{
        flex:1,
        margin:30
    },
    loginArea:{
        backgroundColor:fontConfig.whiteColor,
        height:'45%',
        borderTopLeftRadius:35,
        borderTopRightRadius:35,
        padding:30,
    },
   
    welcomeMessage:{
        flex:2,
        maxWidth:'80%'
    },
        welcome:{
        color:'#ffffff',
        fontWeight:'700',
        fontSize:config.fontAttribute.headingFontSize * pixelValue,
        lineHeight:30
    },
    welcomeText:{
        marginTop:5,
        color:'#fff',
        fontWeight:'400',
        fontSize:config.fontAttribute.labelFontSizeLarge * pixelValue, 
        lineHeight:25
    },
    registerMessage:{
        textAlign:'center',
        marginTop:40,
        color:'#979797'
    },
    register:{
        color:'#1D93D1'
    },
    absoluteIcon:{
        position:'absolute',
        bottom:27,
        right:15,
        
    }
})
export default styles;