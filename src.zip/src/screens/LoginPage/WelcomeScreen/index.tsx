import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  ActivityIndicator,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import { showMessage } from 'react-native-flash-message';
import { SvgXml } from 'react-native-svg';
import { SendOTP } from '../../../ApiServices/httpServices';
import TextInputWithError from '../../../Components/TextInputWithError';
import * as config from '../../../config';
import { NavMenu } from '../../../config/GlobalVariable';
import styles from './style';

let hashCode = '';
const WelcomeScreen = (props: any) => {
  const { navigation } = props;
  const { t, i18n } = useTranslation();
  const [usernameMobile, setUsernameMobile]: any = useState(null);
  const [isMaxCharError, setIsMaxCharError] = useState(false);
  const [isNullError, setIsNullError] = useState(false);
  const [isErrorVisible, setIsErrorVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  let NullErrorMessage = t('emptyUsernameMessage');
  let MaxCharErrorMessage = 'Field must can not exceeds 10 char.';

  const onContinueButtonClicked = () => {
    setIsLoading(true);
    const reg = /^(\+\d{1,3}[- ]?)?\d{10}$/;
    if (usernameMobile == '' || usernameMobile == null) {
      setIsLoading(false);
      setIsErrorVisible(true);
      setIsNullError(true);
    } else if (usernameMobile?.length > 10) {
      setIsLoading(false);
    } else {
      if (reg.test(usernameMobile) === false) {
        setIsLoading(false);
        navigation.navigate(NavMenu.login.loginWithPassword, {
          userName: usernameMobile,
        });
      } else {
        SendOtp();
      }
    }
  };

  // Call Api for Send OTP
  const SendOtp = () => {
    const params = {
      MobileNo: usernameMobile,
      hash_code: hashCode,
    };
    SendOTP(params)
      .then((result: any) => {
        setIsLoading(false);
        if (result?.setFlag) {
          navigation.navigate(NavMenu.login.loginWithOTP, {
            mobileNumber: usernameMobile,
          });
        } else {
          showMessage({
            message: 'Please try again !',
            color: 'white',
            backgroundColor: 'red',
            duration: 1000,
          });
        }
      })
      .catch((err: any) => {
        showMessage({
          message: 'Invalid Mobile Number !',
          color: 'white',
          backgroundColor: 'red',
          duration: 1000,
        });
        setIsLoading(false);
      });
  };

  const onMobileUsernameTextChanged = (e: any) => {
    if (e.length <= 10) {
      setIsErrorVisible(false);
      setIsMaxCharError(false);
    } else {
      setIsErrorVisible(true);
      setIsMaxCharError(true);
    }
    setUsernameMobile(e);
  };

  return (
    <>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS == 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={65}
      >
        <TouchableWithoutFeedback
          onPress={() => {
            Keyboard.dismiss();
          }}
        >
          <View style={styles.container}>
            <View style={styles.welcomeArea}>
              <View>
                <SvgXml
                  xml={config.svgs.FinolexLogo}
                  height={130}
                  width={100}
                />
              </View>
              <View style={styles.welcomeMessage}>
                <Text style={styles.welcome}>{t('welcome')}</Text>
                <Text style={styles.welcomeText}>{t('welcomeMessage')}</Text>
              </View>
            </View>

            <View style={styles.loginArea}>
              <Text style={config.AppStyle.AppStyle.inputLabel}>
                {t('mobileUsername')}
              </Text>

              <TextInputWithError
                onChangeText={(e: any) => onMobileUsernameTextChanged(e)}
                isErrorMessageVisible={isErrorVisible}
                keyboardType={'numeric'}
                errorMessage={
                  isMaxCharError
                    ? MaxCharErrorMessage
                    : isNullError
                    ? NullErrorMessage
                    : ''
                }
              />

              <TouchableOpacity
                onPress={onContinueButtonClicked}
                activeOpacity={0.8}
                style={[config.AppStyle.AppStyle.button]}
              >
                {isLoading ? (
                  <ActivityIndicator color={'white'} size="small" />
                ) : (
                  <Text style={config.AppStyle.AppStyle.buttonText}>
                    {t('continue')}
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </>
  );
};

export default WelcomeScreen;
