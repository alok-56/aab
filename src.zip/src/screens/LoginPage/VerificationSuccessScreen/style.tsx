import { StyleSheet } from "react-native";
import { pixelValue } from "../../../config/GlobalVariable";
import { whiteColor } from "../../../config/fontConfig";

const styles  = StyleSheet.create({
    container:{
        justifyContent:'center',
        alignItems:'center'
    },
    verification:{
        justifyContent:'center',
        alignItems:'center'
    },
    verificationText:{
        fontWeight:'700',
        lineHeight:25,
        fontSize:18 * pixelValue,
        color:whiteColor,
        margin:20

    }
})
export default styles