import { View, Text, Image, StyleSheet } from 'react-native'
import React from 'react'
import * as config from '../../../config';
import styles from './style'
import { useTranslation } from 'react-i18next'

const VerificationSuccess = () => {
    const {t, i18n} = useTranslation();

  return (
    <View style={[config.AppStyle.AppStyle.container,styles.container]}>
      <View style={styles.verification}>
        <Image style={{height:86, width:86}} source={config.Images.verificationSuccess}/>
        <Text style={styles.verificationText}>{t('verificationSuccess')}</Text>
      </View>
    </View>
  )
}

export default VerificationSuccess

