import { StyleSheet } from "react-native";
import { pixelValue } from "../../../config/GlobalVariable";
import { whiteColor } from "../../../config/fontConfig";
import * as config from '../../../config'

const styles = StyleSheet.create({
  InformationArea: {
    margin: 30,
    flex: 1
  },
  borderStyleBase: {
    width: 30,
    height: 45
  },

  borderStyleHighLighted: {
    borderColor: config.fontAttribute.borderLightedColor,
  },

  underlineStyleBase: {
    width: 40,
    height: 45,
    borderWidth: 0,
    borderBottomWidth: 2,
    borderColor: config.fontAttribute.whiteColor
  },

  underlineStyleHighLighted: {
    borderColor: config.fontAttribute.borderLightedColor,
  },
  companyName: {
    fontWeight: '400',
    fontSize: config.fontAttribute.labelFontSizeSmall * pixelValue,
    color: config.fontAttribute.whiteColor,
    marginTop: 25
  },
  phoneVerification: {
    fontWeight: '700',
    fontSize: config.fontAttribute.headingFontSize * pixelValue,
    color: config.fontAttribute.whiteColor,
    marginTop: 25
  },
  mobileNoLine: {
    fontWeight: '400',
    fontSize:config.fontAttribute.labelFontSizeLarge * pixelValue,
    color: config.fontAttribute.whiteColor,
    maxWidth: '80%',
    marginTop: 25,
    lineHeight: 25,
    letterSpacing: 1

  },
  otherLoginOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 30,
    alignItems: 'center',
    marginLeft: 5
  },
  otherLoginOptionsText: {
    fontWeight: '600',
    fontSize:config.fontAttribute.labelFontSize * pixelValue,
    lineHeight: 20,
    color: config.fontAttribute.whiteColor
  }
});

export default styles;