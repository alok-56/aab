import {
  View,
  Text,
  Image,
  TouchableOpacity,
  TouchableWithoutFeedback,
  ImageBackground,
  Keyboard,
  Platform,
  ActivityIndicator,
  KeyboardAvoidingView,
} from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import * as config from '../../../config';
import { useTranslation } from 'react-i18next';
import styles from './style';
import {
  GetDsrProfileService,
  GetMenuList,
  GetUserProfileService,
  SaveDeviceDetails,
  SendOTP,
  VerifyOTP,
} from '../../../ApiServices/httpServices';
import { showMessage } from 'react-native-flash-message';
import {
  Distributor2,
  IuserPorfileDto,
} from '../../../AppModel/UserProfileModel';
import {
  setAccessToken,
  setDistributors,
  setLoginTime,
  setMenuList,
  setProfileDetail,
  setUserData,
} from '../../../redux/actions/authAction';
import { useDispatch } from 'react-redux';
import OTPTextView from 'react-native-otp-textinput';
import DeviceInfo from 'react-native-device-info';
import { baseUrl } from '../../../ApiServices/credential';
import {
  NavMenu,
  PUSH_Token,
  getLocation,
  requestLocationPermission,
} from '../../../config/GlobalVariable';
import { IDsrProfileDto } from '../../../AppModel/DsrProfileModal';
import { Role } from '../../../redux/datamodel/authDataModal';

// ─── Custom countdown hook (replaces react-native-countdown-component) ───────
// Avoids the AppState.removeEventListener crash from the unmaintained library.
const useCountdown = (initialSeconds: number, onFinish: () => void) => {
  const [remaining, setRemaining] = useState(initialSeconds);
  const onFinishRef = useRef(onFinish);
  onFinishRef.current = onFinish;

  useEffect(() => {
    setRemaining(initialSeconds); // reset when initialSeconds changes
  }, [initialSeconds]);

  useEffect(() => {
    if (remaining <= 0) {
      onFinishRef.current();
      return;
    }
    const timer = setTimeout(() => setRemaining(r => r - 1), 1000);
    return () => clearTimeout(timer);
  }, [remaining]);

  return remaining;
};

// ─────────────────────────────────────────────────────────────────────────────

let hashCode = '';

const OTPScreen = (props: any) => {
  const { route, navigation } = props;
  const [isLoading, setIsLoading] = useState(false);
  const [isResendTimer, setIsResendTimer] = useState(true);
  const [countdownKey, setCountdownKey] = useState(0); // increment to restart countdown

  const { t } = useTranslation();

  const [autoFillOTP, setAutofillOTP] = useState<string>('');

  // Countdown: 30 seconds. Restarts whenever countdownKey changes.
  const remaining = useCountdown(isResendTimer ? 30 : 0, () => {
    setIsResendTimer(false);
  });

  const resendCodeClicked = () => {
    resendOTP();
  };

  const resendOTP = () => {
    // Restart the countdown
    setIsResendTimer(true);
    setCountdownKey(k => k + 1);

    const params = {
      MobileNo: route?.params?.mobileNumber,
      hash_code: hashCode,
    };

    SendOTP(params)
      .then((result: any) => {
        console.log('otp send', result);
        setIsLoading(false);
        if (result?.setFlag) {
          navigation.navigate(NavMenu.login.loginWithOTP, {
            mobileNumber: route?.params?.mobileNumber,
          });
        } else {
          showMessage({
            message: 'Please try again !',
            color: 'white',
            backgroundColor: 'red',
            duration: 2000,
          });
        }
      })
      .catch((err: any) => {
        console.log('error', err);
        setIsLoading(false);
      });
  };

  const backArrowClicked = () => {
    navigation.goBack();
  };

  const VerifyOtp = () => {
    setIsLoading(true);

    if (!autoFillOTP || autoFillOTP.length < 4) {
      showMessage({
        message: 'Please Enter OTP',
        color: 'white',
        backgroundColor: 'red',
        duration: 2000,
      });
      setIsLoading(false);
      return;
    }
    VerifyOtpApiCalling();
  };

  // Verify OTP Api Calling
  const VerifyOtpApiCalling = async () => {
    const currentLocation = await getLocation();

    const params = {
      MobileNo: route?.params?.mobileNumber,
      OtpNumber: autoFillOTP,
      Location: currentLocation?.address ?? '',
      Longitude: currentLocation?.longitude
        ? String(currentLocation.longitude)
        : '',
      Latitude: currentLocation?.latitude
        ? String(currentLocation.latitude)
        : '',
    };

    VerifyOTP(params)
      .then(result => {
        if (result?.setFlag) {
          if (result?.status === 'Active') {
            dispatch(setUserData(result.data));
            const currentDateTime = new Date();
            dispatch(setLoginTime(currentDateTime.toISOString()));
            dispatch(setAccessToken(result?.data?.jwtToken ?? ''));
            getMenuListData(result);
            console.log('User Role', result);
            if (result?.data?.role?.id === 4)
              getDsrProfile(result?.data.dsrId, result?.data?.role);
            if (result?.data?.role?.id == 3 || result?.data?.role?.id == 14)
              console.log('Retailer Code', result?.data);
              getRetailerProfile(
                result?.data?.retailerCode || result?.data?.userName,
                result?.data?.role,
              );
            saveDeviceDetails(result?.data?.userName);
            navigation.reset({
              index: 0,
              routes: [{ name: 'Home' }],
            });
          } else {
            showMessage({
              message: 'User is Locked or Inactive',
              color: 'white',
              duration: 3000,
              animated: true,
              backgroundColor: 'red',
            });
            setIsLoading(false);
          }
        } else {
          showMessage({
            message: result?.message,
            color: 'white',
            backgroundColor: 'red',
            duration: 2000,
          });
          setIsLoading(false);
        }
      })
      .catch((err: any) => {
        setIsLoading(false);
        showMessage({
          message: err?.response?.data?.message ?? 'Something went wrong',
          color: 'white',
          backgroundColor: 'red',
          duration: 3000,
        });
      });
  };

  const getMenuListData = (res: any) => {
    GetMenuList(res?.data?.roleId)
      .then(result => {
        dispatch(setMenuList(result));
      })
      .catch((err: any) => {
        console.log('Menu List Error', err);
      });
  };

  const getRetailerProfile = (userId: number, role: Role) => {
    GetUserProfileService(userId)
      .then((result: IuserPorfileDto) => {
        result.profile = {
          profileId: result?.retailerCode,
          profileName: result?.retailerName,
          profileRole: role,
        };
        dispatch(setProfileDetail(result));

        let DistributorArray: Array<Distributor2> = [];
        result?.distributors.map(item => {
          DistributorArray.push(item?.distributor);
        });
        dispatch(setDistributors(DistributorArray));
        setIsLoading(false);
      })
      .catch(() => {
        setIsLoading(false);
      });
  };

  const getDsrProfile = (userId: number, role: Role) => {
    GetDsrProfileService(userId)
      .then((result: IDsrProfileDto) => {
        result.profile = {
          profileId: result?.dsrCode,
          profileName: result?.dsrName,
          profileRole: role,
        };
        dispatch(setProfileDetail(result));

        let DistributorArray: Array<Distributor2> = [];
        DistributorArray.push(result?.distributor);
        dispatch(setDistributors(DistributorArray));
        setIsLoading(false);
      })
      .catch((err: any) => {
        setIsLoading(false);
        console.error('error:', err);
      });
  };

  const dispatch = useDispatch();

  // Save Device Details Api Call
  const saveDeviceDetails = async (userId: number) => {
    const deviceName = await DeviceInfo.getDeviceName();
    const params = {
      UserId: userId,
      UUID: PUSH_Token ?? '1234567890',
      DeviceName: deviceName,
      DeviceVersion: Platform.Version,
      DeviceOS: Platform.OS,
      CallPoint: baseUrl,
      DeviceModel: deviceName,
      AppVesion: DeviceInfo.getVersion(),
      BuildNumber: DeviceInfo.getBuildNumber(),
    };

    SaveDeviceDetails(params)
      .then(result => {
        setIsLoading(false);
        console.log('save device details', result);
      })
      .catch((err: any) => {
        setIsLoading(false);
        console.log('error', err);
      });
  };

  const OnOTPChanged = (otp: string) => {
    if (otp.length === 4) {
      Keyboard.dismiss();
    }
    setAutofillOTP(otp);
  };

  // Format remaining seconds as MM:SS
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60)
      .toString()
      .padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={65}
    >
      <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
        <ImageBackground
          resizeMode="cover"
          style={config.AppStyle.AppStyle.flex1}
          source={config.Images.loginBackground}
        >
          <View style={config.AppStyle.AppStyle.flex1}>
            {/* ── Header / OTP input area ── */}
            <View style={styles.InformationArea}>
              <TouchableOpacity
                style={{ padding: 10 }}
                activeOpacity={1}
                onPress={backArrowClicked}
              >
                <Image source={config.Images.backArrowWhite} />
              </TouchableOpacity>

              <Text style={styles.phoneVerification}>
                {t('phoneVerification')}
              </Text>
              <Text style={styles.mobileNoLine}>
                {t('sentVerificationCodeTo')}
                <Text>{route?.params?.mobileNumber}</Text>
              </Text>

              <OTPTextView
                autoFocus={true}
                inputCount={4}
                defaultValue={autoFillOTP}
                keyboardType="numeric"
                offTintColor={'white'}
                tintColor={'white'}
                containerStyle={{
                  marginTop: 10,
                  marginBottom: 30,
                  justifyContent: 'center',
                }}
                textInputStyle={{
                  color: 'white',
                  borderBottomWidth: 1,
                  width: 30,
                  marginTop: 50,
                  fontSize: 17,
                  marginHorizontal: 20,
                }}
                handleTextChange={(code: string) => OnOTPChanged(code)}
              />
            </View>

            {/* ── Resend + Submit area ── */}
            <View style={{ margin: 30 }}>
              <View style={styles.otherLoginOptions}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  {/* Resend button — disabled while timer is running */}
                  <TouchableOpacity
                    disabled={isResendTimer}
                    activeOpacity={0.9}
                    onPress={resendCodeClicked}
                  >
                    <Text
                      style={[
                        styles.otherLoginOptionsText,
                        isResendTimer && { opacity: 0.5 },
                      ]}
                    >
                      {t('resendCode')}
                    </Text>
                  </TouchableOpacity>

                  {/* Inline countdown — no third-party library */}
                  {isResendTimer && (
                    <Text
                      style={[
                        styles.otherLoginOptionsText,
                        { marginHorizontal: 5, color: 'white', fontSize: 13 },
                      ]}
                    >
                      {' '}
                      in {formatTime(remaining)}
                    </Text>
                  )}
                </View>
              </View>

              {/* Submit OTP button */}
              <TouchableOpacity
                activeOpacity={0.8}
                style={[
                  config.AppStyle.AppStyle.button,
                  {
                    backgroundColor: config.fontAttribute.whiteColor,
                    marginTop: 20,
                  },
                ]}
                onPress={async () => {
                  Keyboard.dismiss();
                  const isPermissionGranted = await requestLocationPermission();
                  console.log('permission', isPermissionGranted);
                  if (isPermissionGranted) {
                    VerifyOtp();
                  }
                }}
              >
                {isLoading ? (
                  <ActivityIndicator
                    color={config.fontAttribute.themeColor}
                    size="small"
                  />
                ) : (
                  <Text
                    style={[
                      config.AppStyle.AppStyle.buttonText,
                      { color: config.fontAttribute.themeColor },
                    ]}
                  >
                    {t('submitOTP')}
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </ImageBackground>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

export default OTPScreen;
