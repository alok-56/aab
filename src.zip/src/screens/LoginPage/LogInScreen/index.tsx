import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Image,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard,
  ImageBackground,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import React, { useEffect, useRef, useState } from 'react';
import * as config from '../../../config';
import { useTranslation } from 'react-i18next';

import styles from './style';
import {
  GetDsrProfileService,
  GetMenuList,
  GetUserProfileService,
  SaveDeviceDetails,
  userAuthenticate,
} from '../../../ApiServices/httpServices';
import { IuserDetail, Role } from '../../../redux/datamodel/authDataModal';
import { useDispatch } from 'react-redux';
import {
  setAccessToken,
  setDistributors,
  setLoginTime,
  setMenuList,
  setProfileDetail,
  setUserData,
} from '../../../redux/actions/authAction';
import { showMessage } from 'react-native-flash-message';
import {
  Distributor2,
  IuserPorfileDto,
} from '../../../AppModel/UserProfileModel';
import TextInputWithError from '../../../Components/TextInputWithError';
import {
  NavMenu,
  PUSH_Token,
  getLocation,
  requestLocationPermission,
} from '../../../config/GlobalVariable';
import { baseUrl } from '../../../ApiServices/credential';
import DeviceInfo from 'react-native-device-info';
import { IDsrProfileDto } from '../../../AppModel/DsrProfileModal';

const LoginScreen = (props: any) => {
  const { route, navigation } = props;

  const { t, i18n } = useTranslation();

  const [isUsernameError, setIsUsernameError] = useState(false);
  const [userNameErrorMessage, setUserNameErrorMessage] = useState(false);

  const dispatch = useDispatch();
  const [password, setPassword] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const onPasswordTextChanged = (e: any) => {
    setPassword(e);
  };

  const onLogInButtonClicked = async () => {
    if (password == '' || password == null) {
      setIsUsernameError(true);
      setUserNameErrorMessage(true);
    } else {
      setUserNameErrorMessage(false);
      setIsUsernameError(false);
      setIsLoading(true);
      const currentLocation = await getLocation();
      const params = {
        userName: route?.params?.userName,
        password: password,
        isApp: true,
        Location: currentLocation?.address ? currentLocation?.address : '',
        Longitude: currentLocation?.longitude
          ? String(currentLocation?.longitude)
          : '',
        Latitude: currentLocation?.latitude
          ? String(currentLocation?.latitude)
          : '',
      };

      userAuthenticate(params)
        .then((res: IuserDetail) => {
          console.log('User Login Response Data:', JSON.stringify(res, null, 2));
          if (res?.status == 'Active') {
            dispatch(setUserData(res));
            const currentDateTime = new Date();
            dispatch(setLoginTime(currentDateTime.toISOString()));
            dispatch(setAccessToken(res.jwtToken ? res.jwtToken : ''));
            setIsLoading(false);
            getMenuList(res);
            if (res?.role?.id == 4) 
              getDsrProfile(res?.dsrId, res?.role);
            if (res?.role?.id == 3 || res?.role?.id == 14)
              getRetailerProfile(res?.retailerCode || res?.userName, res?.role);
              saveDeviceDetails(res?.userName);

            navigation.reset({
              index: 0,
              routes: [{ name: 'Home' }],
            });
          } else {
            showMessage({
              message: 'User is Locked or Inactive',
              color: 'white',
              duration: 3000,
              animated: true,
              backgroundColor: 'red',
            });

            setIsLoading(false);
          }
        })
        .catch((err: any) => {
          setIsLoading(false);

          if (err?.response?.data?.message)
            showMessage({
              message: err?.response?.data?.message,
              color: 'white',
              duration: 3000,
              animated: true,
              backgroundColor: 'red',
            });
          else showMessage({ message: 'Something went wrong' });
        });
    }
  };

  const getMenuList = (res: any) => {
    GetMenuList(res?.role?.id)
      .then(result => {
        console.log('Menu List Data:', result);
        dispatch(setMenuList(result));
      })
      .catch((err: any) => {
        console.log('Menu List Error', err);
      });
  };

  const getRetailerProfile = (userId: number, role: Role) => {
    console.log("User Id",userId + "Role id:",role)
    GetUserProfileService(userId)
      .then((result: IuserPorfileDto) => {
        console.log('Retailer Profile Data:', result);
        result.profile = {
          profileId: result?.retailerCode,
          profileName: result?.retailerName,
          profileRole: role,
        };

        dispatch(setProfileDetail(result));
        let DistributorArray: Array<Distributor2> = new Array<Distributor2>();
        result?.distributors.map(item => {
          DistributorArray.push(item?.distributor);
        });
        dispatch(setDistributors(DistributorArray));
        setIsLoading(false);
      })
      .catch((err: any) => {
        setIsLoading(false);
        console.error('error:', err);
      });
  };

  const getDsrProfile = (userId: number, role: Role) => {
    GetDsrProfileService(userId)
      .then((result: IDsrProfileDto) => {
        console.log('DSR Profile Data:', result);
        result.profile = {
          profileId: result?.dsrCode,
          profileName: result?.dsrName,
          profileRole: role,
        };
        dispatch(setProfileDetail(result));

        let DistributorArray: Array<Distributor2> = new Array<Distributor2>();
        DistributorArray.push(result?.distributor);
        dispatch(setDistributors(DistributorArray));
        setIsLoading(false);
      })
      .catch((err: any) => {
        setIsLoading(false);
        console.error('dsr profile error:', err);
      });
  };

  const saveDeviceDetails = async (userId: number) => {
    const params = {
      UserId: userId,
      UUID: PUSH_Token,
      DeviceName: await DeviceInfo.getDeviceName().then(result => {
        return result;
      }),
      DeviceVersion: Platform.Version,
      DeviceOS: Platform.OS,
      CallPoint: baseUrl,
      DeviceModel: await DeviceInfo.getDeviceName().then(result => {
        return result;
      }),
      AppVesion: DeviceInfo.getVersion(),
      BuildNumber: DeviceInfo.getBuildNumber(),
    };

    SaveDeviceDetails(params)
      .then(result => {
        setIsLoading(false);
        console.log('save device details', result);
      })
      .catch((err: any) => {
        setIsLoading(false);
        console.log('error', err);
      });
  };

  const onForgotPasswordClicked = () => {
    navigation.navigate(NavMenu.forgotPassword);
  };

  const backArrowClicked = () => {
    navigation.goBack();
  };

  const onErrorIconClicked = () => { };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS == 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={65}
    >
      <TouchableWithoutFeedback
        onPress={() => {
          Keyboard.dismiss();
        }}
      >
        <ImageBackground
          resizeMode="cover"
          style={config.AppStyle.AppStyle.flex1}
          source={config.Images.loginBackground}
        >
          <View style={config.AppStyle.AppStyle.flex1}>
            <TouchableOpacity activeOpacity={0.8} onPress={backArrowClicked}>
              <View style={styles.backButtonArea}>
                <Image source={config.Images.backArrowWhite} />
              </View>
            </TouchableOpacity>
            <View style={styles.loginMessageArea}>
              <Text style={styles.login}>{t('login')}</Text>
              <Text style={styles.loginText}>{t('loginMessage')}</Text>
            </View>
            <View style={styles.loginArea}>
              <Text style={config.AppStyle.AppStyle.inputLabel}>
                {t('username')}
              </Text>
              <TextInput
                placeholderTextColor={config.fontAttribute.placeholderColor}
                selectionColor={config.fontAttribute.cursorColor}
                editable={false}
                style={[
                  config.AppStyle.AppStyle.inputField,
                  config.AppStyle.AppStyle.disabledInputField,
                ]}
                value={route?.params?.userName}
              />

              <Text style={config.AppStyle.AppStyle.inputLabel}>
                {t('password')}
              </Text>
              {/* <TextInput onChangeText={e => onPasswordTextChanged(e)} secureTextEntry={true} value={password ? password : ''} style={config.AppStyle.AppStyle.inputField} /> */}

              <TextInputWithError
                onChangeText={(e: any) => onPasswordTextChanged(e)}
                secureTextEntry={true}
                isErrorMessageVisible={userNameErrorMessage}
                onErrorIconclicked={onErrorIconClicked}
                isErrorIconVisible={isUsernameError}
                errorMessage={t('emptyPasswordMessage')}
              // inputValue={password}
              />
              <TouchableOpacity
                onPress={onForgotPasswordClicked}
                activeOpacity={0.8}
              >
                <Text style={styles.loginWithOTP}>{t('forgotPassword')}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={async () => {
                  Keyboard.dismiss();
                  console.warn('before pwemission');
                  const isPermissionGranted = await requestLocationPermission();
                  console.warn('permission', isPermissionGranted);
                  //   if (isPermissionGranted) {
                  //     onLogInButtonClicked();
                  //   } else {
                  //     console.warn('Location permission not granted');
                  //   }

                  if (true) {
                    onLogInButtonClicked();
                  } else {
                    console.warn('Location permission not granted');
                  }

                }}
                activeOpacity={0.8}
                style={[config.AppStyle.AppStyle.button, { marginTop: 20 }]}
              >
                <Text style={config.AppStyle.AppStyle.buttonText}>
                  {!isLoading ? (
                    t('login')
                  ) : (
                    <ActivityIndicator size="small" color="#ffffff" />
                  )}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ImageBackground>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

export default LoginScreen;
