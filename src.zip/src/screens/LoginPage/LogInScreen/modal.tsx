import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Image,
} from 'react-native';
import React, { useState } from 'react';
import * as Icons from '../../../config/images';
import * as config from '../../../config/index';
import { pixelValue } from '../../../config/GlobalVariable';
const ModalPage = (props: any) => {
  const { isOpen, onClose, CompanyList, onMenuChange, selectedId } = props;

  const CompanyNameClicked = (item: any) => {
    onMenuChange(item);
    onClose();
  };

  return (
    <View>
      <Modal
        transparent={true}
        visible={isOpen}
        onRequestClose={onClose}
        animationType="none"
      >
        <View style={styles.ModalView}>
          <View style={styles.crossIcon}>
            <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
              <Image source={Icons.cross} />
            </TouchableOpacity>
          </View>
          <View style={styles.innerModalView}>
            <FlatList
              style={{ marginTop: 20 }}
              data={CompanyList}
              renderItem={({ item }) => (
                <TouchableOpacity
                  onPress={() => CompanyNameClicked(item)}
                  style={[styles.companyName]}
                  activeOpacity={0.7}
                >
                  <Text
                    style={[
                      styles.companyNameText,
                      { color: item.id === selectedId ? '#0051AC' : '' },
                    ]}
                  >
                    {item.name}
                  </Text>
                  {item.id === selectedId ? (
                    <Image source={Icons.tick} />
                  ) : null}
                </TouchableOpacity>
              )}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default ModalPage;

const styles = StyleSheet.create({
  ModalView: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.8)',
  },
  innerModalView: {
    // minWidth: '100%',
    // backgroundColor: 'red',
    // shadowColor: 'black',
    // elevation: 5,
    // maxHeight:'70%'
    backgroundColor: '#fff',
    height: 'auto',
    width: '100%',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    padding: 5,
  },
  companyName: {
    backgroundColor: '#fff',
    height: 65,
    padding: 15,
    // borderColor :'#667085',
    // borderBottomWidth:0.7
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  companyNameText: {
    color: '#3D5E87',
    fontWeight: '400',
    fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
  },
  crossIcon: {
    alignItems: 'flex-end',
    marginBottom: 30,
    marginRight: 20,
  },
});
