import { View, Text, Modal, Image, StyleSheet, TextInput, Switch, FlatList } from 'react-native'
import React, { SetStateAction, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next';
import { TouchableOpacity } from 'react-native';
import * as config from '../../../config/index'
import { RadioButton } from 'react-native-paper';
// import RadioGroup from 'react-native-radio-buttons-group';

const FilterModal = (props: any) => {
    const { t, i18n } = useTranslation();

    const { isOpen, onClose, onfilterValueSelected, filterValues, selectedFilter } = props;

    useEffect(() => {
        // setValue(filterValues[2])
    }, [])
    const [value, setValue] = React.useState<any>(selectedFilter?.filterName);

    // const [isEnabled, setIsEnabled] = useState(false);

    const toggleSwitch = (item: any) => {
        onfilterValueSelected(item)
        setValue(item?.filterName)
        onClose()
    }
    const renderItem = (item: any) => {
        return (
            <TouchableOpacity
                onPress={() => toggleSwitch(item)}
                activeOpacity={1}>
                <View
                    style={{
                        flexDirection: 'row',
                        // backgroundColor:'red',
                        // marginVertical: 10,
                        // marginTop:20,
                        paddingVertical: 10,
                        marginHorizontal: 10,
                        alignItems: 'center',
                        borderBottomColor: 'gray',
                        borderBottomWidth: 0.5
                        // justifyContent: 'center'
                    }}>
                    {/* <Switch
                        trackColor={{ false: '#EAECF0', true: '#1D93D1' }}
                        thumbColor={'#fff'}
                        ios_backgroundColor="#3e3e3e"
                        onValueChange={() => toggleSwitch(item)}
                        value={item.CategoryName == selectedCategory?.CategoryName ? true : false}
                    /> */}
                    <RadioButton value={item?.filterName} color={config.fontAttribute.themeColor} />
                    <Text style={{ marginLeft: 10, color: config.fontAttribute.TextColor1 }}>Last {item ? item?.filterName : ''}</Text>
                </View>
            </TouchableOpacity>
        )
    }
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                {/* <View>
                    <TouchableOpacity activeOpacity={1}> */}
                <View style={styles.ModalView}>
                    <View style={[styles.innerModalView]}>
                        <View style={styles.titleView}>
                            <Text style={{
                                color: '#fff',
                                fontWeight: '600',
                                fontSize: 15,
                                textAlign: 'center'
                            }}>{t('ledgerFilterTitle')}</Text>
                        </View>

                        <View style={{
                            paddingHorizontal: 10,
                            // alignItems: 'flex-start'
                        }}>
                            {/* {
                                filterValues != null ? <Text>No filter available</Text> : */}
                            <RadioButton.Group onValueChange={newValue => { onClose(); setValue(newValue) }} value={value}>
                                <FlatList
                                    data={filterValues}
                                    onEndReachedThreshold={.7}
                                    renderItem={({ item }) => renderItem(item)}
                                // keyExtractor={item => item?.id}
                                />
                            </RadioButton.Group>
                            {/* } */}
                        </View>
                        <TouchableOpacity activeOpacity={0.6} onPress={onClose}>
                            <View style={styles.cancelButtonView}>
                                <Text style={{ color: config.fontAttribute.TextColor1, fontWeight: '500' }}>{t('cancel')}</Text>
                            </View>
                        </TouchableOpacity>

                    </View>
                </View>
                {/* </TouchableOpacity></View> */}
            </Modal>
        </View>
    )
}

export default FilterModal

const styles = StyleSheet.create({
    ModalView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0,0,0,0.8)'
    },
    innerModalView: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '70%',
        borderRadius: 10
    },
    crossIcon: {
        alignItems: 'flex-end',
        marginBottom: 15,
        marginRight: 20,
        padding: 10
    },
    downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 30
    },
    titleView: {
        backgroundColor: config.fontAttribute.themeColor,
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        padding: 15,
        justifyContent: 'center',
        alignItems: 'center'
    },
    cancelButtonView: {
        padding: 15,
        justifyContent: 'center',
        alignItems: 'center',
        borderTopColor: 'gray',
        borderTopWidth: 0.5
    }
})