import { View, Text, StyleSheet } from 'react-native'
import React from 'react'
import { ChangeAmountFormat, ConvertDateFormat, pixelValue } from '../../../config/GlobalVariable'
import * as config from '../../../config/index'
import { useTranslation } from 'react-i18next'

export const Invoice = (props: any) => {
    const { t, i18n } = useTranslation();
    const { item } = props
    return (
        <>
            <View style={styles.ledgerItemCard}>
                <View style={styles.firstRow}>
                    <Text style={styles.debitText}>
                        {item?.documentType}   <Text style={[styles.secondRowText1]}>
                            {ConvertDateFormat(item?.invoiceReference ? item?.invoiceReference?.invoiceDate : item?.invoiceDate)}
                        </Text>
                    </Text>
                    <Text
                        style={styles.debitAmount}>
                        &#8377;{ChangeAmountFormat(item?.invoiceAmount)} <Text style={styles.DrText}>Dr</Text>
                    </Text>
                </View>
                <View style={styles.invoiceSecondRow}>
                    <View>
                        <View style={{ flex: 0.9, flexDirection: 'row' }}>
                            <Text style={styles.secondRowText1}>{t('invoiceNo')} </Text>
                            <Text style={styles.secondRowText1}>#{item?.invoiceNo}</Text>
                        </View>
                        {
                            item?.invoiceReference?.isCancelled ?
                                <Text style={[styles.secondRowText1, { color: 'red' }]}>{t('cancelled')}</Text>
                                : <></>
                        }

                    </View>
                    {/* <View style={{ flex: 0.9 }}>
                        <Text style={styles.secondRowText1}>{item?.ledgerId}</Text>
                    </View> */}
                    <View style={{ flex: 1.2, alignItems: 'flex-end' }}>
                        <Text style={styles.secondRowText2}>{t('closingBalance')} ({ChangeAmountFormat(item?.outstandingAmount)})</Text>
                    </View>
                </View>
            </View>
            <View style={styles.lineBreak}></View>
        </>

    )
}
export const PaymentReconcilation = (props: any) => {
    const { t, i18n } = useTranslation();
    const { item } = props
    return (
        <>
            <View style={styles.ledgerItemCard}>
                <View style={styles.firstRow}>
                    <Text style={styles.debitText}>
                        {item?.paymentType}   <Text style={[styles.secondRowText1]}>
                            {ConvertDateFormat(item?.paymentDetailsReference?.paymentDate)}
                        </Text>
                    </Text>
                    <Text
                        style={styles.creditAmount}>
                        &#8377;{ChangeAmountFormat(item?.paymentDetailsReference?.amount)} <Text style={styles.CrText}>Cr</Text>
                    </Text>
                </View>
                <View style={styles.paymentReconcilationSecondRow}>
                    <View style={{ flexDirection: 'column' }}>
                        <View style={{ flex: 0.9, flexDirection: 'row' }}>
                            <Text style={styles.secondRowText1}>{t('documentNo')} </Text>
                            <Text style={styles.secondRowText1}>{item?.paymentDetailsReference?.paymentReferenceNumber}</Text>
                        </View>
                        {
                            item?.invoiceNo ?
                                <View style={{ flex: 0.9, flexDirection: 'row' }}>
                                    <Text style={styles.secondRowText1}>{t('invoiceNo')} </Text>
                                    <Text style={styles.secondRowText1}>#{item?.invoiceNo}</Text>
                                </View> : <></>
                        }
                    </View>
                    <View style={{ flex: 1.2, alignItems: 'flex-end' }}>
                        <Text style={styles.secondRowText2}>{t('closingBalance')} ({ChangeAmountFormat(item?.outstandingAmount)})</Text>
                    </View>
                </View>
            </View>
            <View style={styles.lineBreak}></View>
        </>
    )
}

export const CreditNote = (props: any) => {
    const { t, i18n } = useTranslation();
    const { item } = props
    return (
        <>
            <View style={styles.ledgerItemCard}>
                <View style={styles.firstRow}>
                    <Text style={styles.debitText}>
                        {item?.documentType}   <Text style={[styles.secondRowText1]}>
                            {ConvertDateFormat(item?.creditNoteReference?.invoiceDate)}
                        </Text>
                    </Text>
                    <Text
                        style={styles.creditAmount}>
                        &#8377;{ChangeAmountFormat(item?.creditNoteReference?.invoiceAmount)}
                    </Text>
                </View>
                <View style={styles.creditNoteSecondRow}>
                    <View style={{ flexDirection: 'column' }}>
                        <View style={{ flex: 0.9, flexDirection: 'row' }}>
                            <Text style={styles.secondRowText1}>{t('documentNo')} </Text>
                            <Text style={styles.secondRowText1}>{item?.creditNoteDocumentNumber}</Text>
                        </View>
                        <View style={{ flex: 0.9, flexDirection: 'row' }}>
                            <Text style={styles.secondRowText1}>{t('invoiceNo')} </Text>
                            <Text style={styles.secondRowText1}>#{item?.invoiceNo}</Text>
                        </View>
                    </View>
                    {/* <View style={{ flex: 0.9 }}>
                        <Text style={styles.secondRowText1}>{item?.ledgerId}</Text>
                    </View> */}
                    <View style={{ flex: 1.2, alignItems: 'flex-end' }}>
                        <Text style={styles.secondRowText2}>{t('closingBalance')} ({ChangeAmountFormat(item?.outstandingAmount)})</Text>
                    </View>
                </View>
            </View>
            <View style={styles.lineBreak}></View>
        </>
    )
}

const styles = StyleSheet.create({
    ledgerItemCard: {
        padding: 8
    },
    lineBreak: {
        borderTopColor: '#D0D5DD',
        borderTopWidth: 1,
        marginHorizontal: 15
    },
    firstRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    invoiceSecondRow: {
        flexDirection: 'row',
        marginVertical: 7,
        marginHorizontal: 5
    },
    paymentReconcilationSecondRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 7,
        marginHorizontal: 5
    },
    creditNoteSecondRow: {
        flexDirection: 'row',
        marginVertical: 7,
        marginHorizontal: 5,
        alignItems:'center'
    },
    secondRowText1: {
        fontSize: config.fontAttribute.labelFontSizeSmall * pixelValue, 
        fontWeight: '600',
        color: config.fontAttribute.TextColor1,
    },
    secondRowText2: {
        fontSize: 9 * pixelValue,
        fontWeight: '400',
        color: config.fontAttribute.TextColor1,
    },
    creditText: {
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
        fontWeight: '600',
        color: config.fontAttribute.TextColor2,
    },
    debitText: {
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
        fontWeight: '600',
        color: config.fontAttribute.TextColor1,
    },
    creditAmount: {
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
        fontWeight: '600',
        color: '#7DCE13',
    },
    debitAmount: {
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
        fontWeight: '600',
        color: '#FF0000',
    },
    CrText: {
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue, 
        fontWeight: '600',
        color: '#7DCE13',
    },
    DrText: {
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600',
        color: '#FF0000',
    }
})

