import {useFocusEffect, useIsFocused} from '@react-navigation/native';
import React, {useState} from 'react';
import {useTranslation} from 'react-i18next';
import {
  ActivityIndicator,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {SvgXml} from 'react-native-svg';
import {shallowEqual, useSelector} from 'react-redux';
import {
  GetLedgerData,
  GetLedgerFilterValues,
} from '../../../ApiServices/httpServices';
import {Headercomponent} from '../../../Components';
import NoData from '../../../Components/No_Data_Component';
import Skeleton from '../../../Components/skeleton/skeleton';
import {
  ChangeAmountFormat,
  capitalize,
  pixelValue,
} from '../../../config/GlobalVariable';
import * as config from '../../../config/index';
import FilterModal from './filterModal';
import {CreditNote, Invoice, PaymentReconcilation} from './renderedItem';

// let selectedFilter: any ;
let selectedFilter: any = null;
let ledgerList: Array<any> = [];
let pageIndex = 1;
const Ledger = (props: any) => {
  const {t, i18n} = useTranslation();
  const isFocused = useIsFocused();
  useFocusEffect(
    React.useCallback(() => {
      if (isFocused) {
        setIsLazyLoader(false);
        setIsLoader(true);
        pageIndex = 1;
        getFilterList();
        ledgerList.length = 0;
      }
    }, [isFocused]),
  );

  const [isLoader, setIsLoader] = useState(false);
  const [isLazyLoader, setIsLazyLoader] = useState(false);
  const [filterValues, setFilterValues] = useState<any>([]);
  const [ledgerData, setLedgerData] = useState<any>([]);
  // const [ledgerList, setLedgerList] = useState<Array<any>>([]);
  // const [selectedFilter, setSelectedFilter] = useState<any>(null);
  const {route} = props;
  const [isFilterModal, setIsFilterModal] = useState(false);
  const toggleFilterModal = () => {
    setIsFilterModal(!isFilterModal);
  };
  const onFilterClicked = () => {
    toggleFilterModal();
  };
  const onfilterValueSelected = (item: any) => {
    // // console.log(item)
    // pageIndex = 1
    // ledgerList.length = 0
    // setLedgerList(ledgerList)
    // setSelectedFilter(item)
    // getLedgerData(item?.duration)
    // // selectedFilter = items
    setIsLoader(true);
    selectedFilter = item;
    pageIndex = 1;
    ledgerList.length = 0;
    // setLedgerList(ledgerList)
    getLedgerData(selectedFilter?.duration);
  };
  const profileDetail: any = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );
  const getFilterList = () => {
    GetLedgerFilterValues()
      .then((result: any) => {
        console.log('filter val', result);
        if (result) {
          setFilterValues(result?.data);
          // setSelectedFilter(result?.data?.[2])
          getLedgerData(result?.data[2]?.duration);
          // setSelectedFilter(result?.data[2])
          selectedFilter = result?.data[2];
        }
      })
      .catch((err: any) => {
        console.log('filter val', err);
      });
  };
  const getLedgerData = (duration: any) => {
    const distributor =
      profileDetail?.profile?.profileRole?.id == 4
        ? profileDetail?.distributor?.distributorCode
        : route?.params?.distributor?.distributor?.distributorCode;
    const retailer =
      profileDetail?.profile?.profileRole?.id == 4
        ? route?.params?.retailer?.retailerCode
        : profileDetail?.retailerCode;

    const params = {
      PageSize: 10,
      PageIndex: pageIndex,
      RetailerId: retailer,
      DistributorId: distributor,
      Duration: duration,
    };
    console.log('ledger params', params);
    GetLedgerData(params)
      .then((result: any) => {
        setLedgerData(result?.data);
        let itemList = [];
        itemList = ledgerList?.concat(
          result?.data?.distributorRetailerPayments,
        );
        // setLedgerList(itemList)
        ledgerList = itemList;
        console.log('result Data', result);
        console.log('display List', ledgerList);
        setIsLazyLoader(false);
        setIsLoader(false);
      })
      .catch((err: any) => {
        setIsLazyLoader(false);
        setIsLoader(false);
        console.log('ledger', err);
      });
  };
  const [isRefreshing, setIsRefreshing] = useState(false);

  const onEndReached = () => {
    setIsLazyLoader(true);
    console.log('end');
    pageIndex = pageIndex + 1;
    getLedgerData(selectedFilter?.duration);
  };
  const onListRefresh = () => {
    setIsLoader(true);
    pageIndex = 1;
    ledgerList.length = 0;
    // setLedgerList(ledgerList)
    getLedgerData(selectedFilter?.duration);
  };

  const renderedItem = (item: any) => {
    switch (item?.documentType) {
      case 'Credit Note':
        return <CreditNote item={item} />;
        break;
      case 'Payment Reconcillation':
        return <PaymentReconcilation item={item} />;
        break;
      case 'For Pending Outstanding':
        return <PaymentReconcilation item={item} />;
        break;
      case 'Invoice':
        return <Invoice item={item} />;
        break;
      default:
        return <View></View>;
        break;
    }
  };
  const skaletonData = [{}, {}, {}, {}, {}];
  const skeletonRenderItem = () => {
    return (
      <Skeleton>
        <View
          style={{flexDirection: 'column', justifyContent: 'space-between',  backgroundColor: '#fff',
            borderRadius: 4}}>
          <View style={{flexDirection: 'row'}}>
            <View
              style={{
                width: 100,
                height: 10,
                marginVertical: 10,
                marginHorizontal: 5,
              }}></View>
            <View
              style={{
                width: 100,
                height: 10,
                marginVertical: 10,
                marginHorizontal: 5,
              }}></View>
            <View
              style={{
                width: 100,
                height: 10,
                marginVertical: 10,
                marginHorizontal: 5,
              }}></View>
          </View>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginHorizontal: 5,
              alignItems: 'center',
            }}>
            <View style={{flexDirection: 'column'}}>
              <View style={{width: 150, height: 10, marginVertical: 3}}></View>
              <View style={{width: 180, height: 10, marginVertical: 3}}></View>
            </View>
            <View style={{width: 60, height: 10, marginVertical: 3}}></View>
          </View>
          <View
            style={{
              borderTopColor: '#D0D5DD',
              borderTopWidth: 1,
              marginHorizontal: 15,
              marginVertical: 10,
            }}></View>
        </View>
      </Skeleton>
    );
  };
  return (
    <>
      <Headercomponent type={'3'} name={t('ledger')} />
      <View style={styles.container}>
        <View style={styles.upperArea}>
          <Text style={styles.distributorName}>
            {profileDetail?.profile?.profileRole?.id == 4
              ? capitalize(profileDetail?.distributor?.distributorName)
              : capitalize(
                  route?.params?.distributor?.distributor?.distributorName,
                )}
          </Text>
          <View style={styles.balanceAndfilterView}>
            <View>
              <Text style={styles.currentBalanceTitle}>
                {t('totalInvoiceOutstanding')}
              </Text>
              <Text style={styles.currentBalanceValue}>
                Rs.{' '}
                {ledgerData?.distributorRetailer?.invoiceOutstanding
                  ? ChangeAmountFormat(
                      ledgerData?.distributorRetailer?.invoiceOutstanding,
                    )
                  : '0'}
              </Text>
            </View>
            <TouchableOpacity activeOpacity={0.8} onPress={onFilterClicked}>
              <View style={styles.filterView}>
                <Text style={styles.filterText}>
                  Last {selectedFilter?.filterName}
                </Text>
                <SvgXml xml={config.svgs.downArrowSvg} height={10} width={10} />
              </View>
            </TouchableOpacity>
          </View>
          <View style={styles.availableCreditLimitArea}>
            <Text style={styles.availableCreditLimitText}>
              {t('availableCreditLimit')}
            </Text>
            <Text style={styles.availableCreditLimitText}>
              Rs.{' '}
              {ledgerData?.distributorRetailer?.creditLimit
                ? ChangeAmountFormat(
                    ledgerData?.distributorRetailer?.creditLimit,
                  )
                : '-'}
            </Text>
          </View>
        </View>
        <View style={styles.transactions}>
          {isLoader ? (
            <FlatList
              // style={{ marginTop: 10 }}
              showsVerticalScrollIndicator={false}
              data={skaletonData}
              onEndReachedThreshold={0.7}
              renderItem={({item}) => skeletonRenderItem()}
            />
          ) : (
            <>
              <FlatList
                style={{marginTop: 5, marginBottom: 20, height: '30%'}}
                onRefresh={onListRefresh}
                refreshing={isRefreshing}
                onEndReached={onEndReached}
                showsVerticalScrollIndicator={false}
                data={ledgerList}
                onEndReachedThreshold={0.7}
                ListEmptyComponent={NoData}
                renderItem={({item}) => renderedItem(item)}
                // keyExtractor={item => item.materialCode}
              />
              {isLazyLoader ? (
                <ActivityIndicator
                  size="small"
                  color={config.fontAttribute.themeColor}
                />
              ) : (
                <></>
              )}
            </>
          )}
        </View>
      </View>
      {isFilterModal && (
        <FilterModal
          isOpen={isFilterModal}
          onClose={toggleFilterModal}
          filterValues={filterValues}
          onfilterValueSelected={(e: any) => onfilterValueSelected(e)}
          selectedFilter={selectedFilter}
        />
      )}
    </>
  );
};

export default Ledger;

const styles = StyleSheet.create({
  container: {
    backgroundColor: config.fontAttribute.themeColor,
    flex: 1,
  },
  distributorName: {
    fontSize: config.fontAttribute.headingFontSizeSmall * pixelValue,
    fontWeight: '700',
    color: config.fontAttribute.whiteColor,
    textAlign: 'center',
  },
  transactions: {
    backgroundColor: config.fontAttribute.whiteColor,
    flex: 1,
    borderTopRightRadius: 40,
    borderTopLeftRadius: 40,
    padding: 20,
  },
  upperArea: {
    paddingHorizontal: 30,
    paddingVertical: 10,
  },
  balanceAndfilterView: {
    marginVertical: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  currentBalanceTitle: {
    // fontSize: config.fontAttribute.labelFontSize * pixelValue,
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '400',
    color: config.fontAttribute.whiteColor,
  },
  currentBalanceValue: {
    fontSize: config.fontAttribute.headingFontSizeSmall * pixelValue,
    fontWeight: '700',
    color: config.fontAttribute.whiteColor,
  },
  filterView: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    backgroundColor: 'rgba(172,0,81,0.1)',
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  filterText: {
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '400',
    color: config.fontAttribute.whiteColor,
    marginRight: 10,
  },
  availableCreditLimitArea: {
    paddingVertical: 8,
    paddingHorizontal: 15,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    marginVertical: 10,
    borderRadius: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  availableCreditLimitText: {
    fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
    fontWeight: '400',
    color: config.fontAttribute.whiteColor,
  },
  ledgerItemCard: {
    padding: 8,
  },
  lineBreak: {
    borderTopColor: '#D0D5DD',
    borderTopWidth: 1,
    marginHorizontal: 15,
  },
  firstRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  secondRow: {
    flexDirection: 'row',
    marginVertical: 7,
    marginHorizontal: 5,
  },
  secondRowText1: {
    fontSize: config.fontAttribute.labelFontSizeSmall * pixelValue,
    fontWeight: '600',
    color: config.fontAttribute.TextColor1,
  },
  secondRowText2: {
    fontSize: 9 * pixelValue,
    fontWeight: '400',
    color: config.fontAttribute.TextColor1,
  },
  creditText: {
    fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
    fontWeight: '600',
    color: config.fontAttribute.TextColor2,
  },
  debitText: {
    fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
    fontWeight: '600',
    color: config.fontAttribute.TextColor1,
  },
  creditAmount: {
    fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
    fontWeight: '600',
    color: '#7DCE13',
  },
  debitAmount: {
    fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
    fontWeight: '600',
    color: '#FF0000',
  },
});
