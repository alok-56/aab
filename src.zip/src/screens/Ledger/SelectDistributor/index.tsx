import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native'
import React, { useState } from 'react'
import { Headercomponent } from '../../../Components'
import * as config from '../../../config/index'
import { IuserPorfileDto } from '../../../AppModel/UserProfileModel'
import { shallowEqual, useSelector } from 'react-redux'
import { SvgXml } from 'react-native-svg'
import { NavMenu, capitalize } from '../../../config/GlobalVariable'
import { IDsrProfileDto } from '../../../AppModel/DsrProfileModal'
import { useTranslation } from 'react-i18next'
import NoData from '../../../Components/No_Data_Component'

const SelectDistributor_Ledger = (props: any) => {
    const { t, i18n } = useTranslation();

    const { navigation } = props;
    const [selectedDistributor, setSelectedDistributor] = useState<any>(null)
    const [selectedRetailer, setSelectedRetailer] = useState<any>(null)
    const profileDetail: IuserPorfileDto | IDsrProfileDto | any = useSelector(
        (state: any) => state.auth.profileData,
        shallowEqual,
    );
    console.log(JSON.stringify(profileDetail, null, 2))
    // const { fromPageName } = props.route.params;
    const onSelectDistributor = (item: any, type: string) => {
        switch (type) {
            case "Retailer":
                setSelectedRetailer(item)
                break
            case "Distributor":
                setSelectedDistributor(item)
                break;
            default:
                break
        }
        setSelectedDistributor(item)
    }
    const NavigationOnButton = () => {
        // switch (fromPageName) {
        //     case 'Order':
        //         GoToCart();
        //         break;
        //     case "Ledger":
        GoToLedger();
        //         break;

        //     default:
        //         break;
        // }
    }
    const GoToLedger = () => {
        console.log(selectedDistributor)
        profileDetail?.profile?.profileRole?.id == 3 ?
            navigation.navigate(NavMenu.ledger.ledger, { distributor: selectedDistributor ? selectedDistributor : null }) :
            navigation.navigate(NavMenu.ledger.ledger, { retailer: selectedDistributor ? selectedDistributor : null })
    }
    const GoToCart = () => {
        navigation.navigate(NavMenu.order.Cart, { distributor: selectedDistributor ? selectedDistributor : null });
    }
    const renderedDistributor = (item: any) => {
        return (
            <TouchableOpacity activeOpacity={0.8} onPress={() => onSelectDistributor(item, "Distributor")}>
                <View style={styles.distributorCard}>
                    {
                        item?.distributor?.distributorCode == selectedDistributor?.distributor?.distributorCode
                            ?
                            <SvgXml xml={config.svgs.checkedCheckbox} height={18} width={18} />
                            :
                            <SvgXml xml={config.svgs.uncheckedCheckbox} height={18} width={18} />
                    }
                    <Text style={styles.distributorName}>{capitalize(item?.distributor?.distributorName)}</Text>
                </View>
            </TouchableOpacity>
        )
    }
    const renderedRetailer = (item: any) => {
        return (
            <TouchableOpacity activeOpacity={0.8} onPress={() => onSelectDistributor(item, "Retailer")}>
                <View style={styles.distributorCard}>
                    {
                        item?.retailerCode == selectedRetailer?.retailerCode
                            ?
                            <SvgXml xml={config.svgs.checkedCheckbox} height={18} width={18} />
                            :
                            <SvgXml xml={config.svgs.uncheckedCheckbox} height={18} width={18} />
                    }
                    <Text style={styles.distributorName}>{capitalize(item?.retailerName)}</Text>
                </View>
            </TouchableOpacity>
        )
    }
    return (
        <>
            <Headercomponent type={'2'} name={profileDetail?.profile?.profileRole?.id == 3 ? t('selectDistributor') : t('selectRetailer')} />
            <View style={styles.container}>
                <View style={{ flex: 1 }}>
                    <Text style={styles.heading}>
                        {profileDetail?.profile?.profileRole?.id == 3 ? t('selectDistributor') : t('selectRetailer')}
                    </Text>

                    {/* Distributor List */}
                    <FlatList
                        style={{ marginTop: 20 }}
                        showsVerticalScrollIndicator={false}
                        data={profileDetail?.profile?.profileRole?.id == 3 ? profileDetail?.distributors : profileDetail?.retailers}
                        onEndReachedThreshold={.7}
                        ListEmptyComponent={NoData}
                        renderItem={({ item }) => profileDetail?.profile?.profileRole?.id == 3 ? renderedDistributor(item) : renderedRetailer(item)}
                        keyExtractor={item => item?.distributor?.distributorCode.toString()}
                    />
                </View>
                <TouchableOpacity
                    disabled={selectedDistributor ? false : true}
                    style={[config.AppStyle.AppStyle.button, { opacity: selectedDistributor ? 1 : 0.5 }]}
                    activeOpacity={0.8}
                    onPress={NavigationOnButton}>
                    {/* {fromPageName == 'Ledger' && <Text style={config.AppStyle.AppStyle.buttonText}>{t('goToLedger')}</Text>}
                    {fromPageName == 'Order' && <Text style={config.AppStyle.AppStyle.buttonText}>{t('cart')}</Text>} */}
                    <Text style={config.AppStyle.AppStyle.buttonText}>{t('goToLedger')}</Text>
                </TouchableOpacity>
            </View>
        </>
    )
}

export default SelectDistributor_Ledger

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff', flex: 1, marginVertical: 5, borderRadius: 10, padding: 20
    },
    heading: {
        fontSize: config.fontAttribute.labelFontSizeExtraLarge,
        fontWeight: '600',
        color: config.fontAttribute.TextColor2
    },
    distributorName: {
        fontSize: config.fontAttribute.labelFontSize,
        fontWeight: '600',
        color: config.fontAttribute.TextColor2,
        marginLeft: 10
    },
    distributorCard: {
        borderWidth: 1,
        borderColor: '#EAECF0',
        borderRadius: 10,
        height: 'auto',
        padding: 15,
        marginVertical: 5,
        backgroundColor: '#fff',
        flexDirection: 'row',
        alignItems: 'center'
    }
})