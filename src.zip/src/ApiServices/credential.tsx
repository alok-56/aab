//NOTE : Change both Base URLs according to enviourment

//Base URL for APIs
//export const baseUrl = 'http://dmsdev.finolex.com:8089/TPI'; // DEV
//export const baseUrl = "http://dmsuat.finolex.com:8092/TPI";      // UAT
export const baseUrl = 'https://dms.finolex.com/TPI'; // LIVE

//Base URL for Files
//const filesURL = 'http://dmsdev.finolex.com:8089/images'; //DEV
//const filesURL = "http://dmsuat.finolex.com:8092/images"         //UAT
const filesURL = 'https://dms.finolex.com/images'; //LIVE

export const baseLinkURLProductCatalogue = `${filesURL}/ProductCatalog/`;
export const baseLinkURLComplain = `${filesURL}/ComplaintManagement/`;
