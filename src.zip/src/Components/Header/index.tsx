import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native'
import React from 'react'
import * as config from '../../config/index'
import { SvgXml } from 'react-native-svg';
import { useNavigation } from '@react-navigation/native';
import { pixelValue } from '../../config/GlobalVariable';

const Headercomponent = (props: any) => {
    const { type, name, onPlusIconClicked, onCartButtonClicked, isCart, isAdd, isDownload } = props;
    const navigation = useNavigation();
    const OpenDrawer = (navigation: any) => {
        navigation.toggleDrawer();
    }
    const onBackArrowclicked = () => {
        navigation.goBack();
    }

    return (
        <>
            {type == '1' &&
                <View style={styles.drawerHeader}>
                    <TouchableOpacity style={{ padding: 10 }} activeOpacity={0.8} onPress={() => OpenDrawer(navigation)}>
                        <SvgXml xml={config.svgs.MenuIcon} height={25} width={25} style={{ marginRight: 10 }} />
                    </TouchableOpacity>
                    <Text style={styles.headerTitle}>{name}</Text>
                </View>}
            {type == '3' &&
                <View style={styles.threeComponent}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <TouchableOpacity style={{ padding: 10 }} activeOpacity={0.8} onPress={onBackArrowclicked}>
                            <Image style={{ tintColor: '#fff', marginRight: 20 }} source={config.Images.backArrowBlack} />
                        </TouchableOpacity>
                        <Text style={styles.headerTitle}>{name}</Text>
                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        {
                            isCart ?
                                <TouchableOpacity style={{ padding: 10 }} activeOpacity={0.8} onPress={onCartButtonClicked}>
                                    <SvgXml xml={config.svgs.cart} height={25} width={25} />
                                </TouchableOpacity>
                                : <></>
                        }
                        {
                            isAdd ?
                                <TouchableOpacity style={{ padding: 10 }} activeOpacity={0.8} onPress={onPlusIconClicked}>
                                    <SvgXml xml={config.svgs.addSquareWhite} height={25} width={25} />
                                </TouchableOpacity>
                                : <></>
                        }
                        {
                            isDownload ?
                                <TouchableOpacity style={{ padding: 10 }} activeOpacity={0.8} onPress={onPlusIconClicked}>
                                    <SvgXml xml={config.svgs.downloadIcon} height={25} width={25} />
                                </TouchableOpacity>
                                : <></>
                        }
                    </View>
                </View>}
            {type == '2' &&
                <View style={styles.twocomponent}>
                    <TouchableOpacity style={{ padding: 10 }} activeOpacity={0.8} onPress={onBackArrowclicked}>
                        <Image source={config.Images.backArrowBlack} style={{ marginRight: 20, tintColor: '#fff' }} />
                    </TouchableOpacity>
                    <Text style={styles.headerTitle}>{name}</Text>
                </View>}
        </>
    )

}

export default Headercomponent

const styles = StyleSheet.create({
    threeComponent: {
        height: 65,
        backgroundColor: config.fontAttribute.themeColor,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingLeft: 15,
        paddingRight: 15
    },
    twocomponent: {
        height: 65,
        backgroundColor: config.fontAttribute.themeColor,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 15,
        paddingRight: 15,
    },
    drawerHeader: {
        height: 65,
        backgroundColor: config.fontAttribute.themeColor,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 15,
        paddingRight: 15,
    },
    headerTitle: {
        color: '#fff',
        fontWeight: '700',
        fontSize: 17 * pixelValue,
        lineHeight: 20,
    }
})