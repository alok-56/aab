import { View, Text, TouchableOpacity, TextInput, Image, StyleSheet } from 'react-native'
import React, { useState } from 'react'
import * as config from '../../config/index'
const GlobalDropdown = (props: any) => {
    const { dropDownClicked, isErrorIconVisible, onErrorIconclicked } = props
    const [isClicked, setIsclicked] = useState();
    return (

        <TouchableOpacity onPress={() => { dropDownClicked() }} activeOpacity={1}  >
            <View style={[config.AppStyle.AppStyle.inputField]}>
                <TextInput
                    editable={false}
                    placeholder='-- Select distributor --'
                    style={{ flex: 1 }}
                />

                {isClicked ?
                    <Image style={{ marginHorizontal: 5 }} source={config.Images.upArrowBlack} /> :
                    <Image style={{ marginHorizontal: 5 }} source={config.Images.DownArrow}
                    />}

            </View>
        </TouchableOpacity>

    )
}

export default GlobalDropdown

const styles = StyleSheet.create({
    downArrow: {
        position: 'absolute',
        right: 15,
        bottom: 30
    }
})