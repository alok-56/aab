import { View, Text, Modal, TouchableOpacity, Image, StyleSheet, FlatList, Dimensions, ActivityIndicator } from 'react-native'
import React from 'react'
import * as config from '../../config/index'
import { pixelValue } from '../../config/GlobalVariable';
import { SvgXml } from 'react-native-svg';
import { useTranslation } from 'react-i18next';

const ConfirmationPopup = (props: any) => {

    const { t, i18n } = useTranslation();

    //Parameters for All Cases
    const { isOpen, onClose, message, isLoading } = props;

    // Parameters for Confirmation Modal
    const { onConfirmButtonClicked, button1Title, button2Title, isconfirmation } = props

    // Parameters for Success Modal
    const { isSuccess, successMessage, onDoneButtonClicked } = props
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={styles.outerModal}>
                    <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                        <View style={styles.closeArea}>
                            {/* <Image source={config.Images.cross} /> */}
                        </View>
                    </TouchableOpacity>
                    <View style={styles.innerModal}>
                        {isconfirmation
                            &&
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <SvgXml xml={config.svgs.announcementIcon} height={50} width={50} />
                                <Text style={
                                    {
                                        marginLeft: 10,
                                        fontWeight: '500',
                                        fontSize: config.fontAttribute.headingFontSizeLarge * pixelValue,
                                        color: config.fontAttribute.themeColor
                                    }}>
                                    {t('heyWait')}</Text>
                            </View>
                        }
                        {
                            isSuccess &&
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Text style={
                                    {
                                        // marginLeft: 10,
                                        fontWeight: '500',
                                        fontSize: config.fontAttribute.headingFontSizeLarge * pixelValue,
                                        color: config.fontAttribute.themeColor
                                    }}>
                                    {successMessage}</Text>
                            </View>
                        }
                        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 15 }}>
                            <Text style={{
                                fontWeight: '400',
                                fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue,
                                color: config.fontAttribute.TextColor2,
                                maxWidth: '80%'
                            }}>{message}</Text>
                        </View>
                        {
                            isconfirmation &&
                            <View style={{ flexDirection: 'row', marginTop: 50 }}>
                                <TouchableOpacity activeOpacity={0.8} onPress={onConfirmButtonClicked} style={styles.Button}>
                                    {isLoading ?
                                        <ActivityIndicator size="small" color={'white'} />
                                        :
                                        <Text style={config.AppStyle.AppStyle.buttonText}>{button1Title}</Text>
                                    }
                                </TouchableOpacity>
                                <TouchableOpacity activeOpacity={0.8} onPress={onClose} style={styles.cancelButton}>
                                    <Text style={[config.AppStyle.AppStyle.buttonText, {
                                        color: config.fontAttribute.themeColor
                                    }]}>{button2Title}</Text>
                                </TouchableOpacity>
                            </View>
                        }
                        {
                            isSuccess &&
                            <View style={{ flexDirection: 'row', marginTop: 50 }}>
                                <TouchableOpacity activeOpacity={0.8} onPress={onDoneButtonClicked} style={[styles.Button, { marginRight: 0 }]}>
                                    <Text style={config.AppStyle.AppStyle.buttonText}>{t('done')}</Text>
                                </TouchableOpacity>
                            </View>
                        }
                    </View>
                    <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                        <View style={styles.closeArea}>

                            {/* <Image source={config.Images.cross} /> */}
                        </View>
                    </TouchableOpacity>
                </View>
            </Modal>
        </View>
    )
}

export default ConfirmationPopup

const styles = StyleSheet.create({

    listItem: {
        backgroundColor: '#fff',
        height: 65,
        padding: 15,
        // borderColor :'#667085',
        // borderBottomWidth:0.7
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    listItemText: {
        color: '#3D5E87',
        fontWeight: '400',
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue
    },
    innerModal: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '90%',
        borderRadius: 10,
        padding: 20,
    },
    outerModal: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: 'rgba(0,0,0,0.8)',
        alignItems: 'center'
    },
    Button: {
        backgroundColor: config.fontAttribute.themeColor,
        height: 45,
        width: 'auto',
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
        marginRight: 10
    },
    cancelButton: {
        flex: 1,
        borderColor: config.fontAttribute.themeColor,
        backgroundColor: config.fontAttribute.whiteColor,
        borderWidth: 1,
        height: 45,
        width: 'auto',
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 10
    },
    closeArea: {
        height: '100%',
        flex: 1,
        width: Dimensions.get('window').width
    }
})