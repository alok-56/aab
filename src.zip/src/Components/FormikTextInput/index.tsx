import { View, Text } from 'react-native'
import React, { useEffect, useState } from 'react'
import { TextInput } from 'react-native';
import * as config from '../../config/index'
import { SvgXml } from 'react-native-svg';
import { useTranslation } from 'react-i18next';

const Formik_Text_Input = (props: any) => {
  const { touched, errors, values, onChangeText, labelText, maxCharacters, editable, required, numericKeyboard } = props;
  const { t, i18n } = useTranslation();
  const [requiredField, setRequiredField] = useState(true)
  useEffect(() => {
    if (required == false) { setRequiredField(false) }
  }, [])

  return (
    <>
      <Text style={config.AppStyle.AppStyle.inputLabel}>{t(labelText)}{requiredField && <RedStar />}</Text>
      <View style={[config.AppStyle.AppStyle.inputField,
      { borderColor: touched && errors ? 'red' : '#ced4da' }
      ]}>
        <TextInput
          placeholderTextColor={config.fontAttribute.placeholderColor}
          selectionColor={config.fontAttribute.cursorColor}
          keyboardType={numericKeyboard ? 'numeric' : undefined}
          editable={editable}
          maxLength={maxCharacters}
          style={{ flex: 1, color: config.fontAttribute.textInputValueColor }}
          value={values}
          onChangeText={(text) => onChangeText(text)}
          placeholder={t(labelText)}
        />
        {
          touched && errors
            ?
            <SvgXml xml={config.svgs.errorIcon} height={18} width={18} />
            :
            <></>
        }
      </View>
      {touched && errors && (
        <Text style={config.AppStyle.AppStyle.errorMessage}>{errors}</Text>
      )}
    </>
  )
}

export default Formik_Text_Input

const RedStar = () => {
  return (
    <View>
      <Text style={{ color: 'red' }}>*</Text>
    </View>
  )
}