import React, { useState } from 'react'
import { ActivityIndicator, View, Modal } from 'react-native';

export default function CustomLoader(props: any) {
  console.log(props)
  const [isLoading, setIsLoading] = useState(false);
  return (

    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <ActivityIndicator color={"#fff"} />
    </View>
  )
}
