import { StyleSheet } from "react-native";
import { pixelValue } from "../../config/GlobalVariable";
import * as fontAttribute from "../../config/fontConfig";

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: fontAttribute.pageBackgroundColor,
    },
    userProfilePic: {
        height: 70,
        width: 70,
        borderWidth: 2,
        borderColor: fontAttribute.TextColor1,
        borderRadius: 100
    },
    userDetails: {
        flexDirection: 'row',
        alignItems: 'center',
        margin: 10,
        backgroundColor: '#fff',
        padding: 10,
        borderRadius: 10,
    },
    userInfo: {
        marginLeft: 15,
        maxWidth: '70%'
    },
    MenuItems: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        // margin:10,
        padding: 10,
        // backgroundColor:'red'
    },
    menuItemText: {
        color: fontAttribute.TextColor2,
        fontSize: fontAttribute.labelFontSize * pixelValue
    },
    appVersionBackground: {
        backgroundColor: fontAttribute.whiteColor,
        paddingHorizontal: 10,
        paddingVertical: 8,
        marginHorizontal: 10,
        marginBottom: 10,
        borderRadius: 10,
    },
    appVersionText: {
        fontWeight: '500',
        color: fontAttribute.themeColor,
        marginLeft: 10,
        fontSize: fontAttribute.labelFontSizeMedium * pixelValue
    },
     shareButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4E4E93',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  shareText: {
    color: '#fff',
    fontSize: 14,
    marginLeft: 8,
    fontWeight: '600',
  },
    userNameText: {
        fontWeight: '600',
        color: fontAttribute.TextColor2,
        fontSize: fontAttribute.labelFontSize * pixelValue
    },
    userEmailText: {
        fontWeight: '400',
        color: fontAttribute.TextColor1,
        fontSize: fontAttribute.labelFontSizeMedium * pixelValue
    },
    drawerHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        margin: 10
    },
    headerDashboardRightArea: {
        flexDirection: 'row',
    },
    drawerHeaderRightImages: {
        marginRight: 15,
        height:25,
        width:25,
    },
    MenuList: {
        // backgroundColor: '#fff',
        padding: 10,
        // borderRadius: 10,
        // marginHorizontal: 10,
    },
    quickLinks: {
        // padding: 10,
        // backgroundColor: '#fff',
        // borderRadius: 10,
        marginBottom: 10,
        // marginHorizontal: 10,
        paddingHorizontal: 20,
        flexDirection: 'row',
        justifyContent: 'space-around'
    },
    quickLinksIcon: {
        width: 25,
        height: 25,
        // backgroundColor:'red',
        // borderRadius:50
    }
})