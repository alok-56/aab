import {
  View,
  Text,
  Image,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Linking,
  Share,
} from 'react-native';
import React, { useState } from 'react';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';
import {
  setAccessToken,
  setDistributors,
  setMenuList,
  setProfileDetail,
  setUserData,
} from '../../redux/actions/authAction';
import { styles } from './style';
import { SvgXml } from 'react-native-svg';
import * as config from '../../config/index';
import DeviceInfo from 'react-native-device-info';
import { IuserDetail } from '../../redux/datamodel/authDataModal';
import { IuserPorfileDto } from '../../AppModel/UserProfileModel';
import {
  NavMenu,
  PUSH_Token,
  capitalize,
  checkStringNullOrEmpty,
  deleteDeviceDetails,
} from '../../config/GlobalVariable';
import { useTranslation } from 'react-i18next';
import ConfirmationPopup from '../ConfirmationPopup/ConfirmationPopup';
import { DeleteDeviceDetails } from '../../ApiServices/httpServices';
import { IDsrProfileDto } from '../../AppModel/DsrProfileModal';
import { setSelecteLanguage } from '../../redux/actions/langAction';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/Feather';

const DrawerContent = (props: any) => {
  const { navigation } = props;
  const authInfo: IuserDetail = useSelector(
    (state: any) => state.auth.userData,
    shallowEqual,
  );
  const { t, i18n } = useTranslation();
  const profileDetail: IuserPorfileDto | IDsrProfileDto = useSelector(
    (state: any) => state.auth.profileData,
    shallowEqual,
  );
  const menuList: any = useSelector(
    (state: any) => state.auth.menuList,
    shallowEqual,
  );
  const [profilePic, setProfilePic] = useState('');
  const dispatch = useDispatch();
  const AppVersion = DeviceInfo.getVersion();
  const MenuItemclicked = (item: any) => {
    switch (item?.menuCode) {
      case 1:
        navigation.closeDrawer();
        break;
      case 2:
        navigation.navigate(NavMenu.order.order);
        navigation.closeDrawer();
        break;
      case 3:
        navigation.navigate(NavMenu.productCatalog);
        navigation.closeDrawer();
        break;
      case 4:
        navigation.navigate(NavMenu.ledger.distributorLedger);
        // if (profileDetail?.profile?.profileRole.id == 3) {
        //   navigation.navigate(NavMenu.ledger.distributorLedger, { fromPageName: "Ledger" });
        // }
        // else {
        //   navigation.navigate(NavMenu.ledger.ledger);
        // }
        navigation.closeDrawer();
        break;
      case 5:
        navigation.navigate(NavMenu.changeLanguage);
        navigation.closeDrawer();
        break;
      case 6:
        navigation.navigate(NavMenu.changePassword);
        navigation.closeDrawer();
        break;
      case 7:
        navigation.navigate(NavMenu.feedback.feedbackList);
        navigation.closeDrawer();
        break;
      case 8:
        navigation.navigate(NavMenu.contactUs);
        navigation.closeDrawer();
        break;
      case 9:
        logoutConfirmAlert();
        navigation.closeDrawer();
        break;
      case 10:
        navigation.navigate(NavMenu.beatPlanManagement.addRetailer);
        navigation.closeDrawer();
        break;
      case 11:
        navigation.navigate(NavMenu.beatPlanManagement.visitDetailsList, {
          fromPage: NavMenu.beatPlanManagement.markedVisits,
        });
        navigation.closeDrawer();
        break;
      case 12:
        navigation.navigate(NavMenu.beatPlanManagement.visitDetailsList, {
          fromPage: NavMenu.beatPlanManagement.visitDetailsList,
        });
        navigation.closeDrawer();
        break;
      default:
        break;
    }
  };
  const logoutConfirmAlert = () => {
    navigation.closeDrawer();
    toggleLogoutModal();
  };

  const finalLogout = async () => {
    try {
      //Api call for Delete device details
      console.log(JSON.stringify(profileDetail,null,2))
      deleteDeviceDetails(profileDetail?.profile.profileId);
      

      dispatch(
        setSelecteLanguage({
          languageCode: 'en',
          languageId: 2,
          languageName: 'English',
        }),
      );
      dispatch(setUserData(null));
      dispatch(setAccessToken(null));
      dispatch(setProfileDetail(null));
      dispatch(setDistributors(null));
      dispatch(setMenuList(null));
      setTimeout(() => {
        props?.navigation?.reset({
          index: 0,
          routes: [{ name: 'Login' }],
        });
      }, 100);
    } catch (error) {
      console.log('Error : ', error);
    }
  };

  const openProfilePage = () => {
    navigation.toggleDrawer();
    navigation.navigate('profile');
  };

  const [isLogOutModal, setIsLogOutModal] = useState(false);
  const onLogOutButtonClicked = () => {
    toggleLogoutModal();
    finalLogout();
  };
  const toggleLogoutModal = () => {
    setIsLogOutModal(!isLogOutModal);
  };
  const onQuickLinksClicked = (type: any) => {
    switch (type) {
      case 'facebook':
        Linking.openURL('https://www.facebook.com/FinolexCables/');
        navigation.closeDrawer();
        break;
      case 'instagram':
        Linking.openURL('https://www.instagram.com/Finolex.Cables/');
        navigation.closeDrawer();
        break;
      case 'twitter':
        Linking.openURL('https://twitter.com/FinolexCables/');
        navigation.closeDrawer();
        break;
      case 'finolex':
        Linking.openURL('https://www.finolex.com/');
        navigation.closeDrawer();
        break;
      default:
        break;
    }
  };

  const handleShareApp = async () => {
    try {
      await Share.share({
        message: 'Check out this awesome app: [Your App Link Here]',
        title: 'Share App',
      });
    } catch (error) {
      console.log('Error sharing app:', error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.container}>
        <View style={styles.drawerHeader}>
          <SvgXml xml={config.svgs.FinolexLogo} height={50} width={100} />
          <View style={styles.headerDashboardRightArea}>
            <TouchableOpacity
              onPress={() => logoutConfirmAlert()}
              activeOpacity={0.8}
            >
              <Image
                style={styles.drawerHeaderRightImages}
                source={config.Images.logout}
              />
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity activeOpacity={1} onPress={openProfilePage}>
          <View style={styles.userDetails}>
            {!checkStringNullOrEmpty(profilePic) ? (
              <SvgXml height={70} width={70} xml={config?.svgs?.profileIcon} />
            ) : (
              <Image
                style={styles.userProfilePic}
                source={profilePic ? { uri: profilePic } : {}}
              />
            )}
            <View style={styles.userInfo}>
              <Text style={styles.userNameText}>
                {capitalize(profileDetail?.profile?.profileName)}
              </Text>
              <Text style={styles.userEmailText}>
                {checkStringNullOrEmpty(profileDetail?.emailId)
                  ? profileDetail?.emailId.toLowerCase()
                  : '-'}
              </Text>
            </View>
          </View>
        </TouchableOpacity>

        <View
          style={{
            borderRadius: 10,
            flex: 1,
            backgroundColor: '#fff',
            margin: 10,
          }}
        >
          <FlatList
            style={styles.MenuList}
            data={menuList}
            renderItem={({ item }) => (
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => MenuItemclicked(item)}
                style={styles.MenuItems}
              >
                <Text style={styles.menuItemText}>{t(item?.menuName)}</Text>
                <SvgXml
                  xml={config.svgs.menuItemArrow}
                  height={10} 
                  width={10} 
                />
              </TouchableOpacity>
            )}
          />
          <View style={styles.quickLinks}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => onQuickLinksClicked('facebook')}
            >
              <Image
                source={config.Images.facebook}
                style={styles.quickLinksIcon}
              />
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => onQuickLinksClicked('instagram')}
            >
              <Image
                source={config.Images.instagram}
                style={styles.quickLinksIcon}
              />
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => onQuickLinksClicked('twitter')}
            >
              <Image
                source={config.Images.twitter}
                style={styles.quickLinksIcon}
              />
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => onQuickLinksClicked('finolex')}
            >
              <Image
                source={config.Images.websiteLink}
                style={[styles.quickLinksIcon, { tintColor: 'black' }]}
              />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <View style={styles.appVersionBackground}>
        <Text style={styles.appVersionText}>
          {t('appVersion')} : {AppVersion}
        </Text>
        {/* <TouchableOpacity onPress={handleShareApp} style={styles.shareButton}>
          <Icon name="share" size={20} color="#fff" />
          <Text style={styles.shareText}>{t('Share App')}</Text>
        </TouchableOpacity> */}
      </View>

      <ConfirmationPopup
        isOpen={isLogOutModal}
        onClose={toggleLogoutModal}
        onConfirmButtonClicked={onLogOutButtonClicked}
        message={t('logoutConfirmationMessage')}
        button1Title={t('logOut')}
        button2Title={t('no')}
        isconfirmation={true}
      />
    </SafeAreaView>
  );
};

export default DrawerContent;
