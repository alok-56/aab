import { View, Text, Modal, TouchableOpacity, Image, StyleSheet, FlatList, Dimensions } from 'react-native'
import React from 'react'
import * as config from '../../config/index'
import { pixelValue } from '../../config/GlobalVariable';
import { SvgXml } from 'react-native-svg';
import { useTranslation } from 'react-i18next';

const LogOutModal = (props: any) => {
    const { t, i18n } = useTranslation();

    const { isOpen, onClose, listItemClicked, onLogOutButtonClicked } = props;
    return (
        <View>
            <Modal
                transparent={true}
                visible={isOpen}
                onRequestClose={onClose}
                animationType='none'>
                <View style={styles.outerModal}>
                    <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                        <View style={styles.closeArea}>
                            {/* <Image source={config.Images.cross} /> */}
                        </View>
                    </TouchableOpacity>
                    <View style={styles.innerModal}>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <SvgXml xml={config.svgs.announcementIcon} height={50} width={50} />
                            <Text style={
                                {
                                    marginLeft: 10,
                                    fontWeight: '500',
                                    fontSize: config.fontAttribute.headingFontSizeLarge * pixelValue,
                                    color: config.fontAttribute.themeColor
                                }}>
                                {t('heyWait')}</Text>
                        </View>
                        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 15 }}>
                            <Text style={{
                                fontWeight: '400',
                                fontSize: config.fontAttribute.labelFontSizeLarge,
                                color: config.fontAttribute.TextColor2,
                                maxWidth: '80%'
                            }}>{t('logoutMessage')}</Text>
                        </View>
                        <View style={{ flexDirection: 'row', marginTop: 50 }}>
                            <TouchableOpacity activeOpacity={0.8} onPress={onLogOutButtonClicked} style={styles.Button}>
                                <Text style={config.AppStyle.AppStyle.buttonText}>{t('logOut')}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity activeOpacity={0.8} onPress={onClose} style={styles.cancelButton}>
                                <Text style={[config.AppStyle.AppStyle.buttonText, {
                                    color: config.fontAttribute.themeColor
                                }]}>{t('noGoBack')}</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <TouchableOpacity activeOpacity={0.9} onPress={onClose}>
                        <View style={styles.closeArea}>
                            {/* <Image source={config.Images.cross} /> */}
                        </View>
                    </TouchableOpacity>
                </View>
            </Modal>
        </View>
    )
}

export default LogOutModal

const styles = StyleSheet.create({

    listItem: {
        backgroundColor: '#fff',
        height: 65,
        padding: 15,
        // borderColor :'#667085',
        // borderBottomWidth:0.7
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    listItemText: {
        color: '#3D5E87',
        fontWeight: '400',
        fontSize: 16 * pixelValue
    },
    innerModal: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '90%',
        borderRadius: 10,
        padding: 20,
    },
    outerModal: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: 'rgba(0,0,0,0.8)',
        alignItems: 'center'
    },
    Button: {
        backgroundColor: config.fontAttribute.themeColor,
        height: 45,
        width: 'auto',
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
        marginRight: 10
    },
    cancelButton: {
        flex: 1,
        borderColor: config.fontAttribute.themeColor,
        backgroundColor: config.fontAttribute.whiteColor,
        borderWidth: 1,
        height: 45,
        width: 'auto',
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 10
    },
    closeArea: {
        height: '100%',
        flex: 1,
        width: Dimensions.get('window').width
    }
})