import { View, Text, StyleSheet } from 'react-native'
import React from 'react'
import * as config  from '../../config/index'
import { useTranslation } from 'react-i18next';
import { pixelValue } from '../../config/GlobalVariable';

const NoData = () => {
  const { t, i18n } = useTranslation();

  return (
    <View style={styles.container}>
        <View style={styles.Card}>
      <Text style={styles.cardText}>{t('noDataAvailable')}</Text>
    </View>
    </View>
  )
}

export default NoData

const styles = StyleSheet.create({
    container:{
        justifyContent:'center',
        alignItems:'center',
    },
    Card:{
        height:120,
        width:'90%',
        backgroundColor:'#fff',
        borderRadius:10,
        justifyContent:'center',
        alignItems:'center',
        margin:10,
    },
    cardText:{
        color:config.fontAttribute.themeColor,
        fontSize:config.fontAttribute.labelFontSize  * pixelValue,
        fontWeight:'400'
    }
})