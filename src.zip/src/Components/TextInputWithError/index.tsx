import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native'
import React from 'react'
import * as config from '../../config/index'
import { SvgXml } from 'react-native-svg';

const TextInputWithError = (props: any) => {
  const { errorMessage, placeholder, keyboardType, secureTextEntry, onChangeText, isDropdown, onFocus, onBlur, maxLength, isErrorMessageVisible = true, isErrorIconVisible } = props;
  return (
    <>
      <TouchableOpacity activeOpacity={1}>
        <View style={[config.AppStyle.AppStyle.inputField, isErrorMessageVisible ? config.AppStyle.AppStyle.inputErrored : {}]}>
          <TextInput
            onChangeText={e => onChangeText ? onChangeText(e) : {}}
            onFocus={() => onFocus ? onFocus() : {}}
            onBlur={() => onBlur ? onBlur() : {}}
            style={{ flex: 1, color: config.fontAttribute.textInputValueColor }}
            secureTextEntry={secureTextEntry ? true : false}
            placeholder={placeholder ? placeholder : ''}
            editable={isDropdown ? false : true}
            keyboardType={keyboardType ? keyboardType : undefined}
            maxLength={maxLength ? maxLength : undefined}
            placeholderTextColor={config.fontAttribute.placeholderColor}
            selectionColor={config.fontAttribute.cursorColor}
          // value={inputValue?inputValue:''}
          />

          {
            isErrorMessageVisible ?
              <SvgXml xml={config.svgs.errorIcon} height={18} width={18} />
              : <></>
          }
          {/* {
            isDropdown ?
              <Image style={{ marginEnd: 5 }} source={config.Images.DownArrow} />
              : <></>
          } */}
        </View>
      </TouchableOpacity>
      <ErrorMessage isVisible={isErrorMessageVisible} errorMessage={errorMessage} />
    </>
  )
}

export default TextInputWithError

export const ErrorMessage = (props: any) => {
  const { errorMessage, isVisible } = props;
  return (
    isVisible ?
      <View>
        <Text style={{ color: 'red', fontWeight: '400', fontSize: config.fontAttribute.labelFontSizeMedium }}>{errorMessage}</Text>
      </View>
      :
      <Text style={{ color: 'white', fontWeight: '400', fontSize: config.fontAttribute.labelFontSizeMedium }}>h</Text>
  )
}