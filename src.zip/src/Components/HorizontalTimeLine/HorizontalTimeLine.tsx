import { View, Text, StyleSheet, Dimensions } from 'react-native'
import React from 'react'
import { themeColor } from '../../config/fontConfig';

const HorizontalTimeLine = ({ currentStep }: any) => {
    // const { t, i18n } = useTranslation();
    // const steps = [t('address'), t('payment'), t('placeOrder')];
    const steps = ['Address', 'Payment', 'Place order'];
    const customStyles = {
        selectedCircle: { backgroundColor: themeColor },
        unselectedCircle: { backgroundColor: 'rgba(102,112,133,0.5)' },
        notCircle: { backgroundColor: '#fff' },
        selectedText: { color: 'black' },
        unselectedText: { color: 'black' },
        selectedOuter: { borderColor: themeColor },
        unSelectedOuter: { borderColor: 'rgba(102,112,133,0.5)' },
        selectedLine: { borderColor: themeColor }, // Line color when step is selected
        unselectedLine: { borderColor: 'rgba(102,112,133,0.5)' },
    };
    const screenWidth = Dimensions.get('window').width;
    const stepWidth = screenWidth / steps.length;
    return (
        <>
            <View style={styles.container}>
                {steps.map((step, index) => (
                    <>
                        {/* /<View key={step} style={styles.stepContainer}> */}
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            {index !== 0 ?
                                <View
                                    style={[
                                        styles.line,
                                        { width: stepWidth / 1.5 },
                                        index <= currentStep + 1 ? customStyles.selectedLine : customStyles.unselectedLine,
                                    ]}
                                /> : <></>
                            }

                            <View style={[
                                styles.outerCircle,
                                index <= currentStep ? customStyles.selectedOuter : customStyles.unSelectedOuter,
                                index <= currentStep + 1 ? customStyles.selectedOuter : customStyles.unSelectedOuter,
                            ]}>
                                <View
                                    style={[
                                        styles.circle,
                                        index <= currentStep ? customStyles.selectedCircle : {},
                                    ]}
                                />
                            </View>
                        </View>

                        {/* </View> */}
                    </>
                ))}
            </View>
            <View style={[styles.container2]}>
                {steps.map((step, index) => (
                    <View style={{
                        // backgroundColor: 'red',
                        // alignItems: 'flex-end',
                        // alignSelf: 'flex-start',
                        marginHorizontal: stepWidth / 4.3
                    }}>
                        <Text
                            style={[
                                styles.stepText,
                                // { width: stepWidth / 2 },
                                index <= currentStep ? customStyles.selectedText : customStyles.unselectedText,
                            ]}
                        >
                            {step}
                        </Text>
                    </View>
                ))}
            </View>
        </>
    );
}

export default HorizontalTimeLine

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: "center",
        alignItems: 'center',
        paddingVertical: 10,
        // backgroundColor: 'blue'
    },
    container2: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'flex-start',
        // paddingVertical: -15,
        marginTop: -10,
        paddingLeft: 20,
        paddingBottom: 10,
        backgroundColor: '#fff'
    },
    stepContainer: {
        // alignItems: 'flex-end',
        // backgroundColor: 'red',
    },
    circle: {
        width: 10,
        height: 10,
        borderRadius: 50,
        // marginBottom: 5,
    },
    outerCircle: {
        justifyContent: 'center',
        alignItems: 'center',
        width: 30,
        height: 30,
        borderRadius: 50,
        borderColor: 'red',
        borderWidth: 1.5
    },
    stepText: {
        textAlign: 'center',
        // marginLeft: -20
        // textAlign: 'right',
        // backgroundColor: 'red'
        // maxWidth: 60,
        // marginTop: 5,
        // marginLeft:10
    },

    line: {
        // height: 2,
        // flex: 1, // This will ensure the line stretches to fill the space between circles
        // marginHorizontal: 5,
        borderTopWidth: 1.5, borderColor: themeColor
    },

    // customStyles = {
    //     selectedCircle: { backgroundColor: 'blue' },
    //     unselectedCircle: { backgroundColor: 'grey' },
    //     selectedText: { color: 'blue' },
    //     unselectedText: { color: 'grey' },
    // };
});