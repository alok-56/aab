import messaging from '@react-native-firebase/messaging';
import { PermissionsAndroid } from 'react-native';
import PushNotification from 'react-native-push-notification';
import { setPushToken } from '../../config/GlobalVariable';

export async function requestUserPermission() {
  console.log("token")
  const authStatus = await messaging().requestPermission();
  const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;

  if (enabled) {
    // console.log('Authorization status:', authStatus);
  }
  PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
}
export async function getToken() {
  const token = await messaging().getToken();
  console.log("token = ", token);
  setPushToken(token);
  // const dispatch = useDispatch();
  // dispatch(setPushNotificationToken(token));
}
export const pushNotificationConfiguration = () => [
  PushNotification.configure({
    onNotification: function (notification) {
      //   console.log('REMOTE NOTIFICATION ==>', notification);

      // Check if the app is in the foreground
      if (notification.foreground) {
        // Display an alert or a modal with the notification details
        console.log(notification.message);
        // Alert.alert('Notification Received', notification.message.toString());
      }

      // Call this function to stop the notification from being shown
      // notification.finish(PushNotificationIOS.FetchResult.NoData);
    },
    // Other configuration...
  })
]