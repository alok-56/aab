import { View, Text, Dimensions } from 'react-native'
import React from 'react'
import {
    LineChart,
    BarChart,
    PieChart,
    ProgressChart,
    ContributionGraph,
    StackedBarChart
} from "react-native-chart-kit";


const Chart = (props) => {
    return (
        <View >
            <LineChart
                data={props.data}
                renderDotContent={({ x, y, index }) => (
                    <View key={index} style={{ position: 'absolute', top: y - 30, left: x - 7 }}>
                        <Text style={{ color: 'black' }}>{props.data.datasets[0].data[index].toFixed(0)}</Text>
                    </View>
                )}
                withInnerLines={false}
                withOuterLines={false}
                width={Dimensions.get("window").width}// from react-native
                height={220}
                yAxisLabel="$"
                yAxisSuffix="k"
                yAxisInterval={1} // optional, defaults to 1
                chartConfig={{
                    fillShadowGradient: 'orange',
                    backgroundGradientFrom: "rgb(230,230,250)",
                    backgroundGradientTo: "rgb(230,230,250)",
                    backgroundGradientFromOpacity: 0,
                    backgroundGradientToOpacity: 0,
                    decimalPlaces: 2, // optional, defaults to 2dp
                    color: (opacity = 1) => 'purple',//`rgba(255, 255, 255, ${opacity})`,
                    labelColor: (opacity = 1) => 'purple',// `rgba(255, 255, 255, ${opacity})`,
                    style: {
                        borderRadius: 16,
                    },
                    propsForDots: {
                        r: "6",
                        strokeWidth: "2",
                        stroke: "white"
                    },
                }}
                bezier
                style={{
                    borderRadius: 16,
                    margin: 10,
                    marginTop: 30,
                    alignItems: 'center'
                }}
            />
        </View>
    )
}

export default Chart