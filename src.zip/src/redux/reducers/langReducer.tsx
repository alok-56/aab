
import * as constants from "../constants";
const initialstate = {
    language: { languageCode: 'en', languageId: 2, languageName: 'English' }
};


export const LangReducer = (state = initialstate, action: any) => {

    switch (action.type) {

        case constants.SELECTED_LANGUAGE:
            return {
                ...state, language: action.data
            }
        default:
            return state;
    }
}