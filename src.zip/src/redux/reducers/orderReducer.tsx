
import * as constants from "../constants";
const initialstate = {
  cartId:null
};


export const orderReducer = (state = initialstate, action:any) => {
   
    switch (action.type) {
        
        case constants.CART_ID:
            return {
                ...state, cartId: action.data
            }
 

        default:
            return state;
    }
}