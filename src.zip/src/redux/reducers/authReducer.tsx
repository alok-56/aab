
import * as constants from "../constants";
const initialstate = {
    userData: null,
    accessToken: null,
    profileData: null,
    menuList: null,
    PushNotificationToken: null,
    Distributors: null,
    loginTime: null
};

export const AuthReducer = (state = initialstate, action: any) => {

    switch (action.type) {

        case constants.USER_DATA:
            return {
                ...state, userData: action.data
            }
        case constants.ACCESS_TOKEN:
            return {
                ...state, accessToken: action.data
            }
        case constants.LOGIN_TIME:
            return {
                ...state, loginTime: action.data
            }
        case constants.PROFILE_DATA:
            return {
                ...state, profileData: action.data
            }
        case constants.MENU_LIST:
            return {
                ...state, menuList: action.data
            }
        case constants.PUSH_NOTIFICATION_TOKEN:
            return {
                ...state, PushNotificationToken: action.data
            }
        case constants.DISTRIBUTOR_DATA:
            return {
                ...state, Distributors: action.data
            }
        default:
            return state;
    }
}

