import { SELECTED_LANGUAGE } from "../constants";
import { Ilanguage } from "../datamodel/langDataModal";

export function setSelecteLanguage(userData:Ilanguage|null) {
    return {
        type: SELECTED_LANGUAGE,
        data: userData
    }
}