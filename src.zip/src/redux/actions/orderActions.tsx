import { CART_ID } from "../constants";
import { Ilanguage } from "../datamodel/langDataModal";

export function setCartId(cartId: any) {
    return {
        type: CART_ID,
        data: cartId
    }
}