import { ISOStringFormat } from 'date-fns'
import { IDsrProfileDto } from '../../AppModel/DsrProfileModal'
import { Distributor2, IuserPorfileDto } from '../../AppModel/UserProfileModel'
import { USER_DATA, ACCESS_TOKEN, PROFILE_DATA, PUSH_NOTIFICATION_TOKEN, DISTRIBUTOR_DATA, MENU_LIST, LOGIN_TIME } from '../constants'
import { IuserDetail } from '../datamodel/authDataModal'

export function setUserData(userData: IuserDetail | null) {
    return {
        type: USER_DATA,
        data: userData
    }
}
export function setAccessToken(token: string | null) {
    return {
        type: ACCESS_TOKEN,
        data: token
    }
}
export function setLoginTime(time: string | null) {
    return {
        type: LOGIN_TIME,
        data: time
    }
}
export function setProfileDetail(profileData: IDsrProfileDto | IuserPorfileDto | null) {
    return {
        type: PROFILE_DATA,
        data: profileData
    }
}
export function setMenuList(menuList: any | null) {
    return {
        type: MENU_LIST,
        data: menuList
    }
}
export function setDistributors(distributors: Distributor2[] | null) {
    return {
        type: DISTRIBUTOR_DATA,
        data: distributors
    }
}

export function setPushNotificationToken(token: string | null) {
    return {
        type: PUSH_NOTIFICATION_TOKEN,
        data: token
    }
}