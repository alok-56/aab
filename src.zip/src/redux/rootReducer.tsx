import { combineReducers } from "redux";
import {  AuthReducer } from "./reducers/authReducer";
import { LangReducer } from "./reducers/langReducer";
import { orderReducer } from "./reducers/orderReducer";

export default combineReducers({
    auth: AuthReducer,
    lang:LangReducer,
    order:orderReducer

})
