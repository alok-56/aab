// export interface IuserDetail {
//     userId: number
//     userName:string
//     accessToken: string
//     expireInSeconds: number
//     shouldResetPassword: boolean

//     userRole: string
//     refreshToken: string
//     refreshTokenExpireInSeconds: number
//   }


  export interface IuserDetail {
    userName: number
    fullName: any
    emailId: any
    mobileNo: string
    roleId: number
    role: Role
    password: any
    passwordCreationDate: string
    lastPassword: any
    firmName: any
    isInternalEmp: boolean
    status: string
    validityStart: string
    validityEnd: string
    jwtToken: string
    finolexEmployeeId: number
    distributorCode: number
    retailerCode: number
    dsrId: number
  }
  
  export interface Role {
    id: number
    name: string
    description: string
    status: string
    accessRights: any[]
    users: any[]
  }