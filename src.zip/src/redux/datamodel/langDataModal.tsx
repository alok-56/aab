export interface Ilanguage {
    languageId:number,
    languageName:string,
    languageCode:string,

}