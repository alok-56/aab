/**
 * Basic Setting Variables Define
 */
export const BaseSetting = {
    name: 'Finolex',
    displayName: 'Finolex',
    appVersion: '1',
    defaultLanguage: 'en',
    languageSupport: [
      'en',
      'hi',
    //   'mt',
    //   'pb',
    ],
    
    resourcesLanguage: {
      en: {
        translation: require('../lang/en.json'),
      },
      hi: {
        translation: require('../lang/hi.json'),
      },
    //   mt: {
    //     translation: require('../lang/mt.json'),
    //   },
    //   pb: {
    //     translation: require('../lang/pb.json'),
    //   },
    },
  
  
  
  };
  