import { StyleSheet } from "react-native";
import { pixelValue } from "./GlobalVariable";
import { TextColor2, themeColor, whiteColor } from '../config/fontConfig'
import * as config from '../config/index'

export const AppStyle = StyleSheet.create({
    flex1: {
        flex: 1
    },
    container: {
        flex: 1,
        backgroundColor: themeColor
    },
    // '#2180b4'
    inputField: {
        height: 50,
        borderColor: '#ced4da',
        borderWidth: 1,
        borderRadius: 8,
        paddingLeft: 10,
        paddingRight: 10,
        marginTop: 5,
        marginBottom: 10,
        color: '#667085',
        flexDirection: 'row',
        alignItems: 'center',
    },
    textArea: {
        borderColor: '#ced4da',
        borderWidth: 1,
        borderRadius: 8,
        paddingLeft: 10,
        paddingRight: 10,
        marginTop: 10,
        marginBottom: 10,
        color: '#667085',
    },
    disabledInputField: {
        backgroundColor: '#F9FAFB'
    },
    inputFocused: {
        borderColor: 'blue',
    },
    inputErrored: {
        borderColor: 'red'
    },
    button: {
        backgroundColor: themeColor,
        height: 45,
        width: 'auto',
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 40,
        borderWidth: 1,
        borderColor: themeColor
    },
    button2: {
        backgroundColor: 'transparent',
        height: 45,
        width: 'auto',
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 40,
        borderWidth: 1,
        borderColor: themeColor
    },
    buttonText: {
        fontWeight: '500',
        color: whiteColor,
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue
    },
    buttonText2: {
        fontWeight: '500',
        color: themeColor,
        fontSize: config.fontAttribute.labelFontSizeLarge * pixelValue
    },
    inputLabel: {
        fontWeight: '500',
        color: config.fontAttribute.TextColor2,
        // fontSize: config.fontAttribute.labelFontSize * pixelValue,
        fontSize: 12 * pixelValue,
    },
    ModalOuterCss: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0,0,0,0.8)'
    },
    ModalInnerCss: {
        backgroundColor: '#fff',
        height: 'auto',
        width: '100%',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        padding: 5,
        maxHeight: '60%'
    },
    ModalCrossIcon: {
        alignItems: 'flex-end',
        paddingBottom: 20,
        paddingRight: 20,
        justifyContent: 'flex-end',
        height: '100%',
    },
    rowTitle: {
        color: config.fontAttribute.TextColor2,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '600'
    },
    rowValue: {
        color: config.fontAttribute.TextColor1,
        fontSize: config.fontAttribute.labelFontSizeMedium * pixelValue,
        fontWeight: '400'
    },
    errorMessage: {
        color: 'red', fontWeight: '400', fontSize: config.fontAttribute.labelFontSizeMedium
    }
})