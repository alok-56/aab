const FinolexLogo = `<svg id="Layer_2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 310.56 160.21">
       
<g id="Layer_1-2">
   <rect class="cls-1" fill="#fff" stroke-width="0px" x="0" y="106.35" width="310.56" height="53.86"/>
   <g id="_Path_">
      <rect class="cls-3" stroke-width="0px" fill="#2093d1" width="310.56" height="117.57"/>
   </g>
   <g id="_Path_-2">
      <polygon class="cls-2" fill="#fff" stroke-width="0px" fill-rule="evenodd" points="69.02 40.05 69.02 29.94 28.29 29.94 28.29 87.15 40.3 87.15 40.3 63.04 65.44 63.04 65.44 52.94 40.3 52.94 40.3 40.05 69.02 40.05"/>
   </g>
   <g id="_Compound_Path_">
      <path class="cls-2" fill="#fff" stroke-width="0px" fill-rule="evenodd" d="m73.39,87.15h11.22v-42.41h-11.22v42.41Zm0-57.84v10.42h11.22v-10.42h-11.22Z"/>
   </g>
   <g id="_Path_-3">
      <path class="cls-2" fill="#fff" stroke-width="0px" fill-rule="evenodd" d="m126.73,47.37c-2.63-2.49-6.25-3.74-10.86-3.74-5.78,0-10.03,2.44-12.73,7.32h-.16v-6.21h-10.74v42.41h11.21v-24.27c0-2.81.69-5.15,2.07-7,1.38-1.86,3.58-2.78,6.6-2.78s5.13.74,6.01,2.22c.87,1.49,1.31,3.55,1.31,6.21v25.62h11.21v-29.36c0-4.46-1.31-7.93-3.94-10.42Z"/>
   </g>
   <g id="_Compound_Path_-2">
      <path class="cls-2" fill="#fff" stroke-width="0px" fill-rule="evenodd" d="m176.2,54.17c-1.77-3.42-4.29-6.04-7.55-7.84-3.26-1.8-7.04-2.7-11.33-2.7-7.05,0-12.45,2.13-16.19,6.4-3.74,4.27-5.61,9.59-5.61,15.95,0,5.94,1.81,11.14,5.45,15.59,3.63,4.46,9.08,6.68,16.35,6.68,6.73,0,12.01-2.09,15.83-6.28,3.82-4.19,5.73-9.52,5.73-15.99,0-4.46-.89-8.4-2.67-11.81Zm-18.89,24.7c-6.84,0-10.26-4.3-10.26-12.89,0-3.5.74-6.52,2.23-9.07,1.48-2.55,4.17-3.82,8.04-3.82s6.39,1.27,7.88,3.82c1.48,2.55,2.23,5.57,2.23,9.07,0,8.59-3.37,12.89-10.1,12.89Z"/>
   </g>
   <g id="_Path_-4">
      <rect class="cls-1" fill="#fff" stroke-width="0px" x="184.03" y="29.94" width="11.22" height="57.21"/>
   </g>
   <g id="_Compound_Path_-3">
      <path class="cls-2" fill="#fff" stroke-width="0px" fill-rule="evenodd" d="m239.87,66.94c0-6.63-1.54-12.17-4.61-16.63-3.08-4.46-8.17-6.68-15.27-6.68s-12.08,2.09-15.39,6.28c-3.31,4.19-4.97,9.26-4.97,15.2,0,15.44,7.05,23.15,21.16,23.15,4.56,0,8.48-1.19,11.77-3.58,3.29-2.39,5.57-5.7,6.84-9.95h-11.45c-.43,1.33-1.29,2.43-2.59,3.3-1.3.88-2.82,1.31-4.57,1.31-6.21,0-9.57-3.47-10.1-10.42h29.19v-1.99Zm-28.71-5.09c.32-2.76,1.19-4.96,2.63-6.6,1.43-1.64,3.44-2.46,6.05-2.46,2.39,0,4.36.81,5.93,2.42,1.56,1.62,2.45,3.83,2.66,6.64h-17.26Z"/>
   </g>
   <g id="_Path_-5">
      <polygon class="cls-2" fill="#fff" stroke-width="0px" fill-rule="evenodd" points="267.79 65.59 281.79 44.74 268.75 44.74 261.59 57.15 254.43 44.74 240.91 44.74 254.75 65.59 240.51 87.15 253.87 87.15 261.11 74.42 268.59 87.15 282.27 87.15 267.79 65.59"/>
   </g>
   <text class="cls-4" fill="#262626" font-family="Helvetica-Bold, Helvetica" font-size="22.24px" font-weight="700" transform="translate(28.43 146.88)">
      <tspan x="0" y="0">XCEEDS XPEC</tspan>
      <tspan class="cls-5" letter-spacing="-.0em" x="145.22" y="0">TA</tspan>
      <tspan x="173.59" y="0">TIONS</tspan>
   </text>
</g>
</svg>`;

const finolexConnectLogo = ``

const MenuIcon = `<svg width="28" height="17" viewBox="0 0 28 17" fill="none" xmlns="http://www.w3.org/2000/svg">
<line x1="1.5" y1="8.5" x2="17.7" y2="8.5" stroke="white" stroke-width="3" stroke-linecap="round"/>
<line x1="1.5" y1="15.5" x2="26.5" y2="15.5" stroke="white" stroke-width="3" stroke-linecap="round"/>
<line x1="1.5" y1="1.5" x2="12.1" y2="1.5" stroke="white" stroke-width="3" stroke-linecap="round"/>
</svg>
`

const profileIcon = `<svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M18.1404 21.6198C17.2604 21.8798 16.2204 21.9998 15.0004 21.9998H9.00035C7.78035 21.9998 6.74035 21.8798 5.86035 21.6198C6.08035 19.0198 8.75035 16.9697 12.0004 16.9697C15.2504 16.9697 17.9204 19.0198 18.1404 21.6198Z" stroke="#667085" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15 2H9C4 2 2 4 2 9V15C2 18.78 3.14 20.85 5.86 21.62C6.08 19.02 8.75 16.97 12 16.97C15.25 16.97 17.92 19.02 18.14 21.62C20.86 20.85 22 18.78 22 15V9C22 4 20 2 15 2ZM12 14.17C10.02 14.17 8.42 12.56 8.42 10.58C8.42 8.60002 10.02 7 12 7C13.98 7 15.58 8.60002 15.58 10.58C15.58 12.56 13.98 14.17 12 14.17Z" stroke="#667085" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15.58 10.58C15.58 12.56 13.98 14.17 12 14.17C10.02 14.17 8.42 12.56 8.42 10.58C8.42 8.60002 10.02 7 12 7C13.98 7 15.58 8.60002 15.58 10.58Z" stroke="#667085" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const filterIcon = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M5.40039 2.09998H18.6004C19.7004 2.09998 20.6004 2.99998 20.6004 4.09998V6.29998C20.6004 7.09998 20.1004 8.09998 19.6004 8.59998L15.3004 12.4C14.7004 12.9 14.3004 13.9 14.3004 14.7V19C14.3004 19.6 13.9004 20.4 13.4004 20.7L12.0004 21.6C10.7004 22.4 8.90039 21.5 8.90039 19.9V14.6C8.90039 13.9 8.50039 13 8.10039 12.5L4.30039 8.49998C3.80039 7.99998 3.40039 7.09998 3.40039 6.49998V4.19998C3.40039 2.99998 4.30039 2.09998 5.40039 2.09998Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

`

const crossBlue = `<svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.5 1.5L1.5 6.5M1.5 1.5L6.5 6.5" stroke="#1D93D1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const checkedCheckbox = `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="0.5" y="0.5" width="19" height="19" rx="9.5" fill="#1D93D1"/>
<rect x="0.5" y="0.5" width="19" height="19" rx="9.5" stroke="#1D93D1"/>
<path d="M14.6668 6.5L8.25016 12.9167L5.3335 10" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const uncheckedCheckbox = `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect x="0.5" y="0.5" width="19" height="19" rx="9.5" fill="white"/>
<rect x="0.5" y="0.5" width="19" height="19" rx="9.5" stroke="#D0D5DD"/>
</svg>
`
const orderSuccessScreen = `<svg width="348" height="348" viewBox="0 0 348 348" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="174" cy="174" r="174" fill="#2FE941" fill-opacity="0.1"/>
<circle cx="174.001" cy="173.341" r="141.045" fill="#7DCE13" fill-opacity="0.1"/>
<circle cx="174.001" cy="174.659" r="108.091" fill="#7DCE13" fill-opacity="0.1"/>
<circle cx="173.999" cy="173.341" r="75.1364" fill="#7DCE13" fill-opacity="0.1"/>
<circle cx="174" cy="173.341" r="42.1818" fill="#7DCE13"/>
<path d="M167.871 185.307C167.374 185.307 166.877 185.123 166.497 184.755L156.775 175.331C156.016 174.595 156.016 173.403 156.775 172.667C157.535 171.931 158.765 171.931 159.524 172.667L167.871 180.759L187.873 161.37C188.632 160.634 189.862 160.634 190.621 161.37C191.38 162.106 191.38 163.298 190.621 164.034L169.246 184.755C168.866 185.123 168.369 185.307 167.871 185.307Z" fill="white"/>
</svg>
`
const tickIcon = `<svg width="12" height="9" viewBox="0 0 12 9" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10.6666 1.5L4.24992 7.91667L1.33325 5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const deleteBlue = `<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12.25 3.48835C10.3075 3.29585 8.35333 3.19669 6.405 3.19669C5.25 3.19669 4.095 3.25502 2.94 3.37169L1.75 3.48835" stroke="#1D93D1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M4.95825 2.89916L5.08659 2.13499C5.17992 1.58082 5.24992 1.16666 6.23575 1.16666H7.76409C8.74992 1.16666 8.82575 1.60416 8.91325 2.14082L9.04159 2.89916" stroke="#1D93D1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M10.9961 5.33145L10.6169 11.2056C10.5527 12.1215 10.5002 12.8331 8.87273 12.8331H5.12773C3.50023 12.8331 3.44773 12.1215 3.38356 11.2056L3.00439 5.33145" stroke="#1D93D1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.02588 9.625H7.96838" stroke="#1D93D1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M5.54175 7.29166H8.45841" stroke="#1D93D1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const announcementIcon = `<svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_638_330)">
<path d="M25 50C38.8071 50 50 38.8071 50 25C50 11.1929 38.8071 0 25 0C11.1929 0 0 11.1929 0 25C0 38.8071 11.1929 50 25 50Z" fill="#FF7069"/>
<path d="M20.3915 43.4875L18.0428 30.8719L11.7794 33.1494L16.3168 44.822C16.726 45.8541 20.694 44.8933 20.3915 43.4875Z" fill="#E4E7ED"/>
<path d="M18.1851 31.6726L18.0427 30.8541L11.7615 33.1316L12.153 34.1104L18.1851 31.6726Z" fill="#C6CBD6"/>
<path d="M22.2242 27.7046L41.3701 28.8968L32.2065 5.67617L19.0569 19.6619C20.2314 22.6513 21.0498 24.7153 22.242 27.6868L22.2242 27.7046Z" fill="#E4E7ED"/>
<path d="M22.2242 27.7046L41.3701 28.8968L40.5515 26.8149H21.8683L22.2242 27.7046Z" fill="#C6CBD6"/>
<path d="M19.3416 19.8398C19.1281 19.3061 18.6121 18.9857 18.2029 19.1637L7.22424 23.5409C6.79719 23.7011 6.63703 24.2883 6.85061 24.8221L8.45207 28.879L10.0535 32.9182C10.267 33.452 10.783 33.7723 11.1923 33.5943L22.1709 29.2171C22.598 29.0569 22.7581 28.4697 22.5446 27.9359L20.9431 23.8968L19.3416 19.8398Z" fill="#6C7678"/>
<path d="M42.4022 28.3274C42.5979 28.8257 42.4199 29.3772 41.9751 29.5552C41.5481 29.7331 41.032 29.4662 40.8363 28.9502L31.7615 5.99649C31.5658 5.49825 31.7438 4.94668 32.1886 4.76875C32.6156 4.59082 33.1316 4.87549 33.3274 5.37373L42.4022 28.3274Z" fill="#6C7678"/>
<path d="M9.6619 31.9573L7.13524 25.5872C2.58006 26.7972 4.57293 34.0569 9.6619 31.9573Z" fill="#E4E7ED"/>
<path d="M42.5623 14.5195L39.2528 15.8185C39.0571 15.8896 38.9859 16.1743 39.0926 16.4412C39.1993 16.7081 39.4485 16.8683 39.6442 16.7971L42.9537 15.4981C43.1494 15.427 43.2206 15.1423 43.1139 14.8754C43.0072 14.6085 42.758 14.4484 42.5623 14.5195Z" fill="#FFE356"/>
<path d="M16.2278 44.6264L20.3914 43.5588C20.9964 43.3986 21.2811 44.5374 20.6761 44.6976L16.5303 45.7295C15.9609 45.8719 15.6584 44.7864 16.21 44.644L16.2278 44.6264Z" fill="#6C7678"/>
<path d="M39.2171 8.06055L37.0818 10.9075C36.9573 11.0677 37.0463 11.3523 37.2775 11.5303C37.5089 11.7082 37.7935 11.7082 37.9181 11.548L40.0533 8.70108C40.1778 8.54092 40.0889 8.25625 39.8576 8.07832C39.6264 7.90039 39.3416 7.90039 39.2171 8.06055Z" fill="#FFE356"/>
<path d="M44.822 22.4377L41.3345 21.7793C41.1388 21.7438 41.0142 21.4768 41.0676 21.1921C41.1211 20.9074 41.3345 20.7116 41.5302 20.7473L45.0177 21.4057C45.2134 21.4412 45.3381 21.7082 45.2846 21.9929C45.2313 22.2775 45.0177 22.4733 44.822 22.4377Z" fill="#FFE356"/>
<path d="M8.82558 23.9502C8.68319 24.0036 8.50526 23.9324 8.45194 23.79C8.39853 23.6477 8.46972 23.4697 8.6121 23.4164L16.121 20.516C16.2634 20.4626 16.4413 20.5338 16.4946 20.6762C16.548 20.8186 16.4768 20.9965 16.3345 21.0498L8.82558 23.9502Z" fill="#E4E7ED"/>
</g>
<defs>
<clipPath id="clip0_638_330">
<rect width="50" height="50" fill="white"/>
</clipPath>
</defs>
</svg>
`
const addSquareWhite = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8 12H16" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12 16V8" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const addCircleWhite = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12 22C17.5 22 22 17.5 22 12C22 6.5 17.5 2 12 2C6.5 2 2 6.5 2 12C2 17.5 6.5 22 12 22Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8 12H16" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12 16V8" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const cart = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M2 2H3.74001C4.82001 2 5.67 2.93 5.58 4L4.75 13.96C4.61 15.59 5.89999 16.99 7.53999 16.99H18.19C19.63 16.99 20.89 15.81 21 14.38L21.54 6.88C21.66 5.22 20.4 3.87 18.73 3.87H5.82001" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M16.25 22C16.9404 22 17.5 21.4404 17.5 20.75C17.5 20.0596 16.9404 19.5 16.25 19.5C15.5596 19.5 15 20.0596 15 20.75C15 21.4404 15.5596 22 16.25 22Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8.25 22C8.94036 22 9.5 21.4404 9.5 20.75C9.5 20.0596 8.94036 19.5 8.25 19.5C7.55964 19.5 7 20.0596 7 20.75C7 21.4404 7.55964 22 8.25 22Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M9 8H21" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const downloadIcon = `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M13.7 7.41666C16.7 7.67499 17.925 9.21666 17.925 12.5917V12.7C17.925 16.425 16.4333 17.9167 12.7083 17.9167H7.28333C3.55833 17.9167 2.06667 16.425 2.06667 12.7V12.5917C2.06667 9.24166 3.275 7.69999 6.225 7.42499" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M10 1.66666V12.4" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12.7917 10.5417L10 13.3333L7.20833 10.5417" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const downArrowSvg = `<svg width="10" height="5" viewBox="0 0 10 5" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M5.3446 4.75909L9.05955 1.2063C9.29599 0.980296 9.29599 0.613875 9.05955 0.387984C8.82332 0.162074 8.44019 0.162074 8.20398 0.387984L4.91682 3.53166L1.62977 0.388075C1.39345 0.162166 1.01035 0.162166 0.77412 0.388075C0.537797 0.613984 0.537797 0.980387 0.77412 1.20639L4.48913 4.75918C4.6073 4.87214 4.76201 4.92855 4.9168 4.92855C5.07166 4.92855 5.22649 4.87203 5.3446 4.75909Z" fill="white"/>
</svg>
`
const downArrowSvgThemeColored = `<svg width="10" height="5" viewBox="0 0 10 5" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M5.3446 4.75909L9.05955 1.2063C9.29599 0.980296 9.29599 0.613875 9.05955 0.387984C8.82332 0.162074 8.44019 0.162074 8.20398 0.387984L4.91682 3.53166L1.62977 0.388075C1.39345 0.162166 1.01035 0.162166 0.77412 0.388075C0.537797 0.613984 0.537797 0.980387 0.77412 1.20639L4.48913 4.75918C4.6073 4.87214 4.76201 4.92855 4.9168 4.92855C5.07166 4.92855 5.22649 4.87203 5.3446 4.75909Z" fill="#1D93D1"/>
</svg>
`
const errorIcon = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.99998 5.33333V8M7.99998 10.6667H8.00665M14.6666 8C14.6666 11.6819 11.6819 14.6667 7.99998 14.6667C4.31808 14.6667 1.33331 11.6819 1.33331 8C1.33331 4.3181 4.31808 1.33333 7.99998 1.33333C11.6819 1.33333 14.6666 4.3181 14.6666 8Z" stroke="#F04438" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const downArrowBlack = `<svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1 1.5L6 6.5L11 1.5" stroke="#667085" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`
const menuItemArrow = `<svg width="6" height="11" viewBox="0 0 6 11" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M5.65178 4.96195L1.34467 0.460874C1.07069 0.174403 0.626472 0.174403 0.352622 0.460874C0.0787485 0.74709 0.0787485 1.2113 0.352622 1.4975L4.16374 5.48026L0.352732 9.46289C0.0788593 9.74922 0.0788593 10.2134 0.352732 10.4996C0.626605 10.7859 1.0708 10.7859 1.34478 10.4996L5.65189 5.99846C5.78883 5.85528 5.85722 5.66783 5.85722 5.48029C5.85722 5.29265 5.78869 5.10506 5.65178 4.96195Z" fill="#344054"/>
</svg>
`
const upArrowBlack = `<svg width="15" height="8" viewBox="0 0 15 8" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.15714 0.491853L1.07612 6.31081C0.689096 6.68096 0.689096 7.28111 1.07612 7.65108C1.4628 8.02109 2.08996 8.02109 2.47661 7.65108L7.85738 2.50221L13.238 7.65093C13.6248 8.02094 14.2519 8.02094 14.6386 7.65093C15.0254 7.28093 15.0254 6.68081 14.6386 6.31066L8.55747 0.491704C8.36404 0.3067 8.11079 0.214303 7.85741 0.214303C7.60392 0.214303 7.35048 0.30688 7.15714 0.491853Z" fill="#344054"/>
</svg>
`
const upArrowSvgThemeColored = `<svg width="15" height="8" viewBox="0 0 15 8" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.15714 0.491853L1.07612 6.31081C0.689096 6.68096 0.689096 7.28111 1.07612 7.65108C1.4628 8.02109 2.08996 8.02109 2.47661 7.65108L7.85738 2.50221L13.238 7.65093C13.6248 8.02094 14.2519 8.02094 14.6386 7.65093C15.0254 7.28093 15.0254 6.68081 14.6386 6.31066L8.55747 0.491704C8.36404 0.3067 8.11079 0.214303 7.85741 0.214303C7.60392 0.214303 7.35048 0.30688 7.15714 0.491853Z" fill="#1D93D1"/>
</svg>
`
export {
   FinolexLogo,
   MenuIcon,
   profileIcon,
   filterIcon,
   crossBlue,
   checkedCheckbox,
   uncheckedCheckbox,
   orderSuccessScreen,
   tickIcon,
   deleteBlue,
   announcementIcon,
   addSquareWhite,
   addCircleWhite,
   cart,
   downloadIcon,
   downArrowSvg,
   errorIcon,
   downArrowBlack,
   menuItemArrow,
   finolexConnectLogo,
   downArrowSvgThemeColored,
   upArrowBlack,
   upArrowSvgThemeColored
}