import { Appearance } from "react-native";
const colorScheme = Appearance.getColorScheme();

const labelFontSizeSmall = 10;
const labelFontSizeMedium = 12;
const labelFontSize = 14;
const labelFontSizeLarge = 16;
const labelFontSizeExtraLarge = 18;

const headingFontSizeSmall = 20;
const headingFontSize = 22;
const headingFontSizeLarge = 24;

const pageBackgroundColor = "#F5F5F5";
const themeColor = "#1D93D1";
const whiteColor = "#FFFFFF";
const TextColor1 = "#667085"
const TextColor2 = "#344054"

// const textInputValueColor = colorScheme == 'dark' ? '#000000' : undefined
// const placeholderColor = colorScheme == 'dark' ? '#a9a9a9' : undefined
// const cursorColor = colorScheme == 'dark' ? '#00FF00' : undefined

const textInputValueColor = '#000000'
const placeholderColor = '#a9a9a9'
const cursorColor = 'green'

const borderLightedColor = "#03DAC6"
export {
   labelFontSize,
   pageBackgroundColor,
   whiteColor,
   TextColor1,
   TextColor2,
   labelFontSizeSmall,
   themeColor,
   labelFontSizeLarge,
   labelFontSizeExtraLarge,
   headingFontSize,
   borderLightedColor,
   labelFontSizeMedium,
   headingFontSizeSmall,
   placeholderColor,
   cursorColor,
   textInputValueColor,
   headingFontSizeLarge
}