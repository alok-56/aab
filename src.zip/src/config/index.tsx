import * as Images from './images'
import * as fontAttribute from './fontConfig'
import * as AppStyle from './Style'
import * as svgs from './svg'
export {
    Images,
    fontAttribute,
    svgs,
    AppStyle
}