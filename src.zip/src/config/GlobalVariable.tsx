import { format } from 'date-fns';
import { Alert, Platform } from 'react-native';
import FileViewer from 'react-native-file-viewer';
import { showMessage } from 'react-native-flash-message';
import RNFS from 'react-native-fs';
import GetLocation from 'react-native-get-location';
import {
  openSettings,
  PERMISSIONS,
  request,
  RESULTS,
} from 'react-native-permissions';
import { DeleteDeviceDetails } from '../ApiServices/httpServices';

export type StatusKey = 1 | 2 | 3 | 4 | 5 | 6 | 7;
export const OrderStatusColorCodes: { [key in StatusKey]: string } = {
  1: '#FFA500', // Pending
  2: '#008000', // Invoiced
  3: '#FFD700', // Partially Invoiced
  4: '#0000FF', // Short Close
  5: '#006400', // Received
  6: '#FF0000', // Terminated
  7: '#8B0000', // Rejected
  // 8: '#000000', // None of the above
};
export type BankStatusKey = 'approved' | 'rejected' | 'sent for approval';
export const BankDetailsStatusCodes: { [key in BankStatusKey]: string } = {
  approved: '#FFA500', // approved
  rejected: '#8B0000', // Rejected
  'sent for approval': '#008000', // updated
  // 4: '#0000FF', // Short Close
  // 5: '#006400', // Received
  // 6: '#FF0000', // Terminated
  // 7: '#8B0000', // Rejected
  // 8: '#000000', // None of the above
};

export const NavMenu = {
  login: {
    login: 'Login',
    loginWithPassword: 'loginWithPassword',
    loginWithOTP: 'loginWithOTP',
    loginSuccess: 'loginSuccess',
  },
  home: 'Home',
  profile: 'profile',
  updateBankDetails: 'updateBankDetails',
  productCatalog: 'productCatalog',
  changeLanguage: 'changeLanguage',
  changePassword: 'changePassword',
  feedback: {
    feedbackList: 'feedbackList',
    createFeedback: 'createFeedback',
  },
  header: 'header',
  contactUs: 'contactUs',
  order: {
    order: 'order',
    createOrder: 'createOrder',
    Cart: 'orderCart',
    selectDeliveryAddress: 'orderSelectDeliveryAddress',
    selectPaymentMethod: 'orderSelectPaymentMethod',
    placeOrder: 'placeOrder',
    successScreen: 'orderSuccessScreen',
    orderDetail: 'orderDetail',
  },
  ledger: {
    distributorLedger: 'selectDistributorLedger',
    ledger: 'ledger',
  },
  forgotPassword: 'forgotPassword',
  forceUpdate: 'forceupdate',
  beatPlanManagement: {
    addRetailer: 'addRetailer',
    visitDetailsList: 'visitDetailsList',
    visitDetailsForm: 'visitDetailsForm',
    markedVisits: 'markedVisits',
    markedVisitsForm: 'markedVisitsForm',
  },
  Scheme: {
    Dashboard: 'dashboard',
    RedeemReport:"redeemreport",
    AcculateReport:"accumulatereport",
    Scanner:"scanner",
    Redeem:"redeenpoints",
    Profile:"loyalityprofile",
    Kyc:"Kycverification"
  },
};

export const pixelValue = 1;
export let PUSH_Token: any;
export const setPushToken = (token: any) => {
  PUSH_Token = token;
};
export const checkStringNullOrEmpty = (stringData: string | undefined) => {
  if (stringData == null || stringData == '' || stringData == undefined)
    return false;
  else return true;
};

export const capitalize = (str: string | undefined) => {
  if (str && typeof str === 'string') {
    return str
      .toLowerCase()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.substring(1))
      .join(' ');
  }
  return str;
};

export function formatFileSize(bytes: any) {
  console.log(bytes, bytes.size, 'size');
  if (bytes < 1024) {
    return bytes + ' bytes';
  } else if (bytes < 1024 * 1024) {
    return (bytes / 1024).toFixed(2) + ' KB';
  } else {
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  }
}

export const ChangeAmountFormat = (Amount: number) => {
  if (Amount && typeof Amount === 'number') {
    return Amount.toLocaleString('en-US');
  }
  return Amount;
};
export const ConvertDateFormat = (date: Date) => {
  if (!date) return '';
  return format(date, 'dd-MMM-yyyy');
};

export const fixToTwoDecimal = (amount: any) => {
  return parseFloat(amount).toFixed(2);
};

export const compareVersion = (version1: string, version2: string) => {
  console.log(version1, version2);
  var v1 = version1?.split('.');
  var v2 = version2?.split('.');
  console.log(v1, v2);
  var len = Math.max(v1.length, v2.length);
  var t1 = 0;
  var t2 = 0;
  for (var i = 0; i < len; i++) {
    t1 = parseInt(v1[i] || '0');
    t2 = parseInt(v2[i] || '0');
    if (t1 > t2) return 1;
    if (t1 < t2) return 0;
  }
  return 0;
};

export const deleteDeviceDetails = (userId: number | undefined) => {
  const params = {
    UserId: userId,
    UUID: PUSH_Token,
  };
  DeleteDeviceDetails(params)
    .then(result => {
      console.log('Delete Device Details', result);
    })
    .catch((err: any) => {
      console.log('error', err);
    });
};

export const downloadFile = async (
  url: any,
  name: any,
  setIsDownloadLoader: Function,
) => {
  console.log('downloadUrl', url);
  // setIsDownloadLoader(true)
  const localFilePath = `${RNFS.DocumentDirectoryPath}/${name}.${
    url.split('.')[url.split('.').length - 1]
  }`;
  try {
    await RNFS.downloadFile({
      fromUrl: url,
      toFile: localFilePath,
    }).promise;
    openDownloadedFile(localFilePath, setIsDownloadLoader);
  } catch (error) {
    setIsDownloadLoader(false);
    console.error('File download error:', error);
    throw error;
  }
};

export const openDownloadedFile = async (
  filePath: any,
  setIsDownloadLoader: Function,
) => {
  try {
    setTimeout(() => {
      FileViewer.open(filePath);
    }, 50);
    setIsDownloadLoader(false);
  } catch (error) {
    setIsDownloadLoader(false);
    console.error('Error opening file:', error);
  }
};

//location permission
export const requestLocationPermission = async () => {
  try {
    if (Platform.OS === 'ios') {
      return true;
    }
    const permission = PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION;
    const granted = await request(permission);
    console.log('permission status', granted);

    if (granted === RESULTS.GRANTED) {
      return true;
    } else {
      return handlePermissionResult(granted, permission);
    }
  } catch (err) {
    console.warn(err);
    return false;
  }
};

const handlePermissionResult = async (result: any, permission: any) => {
  if (
    result === RESULTS.DENIED ||
    result === RESULTS.BLOCKED ||
    result === RESULTS.UNAVAILABLE ||
    result === 'never_ask_again'
  ) {
    while (result !== RESULTS.GRANTED) {
      result = await request(permission);
      if (result === RESULTS.GRANTED) {
        return true;
      } else if (result === RESULTS.BLOCKED || result === 'never_ask_again') {
        showRationale();
        return false;
      }
    }
  }
};

const showRationale = () => {
  Alert.alert(
    'Location Permission',
    'Location permission is required. Please enable it from settings.',
    [
      {
        text: 'Cancel',
        style: 'cancel',
      },
      {
        text: 'Open Settings',
        onPress: () => openSettings(),
      },
    ],
  );
};

//get location from Api
const reverseGeocode = async (latitude: any, longitude: any) => {
  const apiKey = 'cfdbaa69fbe95a3906f0702295a2176f'; //have to make global
  try {
    const response = await fetch(
      `https://apis.mapmyindia.com/advancedmaps/v1/${apiKey}/rev_geocode?lat=${latitude}&lng=${longitude}    `,
    );
    const data = await response.json();

    // Extract address from the response
    const address = data;

    return address;
  } catch (error) {
    console.error(error);
    return null;
  }
};

export const getLocation = async () => {
  const location = await GetLocation.getCurrentPosition({
    enableHighAccuracy: true,
    timeout: 60000,
  });

  const address = await reverseGeocode(location?.latitude, location?.longitude);

  if (address?.responseCode == 200 && address != null) {
    return {
      latitude: location.latitude,
      longitude: location.longitude,
      address: address.results[0].formatted_address,
    };
  } else {
    showMessage({
      message: address?.error,
      color: 'white',
      duration: 3000,
      animated: true,
      backgroundColor: 'red',
    });
    return null;
  }
};
