import { connect, shallowEqual, useDispatch, useSelector } from 'react-redux';
import { NavigationContainer } from '@react-navigation/native';
import { BaseSetting } from '../config/setting';
import {
  Alert,
  PermissionsAndroid,
  Platform,
  StatusBar,
  View,
} from 'react-native';
import Main from './main';
import FlashMessage from 'react-native-flash-message';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { useEffect, useRef, useState } from 'react';
import { themeColor } from '../config/fontConfig';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { GetAppVersionData } from '../ApiServices/httpServices';
import DeviceInfo from 'react-native-device-info';
import {
  NavMenu,
  compareTime,
  compareVersion,
  deleteDeviceDetails,
} from '../config/GlobalVariable';
import {
  setAccessToken,
  setDistributors,
  setMenuList,
  setProfileDetail,
  setUserData,
} from '../redux/actions/authAction';
import { setSelecteLanguage } from '../redux/actions/langAction';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function Navigator() {
  const storeLanguage = useSelector(
    state => state.lang.language?.languageCode,
    shallowEqual,
  );

  i18n.use(initReactI18next).init({
    resources: BaseSetting.resourcesLanguage,
    lng: storeLanguage ?? BaseSetting.defaultLanguage,
    fallbackLng: BaseSetting.defaultLanguage,
  });

  useEffect(() => {
    getVersionDetails();
  }, []);

  const AppVersion = DeviceInfo.getVersion();

  const loginTime = useSelector(state => state?.auth?.loginTime, shallowEqual);

  const profileDetail = useSelector(
    state => state.auth.profileData,
    shallowEqual,
  );

  const resetToForceUpdatePage = () => {
    if (navRef && navRef.current) {
      navRef.current.reset({
        index: 0,
        routes: [{ name: NavMenu.forceUpdate }],
      });
    }
  };

  const forceUpdate = result => {
    if (Platform.OS == 'android') {
      if (
        compareVersion(result?.data[0]?.appVersion, AppVersion) &&
        result?.data[0]?.isForceUpdate
      ) {
        
        resetToForceUpdatePage();
      }
    } else {
      if (
        compareVersion(result?.data[1]?.appVersion, AppVersion) &&
        result?.data[1]?.isForceUpdate
      ) {
        resetToForceUpdatePage();
      }
    }
  };

  const dispatch = useDispatch();

  const forceLogout = result => {
    const date1 = new Date(loginTime);
    const date2 = new Date(result?.data[0]?.forceLogout);
    if (result?.data[0]?.isForceLogout && date1 <= date2) {
      deleteDeviceDetails(profileDetail?.profile.profileId);
      dispatch(
        setSelecteLanguage({
          languageCode: 'en',
          languageId: 2,
          languageName: 'English',
        }),
      );
      dispatch(setUserData(null));
      dispatch(setAccessToken(null));
      dispatch(setProfileDetail(null));
      dispatch(setDistributors(null));
      dispatch(setMenuList(null));
    }
  };

  const getVersionDetails = () => {
    const params = new FormData();
    params.append('OSName', Platform.OS);

    GetAppVersionData(params)
      .then(result => {
        if (result) {
          forceUpdate(result);
          forceLogout(result);
        }
      })
      .catch(err => {
        console.log('app version data', err);
      });
  };
  const navRef = useRef();

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaView style={[{ flex: 1, backgroundColor: 'transparent' }]}>
        <NavigationContainer ref={navRef}>
          <FlashMessage position="bottom" />
          <StatusBar backgroundColor={themeColor} />
          <Main />
        </NavigationContainer>
      </SafeAreaView>
    </GestureHandlerRootView>
  );
}
