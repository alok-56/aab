import { createDrawerNavigator } from '@react-navigation/drawer';
import { useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React, { useEffect } from 'react';
import { View } from 'react-native';
import DeviceInfo from 'react-native-device-info';
import SplashScreen from 'react-native-splash-screen';
import { shallowEqual, useSelector } from 'react-redux';
import { Headercomponent } from '../Components';
import DrawerContent from '../Components/DrawerContent/DrawerContent';
import { NavMenu } from '../config/GlobalVariable';
import AddRetailer from '../screens/AddRetailer';
import VisitDetailsForm from '../screens/BeatManagement/VisitDetailsForm';
import VisitDetailsList from '../screens/BeatManagement/VisitDetailsList';
import ChangeLanguage from '../screens/Change_Language';
import ChangePassword from '../screens/Change_Password';
import ContactUs from '../screens/Contact_Us';
import CreateFeedback from '../screens/Feedback/Create_Feedback';
import FeedbackList from '../screens/Feedback/Feedback_List';
import ForceUpdate from '../screens/ForceUpdate';
import ForgotPassword from '../screens/Forgot_Password';
import home from '../screens/home';
import Ledger from '../screens/Ledger/Ledger';
import SelectDistributor_Ledger from '../screens/Ledger/SelectDistributor';
import LoginScreen from '../screens/LoginPage/LogInScreen';
import OTPScreen from '../screens/LoginPage/OTPScreen';
import VerificationSuccess from '../screens/LoginPage/VerificationSuccessScreen';
import WelcomeScreen from '../screens/LoginPage/WelcomeScreen';
import CreateOrder from '../screens/OrderPages/Create_Order';
import OrderMyCart from '../screens/OrderPages/My_Cart_Order';
import Order from '../screens/OrderPages/Order';
import OrderDetail from '../screens/OrderPages/Order_Detail';
import PlaceOrder from '../screens/OrderPages/Place_Order';
import OrderSelectDeliveryAddress from '../screens/OrderPages/Select_Delivery_Address_Order';
import OrderSelectPaymentMethod from '../screens/OrderPages/Select_Payment_Method_Order';
import OrderSuccessScreen from '../screens/OrderPages/Success_Screen';
import ProductCatalog from '../screens/Product_Catalogue';
import Profile from '../screens/Profile';
import MarkedVisitsForm from '../screens/BeatManagement/MarkedVisitsForm';
import UpdateBankDetails from '../screens/Profile/UpdateBankDetails/updateBankDetails';
import Dashboard from '../screens/RetailerScheme/Dashboard';
import RedeemReport from '../screens/RetailerScheme/Report/RedeemReport';
import AccumulateReport from '../screens/RetailerScheme/Report/AccumulateReport';
import Scanner from '../screens/RetailerScheme/Scanner';
import Redeem from '../screens/RetailerScheme/Redeem';
import LoyalityProfile from '../screens/RetailerScheme/Profile';
import Kyc from '../screens/RetailerScheme/Profile/kyc';

export default function Main() {
  const MainStack = createNativeStackNavigator();
  const userData = useSelector(
    (state: any) => state?.auth?.userData,
    shallowEqual,
  );

  useEffect(() => {
    SplashScreen.hide();
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: '#272727' }}>
      <MainStack.Navigator initialRouteName={userData ? NavMenu.home : 'Login'}>
        <MainStack.Screen
          name={NavMenu.home}
          options={{ headerShown: false }}
          component={DrawerNavigator}
        />
        <MainStack.Screen
          name={NavMenu.login.login}
          component={WelcomeScreen}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.login.loginWithPassword}
          component={LoginScreen}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.login.loginWithOTP}
          component={OTPScreen}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.login.loginSuccess}
          component={VerificationSuccess}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.order.order}
          component={Order}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.profile}
          component={Profile}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.productCatalog}
          component={ProductCatalog}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.changeLanguage}
          component={ChangeLanguage}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.changePassword}
          component={ChangePassword}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.feedback.feedbackList}
          component={FeedbackList}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.feedback.createFeedback}
          component={CreateFeedback}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.header}
          component={Headercomponent}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.contactUs}
          component={ContactUs}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.order.createOrder}
          component={CreateOrder}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.order.Cart}
          component={OrderMyCart}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.order.selectDeliveryAddress}
          component={OrderSelectDeliveryAddress}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.order.selectPaymentMethod}
          component={OrderSelectPaymentMethod}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.order.placeOrder}
          component={PlaceOrder}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.order.successScreen}
          component={OrderSuccessScreen}
          options={{ headerShown: false, gestureEnabled: false }}
        />
        <MainStack.Screen
          name={NavMenu.order.orderDetail}
          component={OrderDetail}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.ledger.distributorLedger}
          component={SelectDistributor_Ledger}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.ledger.ledger}
          component={Ledger}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.forgotPassword}
          component={ForgotPassword}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.forceUpdate}
          component={ForceUpdate}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.beatPlanManagement.addRetailer}
          component={AddRetailer}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.beatPlanManagement.visitDetailsList}
          component={VisitDetailsList}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.beatPlanManagement.visitDetailsForm}
          component={VisitDetailsForm}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.beatPlanManagement.markedVisitsForm}
          component={MarkedVisitsForm}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.updateBankDetails}
          component={UpdateBankDetails}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.Scheme.Dashboard}
          component={Dashboard}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.Scheme.RedeemReport}
          component={RedeemReport}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.Scheme.AcculateReport}
          component={AccumulateReport}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.Scheme.Scanner}
          component={Scanner}
          options={{ headerShown: false }}
        />
        <MainStack.Screen
          name={NavMenu.Scheme.Redeem}
          component={Redeem}
          options={{ headerShown: false }}
        />
         <MainStack.Screen
          name={NavMenu.Scheme.Profile}
          component={LoyalityProfile}
          options={{ headerShown: false }}
        />
         <MainStack.Screen
          name={NavMenu.Scheme.Kyc}
          component={Kyc}
          options={{ headerShown: false }}
        />
      </MainStack.Navigator>
    </View>
  );
}

const DrawerNavigator = () => {
  const drawer = createDrawerNavigator();
  return (
    <>
      <drawer.Navigator
        drawerContent={props => <DrawerContent {...props} />}
        screenOptions={{
          drawerStyle: {
            width: '85%',
          },
        }}
      >
        <drawer.Screen
          name="home"
          component={home}
          options={{
            headerShown: false,
            title: 'Dashboard',
            headerTitleStyle: {
              color: 'white',
            },
            headerTintColor: 'white',
            headerStyle: {
              backgroundColor: '#1D93D1',
            },
          }}
        />
      </drawer.Navigator>
    </>
  );
};
